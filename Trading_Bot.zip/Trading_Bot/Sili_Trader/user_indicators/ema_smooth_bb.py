import pandas as pd
import numpy as np

def _ema(series: pd.Series, length: int) -> pd.Series:
    return series.ewm(span=length, adjust=False).mean()

def _sma(series: pd.Series, length: int) -> pd.Series:
    return series.rolling(window=length).mean()

def _rma(series: pd.Series, length: int) -> pd.Series:
    return series.ewm(alpha=1/length, adjust=False).mean()

def _wma(series: pd.Series, length: int) -> pd.Series:
    weights = np.arange(1, length + 1)
    return series.rolling(window=length).apply(lambda prices: np.dot(prices, weights) / weights.sum(), raw=True)

def _vwma(series: pd.Series, volume: pd.Series, length: int) -> pd.Series:
    return (series * volume).rolling(window=length).sum() / volume.rolling(window=length).sum()

def calculate_ema_smooth_bb(df: pd.DataFrame, params: dict = None) -> dict:
    if params is None:
        params = {}

    ema_len = int(params.get("ema_length", 9))
    ma_type = params.get("ma_type", "None")
    show_bb = params.get("show_bb", False)
    bb_len = int(params.get("bb_length", 14))
    bb_mult = float(params.get("bb_mult", 2.0))
    
    src = df["close"]
    vol = df.get("volume", pd.Series(1, index=df.index))

    # Base EMA
    base_ema = _ema(src, ema_len)

    # Smoothing MA
    smoothing_ma = None
    if ma_type == "SMA":
        smoothing_ma = _sma(base_ema, bb_len)
    elif ma_type == "EMA":
        smoothing_ma = _ema(base_ema, bb_len)
    elif ma_type == "SMMA":
        smoothing_ma = _rma(base_ema, bb_len)
    elif ma_type == "WMA":
        smoothing_ma = _wma(base_ema, bb_len)
    elif ma_type == "VWMA":
        smoothing_ma = _vwma(base_ema, vol, bb_len)
    elif ma_type == "SMA + Bollinger Bands":
        smoothing_ma = _sma(base_ema, bb_len)
        show_bb = True

    # If no smoothing selected, use base EMA as the main line
    final_line = smoothing_ma if smoothing_ma is not None else base_ema

    # Prepare Output Series
    output = {
        "main": [{"t": str(ts), "v": round(float(val), 5) if pd.notna(val) else None} for ts, val in final_line.items()]
    }

    # Calculate Bollinger Bands if requested
    if show_bb and smoothing_ma is not None:
        bb_std = base_ema.rolling(window=bb_len).std()
        upper = smoothing_ma + (bb_std * bb_mult)
        lower = smoothing_ma - (bb_std * bb_mult)
        
        output["upper"] = [{"t": str(ts), "v": round(float(val), 5) if pd.notna(val) else None} for ts, val in upper.items()]
        output["lower"] = [{"t": str(ts), "v": round(float(val), 5) if pd.notna(val) else None} for ts, val in lower.items()]

    return output

INDICATORS = {
    "EMA Smooth + BB": {
        "fn": calculate_ema_smooth_bb,
        "type": "line",
        "color": "#2962FF",
        "pane": "price",
        "params_def": {
            "ema_length": {"type": "int", "default": 9, "min": 1, "max": 200, "label": "EMA Length"},
            "ma_type": {
                "type": "select", 
                "default": "None", 
                "options": ["None", "SMA", "SMA + Bollinger Bands", "EMA", "SMMA", "WMA", "VWMA"],
                "label": "Smoothing Type"
            },
            "bb_length": {"type": "int", "default": 14, "min": 2, "max": 100, "label": "BB Length"},
            "bb_mult": {"type": "float", "default": 2.0, "min": 0.1, "max": 10.0, "step": 0.1, "label": "BB Mult"},
            "show_bb": {"type": "bool", "default": False, "label": "Show Bands"}
        },
        "series_def": [
            {"name": "upper", "color": "#00E676", "style": "Dashed"},
            {"name": "main", "color": "#2962FF", "style": "Solid"},
            {"name": "lower", "color": "#FF5252", "style": "Dashed"}
        ]
    }
}