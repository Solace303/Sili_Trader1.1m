"""
sam_market_structure.py — BOS / CHoCH indicator for Sili_Trader  (v2)

What changed from v1
---------------------
Relative BOS / CHoCH lines
  • Bearish BOS/CHoCH
        Anchor  = nearest swing-LOW  (LL or HL) strictly to the LEFT of the
                  detected LH bar.
        Line    = horizontal at that LOW level, drawn rightward from the
                  anchor bar until the FIRST candle whose LOW ≤ anchor level.
        New BOS = that stop-candle  (returned as break_time / to_time).

  • Bullish BOS/CHoCH
        Anchor  = nearest swing-HIGH (HH or LH) strictly to the LEFT of the
                  detected HL bar.
        Line    = horizontal at that HIGH level, drawn rightward until the
                  FIRST candle whose HIGH ≥ anchor level.
        New BOS = that stop-candle.

Marker positions corrected
  • Bullish (UP)  → label placed aboveBar
  • Bearish (DOWN)→ label placed belowBar

Backward compatibility
  • All previous API keys preserved (type / direction / level / from_time /
    to_time / color / events / markers).
  • Legacy detection fields kept as legacy_level / legacy_from_time /
    legacy_to_time so callers that imported the old values still work.
  • New keys added: marker_position, break_time.

Place in:  user_indicators/sam_market_structure.py
"""

from __future__ import annotations
import numpy as np
import pandas as pd


# ── low-level helpers ─────────────────────────────────────────────────────────

def _utc_unix(ts) -> int:
    t = pd.Timestamp(ts)
    if t.tzinfo is None:
        t = t.tz_localize("UTC")
    else:
        t = t.tz_convert("UTC")
    return int(t.timestamp())


def _get_times(df: pd.DataFrame) -> list:
    if isinstance(df.index, pd.DatetimeIndex):
        return df.index.tolist()
    if "time" in df.columns:
        return pd.to_datetime(df["time"]).tolist()
    return df.index.tolist()


def _detect_swings(highs: np.ndarray, lows: np.ndarray, lb: int, rb: int):
    n = len(highs)
    sh, sl = [], []
    for i in range(lb, n - rb):
        left_h  = highs[i - lb : i]
        right_h = highs[i + 1 : i + rb + 1]
        left_l  = lows[i - lb : i]
        right_l = lows[i + 1 : i + rb + 1]

        if left_h.size == lb and right_h.size == rb:
            if highs[i] >= left_h.max() and highs[i] >= right_h.max():
                sh.append(i)

        if left_l.size == lb and right_l.size == rb:
            if lows[i] <= left_l.min() and lows[i] <= right_l.min():
                sl.append(i)
    return sh, sl


def _breaks_above(bar_idx, level, highs, closes, confirm):
    if confirm == "Close":
        return float(closes[bar_idx]) > level
    return float(highs[bar_idx]) > level


def _breaks_below(bar_idx, level, lows, closes, confirm):
    if confirm == "Close":
        return float(closes[bar_idx]) < level
    return float(lows[bar_idx]) < level


def _classify_swings(sh_bars, sl_bars, highs, lows):
    high_labels: dict[int, str] = {}
    low_labels:  dict[int, str] = {}

    prev_h_val = None
    for bar in sh_bars:
        val = float(highs[bar])
        if prev_h_val is None:
            high_labels[bar] = "HH"
        elif val > prev_h_val:
            high_labels[bar] = "HH"
        else:
            high_labels[bar] = "LH"
        prev_h_val = val

    prev_l_val = None
    for bar in sl_bars:
        val = float(lows[bar])
        if prev_l_val is None:
            low_labels[bar] = "LL"
        elif val > prev_l_val:
            low_labels[bar] = "HL"
        else:
            low_labels[bar] = "LL"
        prev_l_val = val

    return high_labels, low_labels


# ── relative-BOS anchor helpers ───────────────────────────────────────────────

def _nearest_sl_before(sl_bars: list, bar: int):
    """Most recent swing-LOW bar index strictly before `bar`, or None."""
    candidates = [b for b in sl_bars if b < bar]
    return candidates[-1] if candidates else None


def _nearest_sh_before(sh_bars: list, bar: int):
    """Most recent swing-HIGH bar index strictly before `bar`, or None."""
    candidates = [b for b in sh_bars if b < bar]
    return candidates[-1] if candidates else None


def _stop_bar_bear(ref_bar: int, ref_level: float, lows: np.ndarray) -> int:
    """First bar AFTER ref_bar where low ≤ ref_level  (bearish line stop)."""
    for b in range(ref_bar + 1, len(lows)):
        if lows[b] <= ref_level:
            return b
    return len(lows) - 1          # line extends to end of visible data


def _stop_bar_bull(ref_bar: int, ref_level: float, highs: np.ndarray) -> int:
    """First bar AFTER ref_bar where high ≥ ref_level  (bullish line stop)."""
    for b in range(ref_bar + 1, len(highs)):
        if highs[b] >= ref_level:
            return b
    return len(highs) - 1


# ── main compute ──────────────────────────────────────────────────────────────

def compute(df: pd.DataFrame, params: dict | None = None) -> dict:
    params  = params or {}

    # ── Inputs tab ───────────────────────────────────────────────────────
    lb      = max(1, int(params.get("pivot_lb",          5)))
    rb      = max(1, int(params.get("pivot_rb",          5)))
    confirm = str(params.get("breakout_confirm",       "H/L"))

    # ── Visibility tab ────────────────────────────────────────────────────
    show_hh_ll  = bool(params.get("show_hh_ll",  True))
    show_hl_lh  = bool(params.get("show_hl_lh",  True))
    show_bos    = bool(params.get("show_bos",    True))
    show_choch  = bool(params.get("show_choch",  True))

    # ── Style tab — colours ───────────────────────────────────────────────
    bull_bos_c   = str(params.get("bull_bos_color",   "#26a69a"))
    bear_bos_c   = str(params.get("bear_bos_color",   "#ef5350"))
    bull_choch_c = str(params.get("bull_choch_color", "#00bcd4"))
    bear_choch_c = str(params.get("bear_choch_color", "#ff9800"))
    hh_hl_col    = str(params.get("hh_hl_color",      "#26a69a"))
    ll_lh_col    = str(params.get("ll_lh_color",      "#ef5350"))

    if len(df) < lb + rb + 2:
        return {"events": [], "markers": []}

    times  = _get_times(df)
    highs  = df["high"].values.astype(float)
    lows   = df["low"].values.astype(float)
    closes = df["close"].values.astype(float)
    n      = len(highs)

    sh_bars, sl_bars = _detect_swings(highs, lows, lb, rb)
    high_labels, low_labels = _classify_swings(sh_bars, sl_bars, highs, lows)

    # ── Swing-point markers ───────────────────────────────────────────────
    markers: list[dict] = []

    if show_hh_ll:
        for bar, lbl in high_labels.items():
            if lbl == "HH":
                markers.append({
                    "time": _utc_unix(times[bar]), "position": "aboveBar",
                    "color": hh_hl_col, "shape": "circle", "size": 1, "text": "HH",
                })
        for bar, lbl in low_labels.items():
            if lbl == "LL":
                markers.append({
                    "time": _utc_unix(times[bar]), "position": "belowBar",
                    "color": ll_lh_col, "shape": "circle", "size": 1, "text": "LL",
                })

    if show_hl_lh:
        for bar, lbl in high_labels.items():
            if lbl == "LH":
                markers.append({
                    "time": _utc_unix(times[bar]), "position": "aboveBar",
                    "color": ll_lh_col, "shape": "circle", "size": 1, "text": "LH",
                })
        for bar, lbl in low_labels.items():
            if lbl == "HL":
                markers.append({
                    "time": _utc_unix(times[bar]), "position": "belowBar",
                    "color": hh_hl_col, "shape": "circle", "size": 1, "text": "HL",
                })

    # ── BOS / CHoCH events ────────────────────────────────────────────────
    events: list[dict] = []
    trend: str | None  = None

    # ── BEARISH: LH pattern in swing-highs ───────────────────────────────
    #   A Lower High means the up-swing has been broken.
    #   Relative anchor = nearest swing-LOW (LL or HL) left of the LH bar.
    #   Line goes from that LOW level rightward until the first candle that
    #   pierces it downward — that candle IS the new bearish BOS mark.
    for i in range(1, len(sh_bars)):
        prev_bar   = sh_bars[i - 1]
        curr_bar   = sh_bars[i]          # LH bar (current swing high)
        prev_level = float(highs[prev_bar])   # original swing-high level (legacy)

        if float(highs[curr_bar]) >= prev_level:
            continue                      # not a LH → skip

        # ── Legacy break-bar (kept for backward compat) ──────────────────
        legacy_break = None
        for b in range(prev_bar + 1, min(curr_bar + rb + 1, n)):
            if _breaks_below(b, prev_level, lows, closes, confirm):
                legacy_break = b
                break
        if legacy_break is None:
            legacy_break = curr_bar

        # ── Relative BOS anchor: nearest swing-LOW before LH bar ─────────
        ref_sl = _nearest_sl_before(sl_bars, curr_bar)
        if ref_sl is not None:
            rel_level = float(lows[ref_sl])
            stop      = _stop_bar_bear(ref_sl, rel_level, lows)
            from_b    = ref_sl
            to_b      = stop
            ev_level  = rel_level
        else:
            # Fallback: original behaviour (no swing-low found to the left)
            from_b   = prev_bar
            to_b     = legacy_break
            ev_level = prev_level

        ev_type = "ChoCh" if trend == "UP" else "BOS"
        trend   = "DOWN"
        color   = bear_bos_c if ev_type == "BOS" else bear_choch_c

        if (ev_type == "BOS" and show_bos) or (ev_type == "ChoCh" and show_choch):
            events.append({
                # ── primary fields (used by chart_server renderMSEvents) ──
                "type":            ev_type,
                "direction":       "DOWN",
                "level":           ev_level,
                "from_time":       _utc_unix(times[from_b]),
                "to_time":         _utc_unix(times[to_b]),
                "color":           color,
                # ── new fields ───────────────────────────────────────────
                "marker_position": "belowBar",              # bearish → below
                "break_time":      _utc_unix(times[to_b]),  # the new BOS mark
                # ── legacy fields (backward compat) ─────────────────────
                "legacy_level":     prev_level,
                "legacy_from_time": _utc_unix(times[prev_bar]),
                "legacy_to_time":   _utc_unix(times[legacy_break]),
            })

    # ── BULLISH: HL pattern in swing-lows ────────────────────────────────
    #   A Higher Low means the down-swing has been broken.
    #   Relative anchor = nearest swing-HIGH (HH or LH) left of the HL bar.
    #   Line goes from that HIGH level rightward until the first candle that
    #   pierces it upward — that candle IS the new bullish BOS mark.
    for i in range(1, len(sl_bars)):
        prev_bar   = sl_bars[i - 1]
        curr_bar   = sl_bars[i]          # HL bar (current swing low)
        prev_level = float(lows[prev_bar])    # original swing-low level (legacy)

        if float(lows[curr_bar]) <= prev_level:
            continue                      # not a HL → skip

        # ── Legacy break-bar ─────────────────────────────────────────────
        legacy_break = None
        for b in range(prev_bar + 1, min(curr_bar + rb + 1, n)):
            if _breaks_above(b, prev_level, highs, closes, confirm):
                legacy_break = b
                break
        if legacy_break is None:
            legacy_break = curr_bar

        # ── Relative BOS anchor: nearest swing-HIGH before HL bar ────────
        ref_sh = _nearest_sh_before(sh_bars, curr_bar)
        if ref_sh is not None:
            rel_level = float(highs[ref_sh])
            stop      = _stop_bar_bull(ref_sh, rel_level, highs)
            from_b    = ref_sh
            to_b      = stop
            ev_level  = rel_level
        else:
            from_b   = prev_bar
            to_b     = legacy_break
            ev_level = prev_level

        ev_type = "ChoCh" if trend == "DOWN" else "BOS"
        trend   = "UP"
        color   = bull_bos_c if ev_type == "BOS" else bull_choch_c

        if (ev_type == "BOS" and show_bos) or (ev_type == "ChoCh" and show_choch):
            events.append({
                # ── primary fields ────────────────────────────────────────
                "type":            ev_type,
                "direction":       "UP",
                "level":           ev_level,
                "from_time":       _utc_unix(times[from_b]),
                "to_time":         _utc_unix(times[to_b]),
                "color":           color,
                # ── new fields ────────────────────────────────────────────
                "marker_position": "aboveBar",               # bullish → above
                "break_time":      _utc_unix(times[to_b]),   # the new BOS mark
                # ── legacy fields ─────────────────────────────────────────
                "legacy_level":     prev_level,
                "legacy_from_time": _utc_unix(times[prev_bar]),
                "legacy_to_time":   _utc_unix(times[legacy_break]),
            })

    events.sort(key=lambda e: e["from_time"])
    markers.sort(key=lambda m: m["time"])
    return {"events": events, "markers": markers}


# ── Indicator registration ────────────────────────────────────────────────────

INDICATORS = {
    "BoS/ChoCh (Nephew_Sam_)": {
        "fn":    compute,
        "type":  "events",
        "pane":  "price",
        "color": "#26a69a",
        "params_def": {
            # ── Inputs tab ────────────────────────────────────────────────
            "pivot_lb": {
                "type": "int", "default": 5, "min": 1, "max": 50,
                "label": "Pivot lb", "tab": "inputs",
            },
            "pivot_rb": {
                "type": "int", "default": 5, "min": 1, "max": 50,
                "label": "Pivot rb", "tab": "inputs",
            },
            "breakout_confirm": {
                "type": "select", "default": "H/L", "options": ["H/L", "Close"],
                "label": "Breakout Confirmation", "tab": "inputs",
            },
            # ── Style tab — colours ───────────────────────────────────────
            "bull_bos_color": {
                "type": "color", "default": "#26a69a",
                "label": "Bull BOS line color", "tab": "style",
            },
            "bear_bos_color": {
                "type": "color", "default": "#ef5350",
                "label": "Bear BOS line color", "tab": "style",
            },
            "bull_choch_color": {
                "type": "color", "default": "#00bcd4",
                "label": "Bull ChoCh line color", "tab": "style",
            },
            "bear_choch_color": {
                "type": "color", "default": "#ff9800",
                "label": "Bear ChoCh line color", "tab": "style",
            },
            "hh_hl_color": {
                "type": "color", "default": "#26a69a",
                "label": "HH / HL marker color", "tab": "style",
            },
            "ll_lh_color": {
                "type": "color", "default": "#ef5350",
                "label": "LL / LH marker color", "tab": "style",
            },
            # ── Visibility tab — checkboxes ───────────────────────────────
            "show_hh_ll": {
                "type": "bool", "default": True,
                "label": "Show HH / LL", "tab": "visibility",
            },
            "show_hl_lh": {
                "type": "bool", "default": True,
                "label": "Show HL / LH", "tab": "visibility",
            },
            "show_bos": {
                "type": "bool", "default": True,
                "label": "Show BOS", "tab": "visibility",
            },
            "show_choch": {
                "type": "bool", "default": True,
                "label": "Show ChoCh", "tab": "visibility",
            },
        },
        "series_def": [],
    }
}