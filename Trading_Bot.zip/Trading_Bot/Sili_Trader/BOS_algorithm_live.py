import os
import dotenv
import requests
import pandas as pd
from datetime import datetime
from user_indicators.sam_market_structure import compute


# ── CONFIG ─────────────────────────────────────────────
API_KEY = os.getenv("API_KEY")
ACCOUNT_ID = os.getenv("ACCOUNT_ID")

INSTRUMENT = "GBP_USD"
GRANULARITY = "H4"
COUNT = 200

BASE_URL = "https://api-fxpractice.oanda.com/v3"

headers = {
    "Authorization": f"Bearer {API_KEY}"
}


# ── FETCH DATA FROM OANDA ─────────────────────────────
def fetch_candles(instrument, granularity, count=200):
    url = f"{BASE_URL}/instruments/{instrument}/candles"
    params = {
        "granularity": granularity,
        "count": count,
        "price": "M"  # mid price
    }

    r = requests.get(url, headers=headers, params=params)
    r.raise_for_status()

    data = r.json()["candles"]

    rows = []
    for c in data:
        if not c["complete"]:
            continue

        rows.append({
            "time": pd.to_datetime(c["time"]),
            "open": float(c["mid"]["o"]),
            "high": float(c["mid"]["h"]),
            "low": float(c["mid"]["l"]),
            "close": float(c["mid"]["c"]),
            "volume": int(c["volume"])
        })

    df = pd.DataFrame(rows)
    df.set_index("time", inplace=True)

    return df


# ── FEATURE ENGINEERING (MATCH YOUR BACKTEST FORMAT) ──
def add_features(df):
    df["candle_type"] = "Neutral"
    df.loc[df["close"] > df["open"], "candle_type"] = "Bullish"
    df.loc[df["close"] < df["open"], "candle_type"] = "Bearish"

    df["body_size"] = (df["close"] - df["open"]).abs()
    df["upper_wick"] = df["high"] - df[["open", "close"]].max(axis=1)
    df["lower_wick"] = df[["open", "close"]].min(axis=1) - df["low"]

    return df


# ── MAIN ──────────────────────────────────────────────
def run():
    df = fetch_candles(INSTRUMENT, GRANULARITY, COUNT)
    df = add_features(df)
    
    custom_params = {
    "pivot_lb": 5,   # Change this to your desired Left Bars (e.g., 3)
    "pivot_rb": 5,   # Change this to your desired Right Bars (e.g., 3)
    "breakout_confirm": "H/L", # Keep default or change to "Close"
    "show_bos": True,
    "show_choch": False,
    "show_hh_ll": False, # Optional: Hide swing markers to clean up print
    "show_hl_lh": False,
    }

    result = compute(df, params = custom_params)

    events = result["events"]

    print("\n===== BOS / CHoCH EVENTS =====\n")
    print(f"Settings Used: LB={custom_params['pivot_lb']}, RB={custom_params['pivot_rb']}\n")


    for e in events:
        direction = e["direction"]
        ev_type = e["type"]
        level = e["level"]

        time_from = datetime.utcfromtimestamp(e["from_time"])
        time_to = datetime.utcfromtimestamp(e["to_time"])
        break_time = datetime.utcfromtimestamp(e["break_time"])

        print(f"""
{ev_type} ({direction})
Level: {level}
From:  {time_from}
To:    {time_to}
Break: {break_time}
-----------------------------------
""")

    print(f"\nTotal events detected: {len(events)}\n")


if __name__ == "__main__":
    run()