import pandas as pd
from strategy import analyze_trend_in_range

df = pd.read_csv(
    "/run/media/solace/ABBA-2E35/My_Code/Sili_Trader/forex_data/EUR_USD.csv",
    parse_dates=["time"],
    index_col="time"
)

trend = analyze_trend_in_range(
    df=df,
    start_time="2026-04-01 12:00",
    end_time="2026-04-03 12:00",
    timeframe="M15",
    plot=True
)
print(trend)
