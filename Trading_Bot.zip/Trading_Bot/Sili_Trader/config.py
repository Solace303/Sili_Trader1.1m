"""Project configuration for Sili_Trader."""

import os
from dotenv import load_dotenv

# -----------------------------------------------------------------------------
# OANDA API configuration
# -----------------------------------------------------------------------------
OANDA_API_KEY     = os.getenv("API_KEY")
OANDA_ACCOUNT_ID  = os.getenv("ACCOUNT_ID")
OANDA_ENVIRONMENT = "practice"

# ================================
# ▶  MODE SWITCH  ◀
#   False → live trading via OANDA
#   True  → backtest replay from CSV
# ================================
BACKTEST_MODE = False

# ================================
# BACKTEST SETTINGS
# (only used when BACKTEST_MODE = True)
# ================================
BACKTEST_DATA_DIR = "/run/media/solace/ABBA-2E35/My_Code/Sili_Trader/forex_data"
CHART_CANDLE_LIMIT = 120   # candles sent to the browser per request

# ================================
# MULTI-PAIR CONFIGURATION
# ================================
INSTRUMENTS = [
    "EUR_USD", # Major
    "GBP_USD", # Major
    "USD_JPY", # Major
    "USD_CAD", # Major (Oil Proxy)
    "USD_CHF", # Safe Haven / Inverse EUR
    "EUR_GBP", # Euro Cross
    "EUR_JPY", # Euro Cross
    "GBP_JPY", # High Volatility
    "AUD_JPY", # Risk Sentiment
    "NZD_JPY", # Carry Trade / Volatility
    "AUD_CAD", # Cross-Commodity (Gold/Oil proxy)
]



CRT_TIMEFRAMES = {
    "rdc_tf":         "H4",
    "manipulation_tf":"H1",
    "execution_tf":   "M15",
}

LOOPBACK_CANDLES = {
    "rdc_tf":         3,
    "manipulation_tf":3,
    "execution_tf":   3,
    "test_tf":        500,
}

# ================================
# BACKTEST LOOP SPEED CONFIG IN SECONDS
# ================================
# TIMEFRAME RELATIVITY SHOULD BE IN THE RATIO
#H4:H1:M15 = 4:1:0.25
BACKTEST_TIMEFRAME_RELATIVITY_SECONDS = {
    "H4":  16,
    "H1":  4,
    "M15": 1,
    "15M": 1,
}

# ================================
# TREND DETECTION SETTINGS
# ================================
TREND_CONFIG = {
    "reference_timeframe":  "4h",
    "threshold_mode":       "volatility",
    "volatility_multiplier":2.0,
    "volatility_window":    50,
    "minimum_threshold":    0.0001,
}



# ================================================
# WICK-TO-BODY RATIO REFERENCE TABLE
# ================================================
"""
Ratio (from config) | What it requires                          | Body as % of total candle range | Strength in your strategy
--------------------|-------------------------------------------|---------------------------------|----------------------------
0.5                 | Wick ≥ 50% of body size                   | ~67% (quite large body)         | Very easy to pass
1.0                 | Wick = body size                          | 50%                             | Moderate
2.0                 | Wick = 2× body size                       | 33%                             | Strong
3.0                 | Wick = 3× body size                       | 25%                             | Very strong
"""

# ================================================
# YOUR ACTUAL CONFIG (update the values whenever you want)
# ================================================

WICK_REJECTION_CONFIG = {
    "lower_wick_to_body_threshold": 3.0,   # bullish rejection (lower wick / body)
    "upper_wick_to_body_threshold": 3.0,   # bearish rejection (upper wick / body)
}

# ================================
# RISK MANAGEMENT CONFIG
# ================================
RISK_CONFIG = {
    "risk_per_trade": 0.01,   # 1% default
    "min_risk": 0.005,        # 0.5% after losses
    "recovery_trigger": 0.25  # 25% recovery threshold
}

LOT_SIZE_CONFIG = {
    "standard": 100000,
    "mini": 10000,
    "micro": 1000,
    "nano": 100
}