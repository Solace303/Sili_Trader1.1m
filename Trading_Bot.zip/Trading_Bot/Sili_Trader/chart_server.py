"""chart_server.py — Sili_Trader backtest chart server  (v5)

Run:
    uvicorn chart_server:app --host 0.0.0.0 --port 8000

New in v5
---------
• Transport bar — date-range pickers, ▶/⏸, ⏮/⏭ step buttons, speed selector.
• /api/date_range         — returns min/max dates available across all CSV files.
• /api/playback/play|pause|forward|rewind|speed|daterange  — transport API.
• /api/status now includes playing + rewind_version so the browser can sync.
• When rewind_version changes the browser clears initializedSeries + MS event
  series, forcing a full setData() re-render of every chart panel.
"""

from __future__ import annotations
import importlib.util, json, math, os, threading
from contextlib import asynccontextmanager
from typing import Optional

import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse

import backtest as _bt
from backtest import candle_store, playback, push_candles, _norm
from main import run as _run_backtest
from config import CRT_TIMEFRAMES, CHART_CANDLE_LIMIT, BACKTEST_MODE


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    if BACKTEST_MODE:
        threading.Thread(target=_run_backtest, daemon=True, name="backtest-loop").start()
    yield


app = FastAPI(title="Sili_Trader", version="5.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET"], allow_headers=["*"])

DISPLAY_TIMEFRAMES = list(CRT_TIMEFRAMES.values())


# ── Helpers ───────────────────────────────────────────────────────────────────

def _df_to_ohlcv(df) -> list[dict]:
    records = []
    for ts, row in df.iterrows():
        try:
            if any(math.isnan(v) for v in [row["open"], row["high"], row["low"], row["close"]]):
                continue
        except TypeError:
            continue
        records.append({
            "t": ts.isoformat(),
            "o": round(float(row["open"]),  5),
            "h": round(float(row["high"]),  5),
            "l": round(float(row["low"]),   5),
            "c": round(float(row["close"]), 5),
            "v": int(row.get("volume", 0)),
            "type": str(row.get("candle_type", "")),
        })
    return records


def _load_user_indicators() -> dict:
    folder = os.path.join(os.path.dirname(__file__), "user_indicators")
    if not os.path.exists(folder):
        os.makedirs(folder)
        return {}
    result = {}
    for fname in os.listdir(folder):
        if not fname.endswith(".py") or fname == "__init__.py":
            continue
        path = os.path.join(folder, fname)
        try:
            spec = importlib.util.spec_from_file_location(fname[:-3], path)
            mod  = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            for k, v in getattr(mod, "INDICATORS", {}).items():
                if callable(v):
                    result[k] = {"fn": v, "type": "line", "color": "#e2e8f0",
                                 "pane": "sub", "series_def": [{"name": "Value", "color": "#e2e8f0"}]}
                elif isinstance(v, dict):
                    if "series_def" not in v:
                        v["series_def"] = [{"name": "Value", "color": v.get("color", "#e2e8f0")}]
                    result[k] = v
        except Exception as e:
            print(f"[IND] Error loading {fname}: {e}")
            import traceback; traceback.print_exc()
    return result


def _all_indicators() -> dict:
    return _load_user_indicators()


# ── Core API ──────────────────────────────────────────────────────────────────

@app.get("/api/pairs")
def get_pairs():
    result = []
    for pair in candle_store.pairs():
        cursor = candle_store.cursors.get(pair, 0)
        total  = candle_store.lengths.get(pair, 1)
        result.append({
            "pair": pair, "cursor": cursor, "total": total,
            "progress_pct": round(cursor / max(total - 1, 1) * 100, 1),
            "timeframes": candle_store.timeframes(pair),
        })
    return JSONResponse(result)


@app.get("/api/candles/{pair}/{tf}")
def get_candles(pair: str, tf: str):
    tf_norm = _norm(tf)
    df = candle_store.get(pair, tf_norm)
    if df is None:
        raise HTTPException(status_code=404, detail=f"No data yet for {pair}/{tf_norm}.")
    candles = _df_to_ohlcv(df)
    return JSONResponse({"pair": pair, "timeframe": tf_norm, "count": len(candles), "candles": candles})


@app.get("/api/signal/{pair}")
def get_signal(pair: str):
    sig = candle_store.get_signal(pair)
    if sig is None:
        return JSONResponse({"pair": pair, "signal": None})
    out = {}
    for k, v in sig.items():
        if hasattr(v, "isoformat"): out[k] = v.isoformat()
        elif isinstance(v, float) and math.isnan(v): out[k] = None
        else: out[k] = v
    return JSONResponse({"pair": pair, "signal": out})


@app.get("/api/status")
def get_status():
    pairs    = candle_store.pairs()
    finished = sum(1 for p in pairs if candle_store.cursors.get(p, 0) >= candle_store.lengths.get(p, 1) - 1)
    return JSONResponse({
        "pairs_loaded":   len(pairs),
        "pairs_finished": finished,
        "running":        finished < len(pairs) or len(pairs) == 0,
        "playing":        playback.playing,
        "speed":          playback.speed,
        "rewind_version": candle_store.rewind_version,
    })


# ── Playback transport API ────────────────────────────────────────────────────

@app.get("/api/date_range")
def get_date_range():
    """Return the min/max dates available across all loaded CSV files."""
    f = _bt.current_fetcher
    if f is None:
        return JSONResponse({"start": None, "end": None})
    return JSONResponse(f.available_date_range())


@app.get("/api/playback/play")
def transport_play():
    playback.play()
    return JSONResponse({"ok": True, "playing": True})


@app.get("/api/playback/pause")
def transport_pause():
    playback.pause()
    return JSONResponse({"ok": True, "playing": False})


@app.get("/api/playback/forward")
def transport_forward(steps: int = Query(default=1, ge=1, le=100)):
    """Advance the replay by `steps` candles (default 1)."""
    playback.step_forward(steps)
    return JSONResponse({"ok": True, "steps": steps})


@app.get("/api/playback/rewind")
def transport_rewind(steps: int = Query(default=1, ge=1, le=100)):
    """Rewind the replay by `steps` candles (default 1)."""
    playback.step_rewind(steps)
    return JSONResponse({"ok": True, "steps": steps})


@app.get("/api/playback/speed")
def transport_speed(v: float = Query(default=1.0)):
    """Set playback speed multiplier (0.125 – 64)."""
    playback.set_speed(v)
    return JSONResponse({"ok": True, "speed": playback.speed})


@app.get("/api/playback/daterange")
def transport_daterange(start: str = Query(default=None), end: str = Query(default=None)):
    """Apply a new date range and reset the replay cursor."""
    try:
        start_ts = pd.Timestamp(start + "Z") if start and not start.endswith("Z") else (pd.Timestamp(start) if start else None)
        end_ts   = pd.Timestamp(end   + "Z") if end   and not end.endswith("Z")   else (pd.Timestamp(end)   if end   else None)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid date: {e}")

    playback.set_date_range(start_ts, end_ts)
    playback.pause()

    f = _bt.current_fetcher
    if f is not None:
        f.apply_date_range(start_ts, end_ts)
        # Push the first visible slice so the browser has something to show
        for pair in f.market_data:
            if not f.pair_finished(pair):
                f.advance_pair(pair)
        for pair in f.market_data:
            push_candles(pair, f)
        candle_store.rewind_version += 1     # tells browser to reinit charts

    return JSONResponse({"ok": True, "rewind_version": candle_store.rewind_version})


# ── Indicator API ─────────────────────────────────────────────────────────────

@app.get("/api/indicators")
def list_indicators():
    result = []
    for name, meta in _all_indicators().items():
        ind_type = meta.get("type", "line")
        if ind_type != "events" and len(meta.get("series_def", [])) > 1:
            ind_type = "multi"
        result.append({
            "name":       name,
            "type":       ind_type,
            "color":      meta.get("color", "#e2e8f0"),
            "pane":       meta.get("pane", "sub"),
            "params_def": meta.get("params_def", {}),
            "series_def": meta.get("series_def", []),
        })
    return JSONResponse(result)


@app.get("/api/indicators/{pair}/{tf}/{indicator_name:path}")
def get_indicator(pair: str, tf: str, indicator_name: str, params: str = None):
    tf_norm = _norm(tf)
    df = candle_store.get(pair, tf_norm)
    if df is None:
        raise HTTPException(status_code=404, detail=f"No candle data for {pair}/{tf_norm}.")
    ind = _all_indicators()
    if indicator_name not in ind:
        raise HTTPException(status_code=404, detail=f"Unknown indicator: {indicator_name}.")
    try:
        meta        = ind[indicator_name]
        params_dict = json.loads(params) if params else None
        raw         = meta["fn"](df, params_dict) if params_dict else meta["fn"](df)

        if isinstance(raw, dict) and "events" in raw:
            return JSONResponse({
                "indicator": indicator_name, "pair": pair, "timeframe": tf_norm,
                "type": "events", "pane": meta.get("pane", "price"),
                "events": raw["events"], "markers": raw.get("markers", []),
            })

        series_data = {"main": raw} if isinstance(raw, list) else (raw if isinstance(raw, dict) else (_ for _ in ()).throw(ValueError("bad return")))
        response_series = []
        series_defs = meta.get("series_def", [{"name": "main", "color": meta.get("color", "#fff")}])
        for s_def in series_defs:
            s_name = s_def.get("name", "main"); s_color = s_def.get("color", "#fff")
            fmt = []
            for pt in series_data.get(s_name, []):
                ts_val = pt.get("t")
                if ts_val is None: continue
                try:
                    ts_obj = pd.Timestamp(ts_val)
                    if ts_obj.tzinfo is None: ts_obj = ts_obj.tz_localize("UTC")
                    else:                     ts_obj = ts_obj.tz_convert("UTC")
                    point = {"time": int(ts_obj.timestamp()), "value": float(pt["v"]) if pt.get("v") is not None else None}
                    for k in ("shape", "text", "color"):
                        if k in pt: point[k] = pt[k]
                    fmt.append(point)
                except Exception: continue
            response_series.append({"name": s_name, "color": s_color,
                                     "style": s_def.get("style", "Solid"), "data": fmt})
        return JSONResponse({
            "indicator": indicator_name, "pair": pair, "timeframe": tf_norm,
            "type": "multi" if len(response_series) > 1 else "line",
            "pane": meta.get("pane", "sub"), "series": response_series,
        })
    except Exception as e:
        import traceback; traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Indicator error: {e}")


# ── Browser UI ────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
def index():
    return HTMLResponse(content=_load_html(), status_code=200)


HTML_TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "chart_server.html")


def _load_html() -> str:
    with open(HTML_TEMPLATE_PATH, "r", encoding="utf-8") as f:
        return f.read()
