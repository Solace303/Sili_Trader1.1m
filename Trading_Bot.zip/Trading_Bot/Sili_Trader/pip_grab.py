import oandapyV20
import oandapyV20.endpoints.accounts as accounts
from config import (
    OANDA_ACCOUNT_ID, OANDA_API_KEY, OANDA_ENVIRONMENT,
    INSTRUMENTS, BACKTEST_MODE, CRT_TIMEFRAMES
)

class PipManager:
    def __init__(self):
        # Initializing Oanda API Client
        self.client = oandapyV20.API(
            access_token=OANDA_API_KEY,
            environment=OANDA_ENVIRONMENT
        )
        self.account_id = OANDA_ACCOUNT_ID

    def get_pip_decimal(self, instrument):
        """Fetches the pip decimal (e.g., 0.0001 or 0.01) for any pair."""
        try:
            params = {"instruments": instrument}
            r = accounts.AccountInstruments(accountID=self.account_id, params=params)
            self.client.request(r)
            
            # The 'instruments' key returns a list; we grab the first item
            instruments_data = r.response.get('instruments', [])
            
            if not instruments_data:
                print(f"Instrument {instrument} not found.")
                return None
                
            pip_location = instruments_data[0].get('pipLocation')
            
            # 10 to the power of pipLocation (e.g., 10^-4 = 0.0001)
            return 10 ** pip_location
            
        except Exception as e:
            print(f"Error fetching pip decimal: {e}")
            return None

# --- Usage ---
if __name__ == "__main__":
    manager = PipManager()
    pair = "AUD_USD"
    decimal = manager.get_pip_decimal(pair)
    
    if decimal:
        print(f"Pair: {pair}")
        print(f"Pip Decimal: {decimal:.5f}")
