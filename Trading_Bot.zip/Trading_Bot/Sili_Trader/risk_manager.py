import logging
import oandapyV20

from config import (
    OANDA_API_KEY,
    OANDA_ENVIRONMENT,
    LOT_SIZE_CONFIG,
)

logger = logging.getLogger(__name__)


class RiskManager:
    def __init__(self, fetcher, journal):
        self.fetcher = fetcher
        self.journal = journal

        self.client = oandapyV20.API(
            access_token=OANDA_API_KEY,
            environment=OANDA_ENVIRONMENT,
        )

    # ---------------------------------------
    # PRICE
    # ---------------------------------------
    def _mid(self, instrument):
        return float(self.fetcher.get_current_price(instrument))

    # ---------------------------------------
    # EXCHANGE RATE (SAFE)
    # ---------------------------------------
    def _exchange_rate(self, from_ccy, to_ccy):
        if from_ccy == to_ccy:
            return 1.0

        try:
            return self._mid(f"{from_ccy}_{to_ccy}")
        except:
            try:
                return 1 / self._mid(f"{to_ccy}_{from_ccy}")
            except:
                # fallback via USD
                a = self._mid(f"{from_ccy}_USD")
                b = self._mid(f"USD_{to_ccy}")
                return a * b

    # ---------------------------------------
    # PIP VALUE
    # ---------------------------------------
    def calculate_pip_value(self, instrument, account_currency, lot_type="standard"):
        base, quote = instrument.split("_")

        pip_unit = 10 ** self.fetcher.get_pip_location(instrument)
        contract_size = LOT_SIZE_CONFIG[lot_type]

        pip_value_quote = pip_unit * contract_size
        rate = self._exchange_rate(quote, account_currency)

        return pip_value_quote * rate

    # ---------------------------------------
    # LOT SIZE
    # ---------------------------------------
    def calculate_lot_size(self, instrument, entry, stop, lot_type="standard"):
        account = self.fetcher.get_account_summary()

        balance = account["balance"]
        currency = account["currency"]

        # ✅ FROM JOURNAL
        risk_percent = self.journal.get_pair_risk(instrument)
        risk_amount = balance * risk_percent

        pip_unit = 10 ** self.fetcher.get_pip_location(instrument)
        sl_pips = abs(entry - stop) / pip_unit

        pip_value = self.calculate_pip_value(instrument, currency, lot_type)

        if sl_pips == 0:
            return 0

        lot_size = risk_amount / (sl_pips * pip_value)

        logger.info(
            f"[RISK] {instrument} | risk={risk_percent:.4f} | "
            f"balance={balance} | lot={lot_size}"
        )

        return round(lot_size, 2)

    # ---------------------------------------
    # UNITS
    # ---------------------------------------
    def calculate_units(self, lot_size, lot_type="standard"):
        return int(lot_size * LOT_SIZE_CONFIG[lot_type])

    # ---------------------------------------
    # NEW: RISK AMOUNT
    # ---------------------------------------
    def calculate_risk_amount(self, instrument):
        account = self.fetcher.get_account_summary()
        balance = account["balance"]

        risk_percent = self.journal.get_pair_risk(instrument)
        return balance * risk_percent

    # ---------------------------------------
    # NEW: POTENTIAL PROFIT
    # ---------------------------------------
    def calculate_potential_profit(self, entry, take_profit, position_size, trade_type):

        if trade_type == "BUY":
            price_diff = take_profit - entry

        elif trade_type == "SELL":
            price_diff = entry - take_profit

        else:
            raise ValueError("trade_type must be BUY or SELL")

        return price_diff * position_size

    # ---------------------------------------
    # PIPELINE (UPDATED)
    # ---------------------------------------
    def compute_trade_parameters(
        self,
        instrument,
        entry,
        stop,
        take_profit,
        trade_type,
        lot_type="standard"
    ):
        # -------------------------
        # position sizing (existing logic)
        # -------------------------
        lot_size = self.calculate_lot_size(instrument, entry, stop, lot_type)
        units = self.calculate_units(lot_size, lot_type)

        # -------------------------
        # risk amount
        # -------------------------
        risk_amount = self.calculate_risk_amount(instrument)

        stop_distance = abs(entry - stop)
        if stop_distance == 0:
            return None

        # position size for profit calc
        position_size = units

        # -------------------------
        # potential profit
        # -------------------------
        potential_profit = self.calculate_potential_profit(
            entry,
            take_profit,
            position_size,
            trade_type
        )

        if risk_amount == 0:
            return None

        reward_ratio = potential_profit / risk_amount

        # 🚫 enforce R:R >= 1
        if reward_ratio < 1.0:
            logger.info(f"[FILTER] Trade rejected (R:R < 1) → {reward_ratio:.2f}")
            return None

        rr_ratio = f"1:{round(reward_ratio, 2)}"

        # -------------------------
        # FINAL RETURN
        # -------------------------
        return {
            "lot_size": lot_size,
            "units": units,
            "risk_percent": self.journal.get_pair_risk(instrument),

            # ✅ NEW
            "trade_type": trade_type,
            "entry_price": entry,
            "stop_loss": stop,
            "take_profit": take_profit,
            "risk_amount": risk_amount,
            "potential_profit": potential_profit,
            "risk_reward_ratio": rr_ratio
        }