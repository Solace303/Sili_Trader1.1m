import csv
import os
import oandapyV20
import oandapyV20.endpoints.transactions as trans
from datetime import datetime

from config import (
    OANDA_API_KEY,
    OANDA_ACCOUNT_ID,
    OANDA_ENVIRONMENT,
    RISK_CONFIG
)


class TradeJournal:
    def __init__(self, fetcher, filename="trade_journal.csv"):
        self.fetcher = fetcher
        self.filename = filename

        self.client = oandapyV20.API(
            access_token=OANDA_API_KEY,
            environment=OANDA_ENVIRONMENT
        )

        # --- STATE ---
        self.loss_streaks = {}
        self.drawdown_start_balance = {}
        self.current_risk_map = {}
        self.last_transaction_id = "0"

        self._initialize_file()
        self._load_state()

    # ---------------------------------------
    # INIT FILE
    # ---------------------------------------
    def _initialize_file(self):
        if not os.path.exists(self.filename) or os.path.getsize(self.filename) == 0:
            with open(self.filename, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "id",
                    "timestamp",
                    "pair",
                    "side",
                    "entry_price",
                    "exit_price",
                    "pl",
                    "balance",
                    "outcome",
                    "streak",
                    "drawdown_start_balance",
                    "next_risk_per_trade"
                ])

    # ---------------------------------------
    # UPDATE
    # ---------------------------------------
    def update(self):
        transactions, last_id = self._fetch_transactions()

        if not transactions:
            self.last_transaction_id = last_id
            return

        with open(self.filename, "a", newline="") as f:
            writer = csv.writer(f)

            for txn in transactions:
                txn_id = str(txn.get("id"))

                if int(txn_id) <= int(self.last_transaction_id):
                    continue

                if txn.get("type") != "ORDER_FILL":
                    continue

                pl = float(txn.get("pl", 0))
                if pl == 0:
                    continue

                pair = txn["instrument"]
                balance = float(txn["accountBalance"])

                timestamp = datetime.fromisoformat(
                    txn["time"].replace("Z", "")
                )

                units = float(txn["units"])
                side = "SELL" if units > 0 else "BUY"

                exit_price = float(txn["price"])
                entry_price = exit_price

                if "tradesClosed" in txn:
                    try:
                        entry_price = float(txn["tradesClosed"][0]["price"])
                    except:
                        pass

                outcome, streak = self._update_streak(pair, pl, balance)

                # ✅ always take updated risk
                next_risk = self.current_risk_map[pair]

                writer.writerow([
                    txn_id,
                    timestamp,
                    pair,
                    side,
                    entry_price,
                    exit_price,
                    pl,
                    balance,
                    outcome,
                    streak,
                    self.drawdown_start_balance.get(pair),
                    next_risk
                ])

        self.last_transaction_id = last_id

    # ---------------------------------------
    # FETCH TRANSACTIONS
    # ---------------------------------------
    def _fetch_transactions(self):
        try:
            r = trans.TransactionsSinceID(
                accountID=OANDA_ACCOUNT_ID,
                params={"id": self.last_transaction_id}
            )

            self.client.request(r)

            return (
                r.response.get("transactions", []),
                str(r.response.get("lastTransactionID", self.last_transaction_id))
            )

        except Exception as e:
            print(f"[FETCH ERROR] {e}")
            return [], self.last_transaction_id

    # ---------------------------------------
    # LOAD STATE FROM CSV
    # ---------------------------------------
    def _load_state(self):
        if not os.path.exists(self.filename):
            return

        with open(self.filename, "r") as f:
            reader = csv.DictReader(f)

            for row in reader:
                try:
                    txn_id = row["id"]
                    pair = row["pair"]

                    self.last_transaction_id = max(
                        self.last_transaction_id,
                        txn_id,
                        key=int
                    )

                    # ✅ restore state
                    self.loss_streaks[pair] = int(row["streak"])

                    risk_val = float(row["next_risk_per_trade"])
                    self.current_risk_map[pair] = risk_val

                    if row["drawdown_start_balance"]:
                        self.drawdown_start_balance[pair] = float(
                            row["drawdown_start_balance"]
                        )

                except:
                    continue

    # ---------------------------------------
    # STREAK LOGIC
    # ---------------------------------------
    def _update_streak(self, pair, pl, balance):

        if pair not in self.loss_streaks:
            self.loss_streaks[pair] = 0
            self.current_risk_map[pair] = RISK_CONFIG["risk_per_trade"]

        # -------- LOSS --------
        if pl < 0:
            self.loss_streaks[pair] += 1

            if pair not in self.drawdown_start_balance:
                self.drawdown_start_balance[pair] = balance

            # halve risk
            self.current_risk_map[pair] *= 0.5

            return "LOSS", self.loss_streaks[pair]

        # -------- WIN --------
        else:
            if pair in self.drawdown_start_balance:
                dd_balance = self.drawdown_start_balance[pair]
                recovery = balance - dd_balance

                if recovery >= dd_balance * RISK_CONFIG["recovery_trigger"]:
                    self.loss_streaks[pair] = 0
                    self.current_risk_map[pair] = RISK_CONFIG["risk_per_trade"]
                    del self.drawdown_start_balance[pair]

            return "WIN", self.loss_streaks[pair]

    # ---------------------------------------
    # ✅ UPDATED: GET RISK (CSV-FIRST)
    # ---------------------------------------
    def get_pair_risk(self, pair):
        """
        Always returns latest risk.
        Priority:
        1. Memory (fast, already synced)
        2. CSV fallback (safety)
        """

        # ✅ fast path
        if pair in self.current_risk_map:
            return self.current_risk_map[pair]

        # ⚠️ fallback to CSV
        if not os.path.exists(self.filename):
            return RISK_CONFIG["risk_per_trade"]

        try:
            with open(self.filename, "r") as f:
                reader = list(csv.DictReader(f))

                for row in reversed(reader):
                    if row["pair"] == pair:
                        risk_val = float(row["next_risk_per_trade"])

                        # sync back into memory
                        self.current_risk_map[pair] = risk_val
                        return risk_val

        except:
            pass

        return RISK_CONFIG["risk_per_trade"]

    # ---------------------------------------
    # GET STREAK
    # ---------------------------------------
    def get_current_streak(self, pair):
        return self.loss_streaks.get(pair, 0)