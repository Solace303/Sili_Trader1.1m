"""backtest.py — Sili_Trader backtest infrastructure."""

from __future__ import annotations
import os, threading, logging
from pathlib import Path
from typing import Dict, Optional

import pandas as pd
from config import BACKTEST_DATA_DIR, CHART_CANDLE_LIMIT, CRT_TIMEFRAMES

BACKTEST_STATE_FILE = os.path.join(BACKTEST_DATA_DIR, "backtest_watcher_state.json")
BACKTEST_LOG_FILE   = os.path.join(BACKTEST_DATA_DIR, "backtest_log.log")

OANDA_TO_PANDAS: Dict[str, str] = {
    "M1": "1min", "M5": "5min", "M15": "15min",
    "H1": "1h",   "H4": "4h",   "D":   "1D",
}
TF_SECONDS: Dict[str, int] = {
    "M1": 60, "M5": 300, "M15": 900,
    "H1": 3600, "H4": 14400, "D": 86400,
}
DISPLAY_TIMEFRAMES = list(CRT_TIMEFRAMES.values())


def _norm(tf: str) -> str:
    s = str(tf).strip().upper()
    aliases = {
        "15M": "M15",
        "1H": "H1",
        "4H": "H4",
        "1D": "D",
    }
    return aliases.get(s, s)


# ── PlaybackController ────────────────────────────────────────────────────────

class PlaybackController:
    """Thread-safe transport controller shared between the backtest loop and
    the HTTP API endpoints in chart_server.py."""

    def __init__(self):
        self._lock         = threading.Lock()
        self.playing       = False          # False = start paused
        self.speed         = 1.0            # sleep-time divider
        self._fwd_steps    = 0              # pending step-forward count
        self._rwd_steps    = 0              # pending step-rewind count
        self.start_ts: Optional[pd.Timestamp] = None
        self.end_ts:   Optional[pd.Timestamp] = None
        # Event wakes the loop when paused (play, step-fwd, step-rwd, date-apply)
        self._wake = threading.Event()

    # ── public API called by HTTP handlers ───────────────────────────────────
    def play(self):
        with self._lock:
            self.playing = True
        self._wake.set()

    def pause(self):
        with self._lock:
            self.playing = False
        self._wake.clear()

    def step_forward(self, n: int = 1):
        with self._lock:
            self._fwd_steps += n
        self._wake.set()

    def step_rewind(self, n: int = 1):
        with self._lock:
            self._rwd_steps += n
        self._wake.set()

    def set_speed(self, v: float):
        with self._lock:
            self.speed = max(0.125, min(64.0, float(v)))

    def set_date_range(self, start=None, end=None):
        with self._lock:
            self.start_ts = pd.Timestamp(start).tz_localize("UTC") if start and pd.Timestamp(start).tzinfo is None else (pd.Timestamp(start).tz_convert("UTC") if start else None)
            self.end_ts   = pd.Timestamp(end).tz_localize("UTC")   if end   and pd.Timestamp(end).tzinfo   is None else (pd.Timestamp(end).tz_convert("UTC")   if end   else None)

    # ── called by the loop to consume pending actions ────────────────────────
    def consume_steps(self):
        with self._lock:
            fwd = self._fwd_steps
            rwd = self._rwd_steps
            self._fwd_steps = 0
            self._rwd_steps = 0
            playing = self.playing
        return fwd, rwd, playing

    def wait(self, timeout: float = 0.2):
        """Block until woken (play, step, etc.)."""
        self._wake.wait(timeout=timeout)
        # If still paused after wake, re-clear so next wait blocks again
        with self._lock:
            if not self.playing and self._fwd_steps == 0 and self._rwd_steps == 0:
                self._wake.clear()


# Module-level singletons
playback: PlaybackController = PlaybackController()
current_fetcher: Optional["BacktestCSVFetcher"] = None   # set by main.py


# ── CandleStore ───────────────────────────────────────────────────────────────

class CandleStore:
    def __init__(self):
        self._lock             = threading.RLock()
        self._data:            Dict[str, Dict[str, pd.DataFrame]] = {}
        self.cursors:          Dict[str, int]  = {}
        self.lengths:          Dict[str, int]  = {}
        self.active_signals:   Dict[str, dict] = {}
        self.rewind_version:   int             = 0     # incremented on rewind

    def update(self, pair: str, tf: str, df: pd.DataFrame):
        with self._lock:
            self._data.setdefault(pair, {})[tf] = df.copy()

    def get(self, pair: str, tf: str) -> Optional[pd.DataFrame]:
        with self._lock:
            return self._data.get(pair, {}).get(tf)

    def pairs(self) -> list:
        with self._lock:
            return list(self._data.keys())

    def timeframes(self, pair: str) -> list:
        with self._lock:
            return list(self._data.get(pair, {}).keys())

    def set_signal(self, pair: str, info: dict):
        with self._lock:
            self.active_signals[pair] = info

    def get_signal(self, pair: str) -> Optional[dict]:
        with self._lock:
            return self.active_signals.get(pair)


candle_store = CandleStore()


# ── SimulatedTradeExecutor ────────────────────────────────────────────────────

class SimulatedTradeExecutor:
    def __init__(self):
        self._lock = threading.Lock()
        self.order_events: list = []

    def place_market_order(self, instrument, units, stop_loss=None, take_profit=None):
        rec = {"instrument": instrument, "units": units,
               "sl": stop_loss, "tp": take_profit,
               "timestamp": pd.Timestamp.now(tz="UTC")}
        with self._lock:
            self.order_events.append(rec)
        return rec

    def buy(self, instrument, units, stop_loss=None, take_profit=None):
        logging.info(f"[SIM BUY]  {instrument}  units={abs(units)}  sl={stop_loss}  tp={take_profit}")
        return self.place_market_order(instrument, abs(units), stop_loss, take_profit)

    def sell(self, instrument, units, stop_loss=None, take_profit=None):
        logging.info(f"[SIM SELL] {instrument}  units={-abs(units)}  sl={stop_loss}  tp={take_profit}")
        return self.place_market_order(instrument, -abs(units), stop_loss, take_profit)

    def has_open_position(self, instrument: str) -> bool:
        return False

    def get_open_trade_details(self, instrument: str):
        return None

    def get_open_positions(self):
        return {"positions": []}

    def get_open_trades(self):
        return {"trades": []}


# ── BacktestCSVFetcher ────────────────────────────────────────────────────────

class BacktestCSVFetcher:
    """Cursor-based CSV replay with date-range filtering and rewind support."""

    def __init__(self, data_dir: str, instruments, base_granularity: str = "M15"):
        self.data_dir         = Path(data_dir)
        self.base_granularity = _norm(base_granularity)
        self.market_data:  Dict[str, pd.DataFrame] = {}
        self.cursor:       Dict[str, int]          = {}
        self.start_idx:    Dict[str, int]          = {}
        self.end_idx:      Dict[str, int]          = {}

        for pair in instruments:
            path = self.data_dir / f"{pair}.csv"
            if not path.exists():
                logging.warning(f"[BT DATA] Missing CSV → {path}")
                continue
            df = pd.read_csv(path)
            if df.empty or "time" not in df.columns:
                logging.warning(f"[BT DATA] Invalid CSV for {pair}")
                continue
            df["time"] = pd.to_datetime(df["time"], utc=True)
            df = df.sort_values("time").set_index("time")
            df = df[~df.index.duplicated(keep="last")]
            kept = [c for c in ["open", "high", "low", "close", "volume"] if c in df.columns]
            df = df[kept].copy()
            df = self._coerce_to_base_granularity(df, self.base_granularity, pair)
            if df.empty:
                logging.warning(f"[BT DATA] No usable {self.base_granularity} candles after cleanup for {pair}")
                continue
            self._add_features(df)
            self.market_data[pair]  = df
            self.cursor[pair]       = -1
            self.start_idx[pair]    = 0
            self.end_idx[pair]      = len(df) - 1
            candle_store.lengths[pair] = len(df)
            candle_store.cursors[pair] = -1

        if not self.market_data:
            raise ValueError(f"No valid CSV files in {data_dir}.")

    @staticmethod
    def _add_features(df: pd.DataFrame) -> None:
        df["candle_type"] = "Neutral"
        df.loc[df["close"] > df["open"], "candle_type"] = "Bullish"
        df.loc[df["close"] < df["open"], "candle_type"] = "Bearish"
        df["body_size"]  = (df["close"] - df["open"]).abs()
        df["upper_wick"] = df["high"] - df[["open", "close"]].max(axis=1)
        df["lower_wick"] = df[["open", "close"]].min(axis=1) - df["low"]

    @staticmethod
    def _coerce_to_base_granularity(df: pd.DataFrame, base_granularity: str, pair: str) -> pd.DataFrame:
        """When CSVs were accidentally mixed across timeframes, keep only rows
        that participate in the requested base timeframe continuity.
        """
        if df.empty:
            return df
        step = TF_SECONDS.get(_norm(base_granularity))
        if step is None:
            return df
        diffs_prev = df.index.to_series().diff().dt.total_seconds()
        if diffs_prev.dropna().empty:
            return df
        # If no exact step exists, keep source unchanged and let callers decide.
        if not (diffs_prev == step).any():
            return df
        diffs_next = -df.index.to_series().diff(-1).dt.total_seconds()
        keep_mask = (diffs_prev == step) | (diffs_next == step)
        kept = int(keep_mask.sum())
        if kept >= 2 and kept < len(df):
            dropped = len(df) - kept
            logging.warning(
                f"[BT DATA] {pair}: mixed intervals detected; "
                f"keeping {kept}/{len(df)} rows aligned to {base_granularity}, dropped {dropped}."
            )
            return df.loc[keep_mask].copy()
        return df

    # ── Date-range helpers ────────────────────────────────────────────────────

    def available_date_range(self) -> dict:
        """Intersection of available dates across all loaded pairs."""
        if not self.market_data:
            return {"start": None, "end": None}
        starts, ends = [], []
        for df in self.market_data.values():
            if not df.empty:
                starts.append(df.index.min())
                ends.append(df.index.max())
        if not starts:
            return {"start": None, "end": None}
        return {
            "start": max(starts).isoformat(),
            "end":   min(ends).isoformat(),
        }

    def apply_date_range(self, start_ts=None, end_ts=None) -> None:
        """Reset cursors to [start_ts, end_ts] window across all pairs."""
        for pair, df in self.market_data.items():
            n = len(df)

            # -- start index
            if start_ts is not None:
                ts = pd.Timestamp(start_ts)
                if ts.tzinfo is None:
                    ts = ts.tz_localize("UTC")
                else:
                    ts = ts.tz_convert("UTC")
                si = max(0, int(df.index.searchsorted(ts)))
            else:
                si = 0

            # -- end index
            if end_ts is not None:
                ts = pd.Timestamp(end_ts)
                if ts.tzinfo is None:
                    ts = ts.tz_localize("UTC")
                else:
                    ts = ts.tz_convert("UTC")
                ei = min(n - 1, max(si, int(df.index.searchsorted(ts, side="right")) - 1))
            else:
                ei = n - 1

            self.start_idx[pair] = si
            self.end_idx[pair]   = ei
            self.cursor[pair]    = si - 1     # advance() will land on si
            candle_store.cursors[pair] = self.cursor[pair]
            # Lengths for progress bar — relative to the window
            candle_store.lengths[pair] = ei - si + 1

    # ── Replay controls ───────────────────────────────────────────────────────

    def start_price_stream(self) -> None:
        pass

    def pair_finished(self, pair: str) -> bool:
        if pair not in self.market_data:
            return True
        return self.cursor[pair] >= self.end_idx.get(pair, len(self.market_data[pair]) - 1)

    def all_finished(self) -> bool:
        return all(self.pair_finished(p) for p in self.market_data)

    def advance_pair(self, pair: str) -> bool:
        if pair not in self.market_data:
            return False
        ei = self.end_idx.get(pair, len(self.market_data[pair]) - 1)
        idx = self.cursor[pair]
        if idx < ei:
            self.cursor[pair] = idx + 1
            # Progress cursor is relative to the window
            si = self.start_idx.get(pair, 0)
            candle_store.cursors[pair] = self.cursor[pair] - si
            return True
        return False

    def rewind_pair(self, pair: str, n: int) -> None:
        """Move cursor back by n steps (clamped to start of window)."""
        if pair not in self.market_data:
            return
        si = self.start_idx.get(pair, 0)
        self.cursor[pair] = max(si - 1, self.cursor[pair] - n)
        candle_store.cursors[pair] = max(0, self.cursor[pair] - si)

    # ── Data access ───────────────────────────────────────────────────────────

    def _visible(self, pair: str) -> pd.DataFrame:
        if pair not in self.market_data:
            return pd.DataFrame()
        n = self.cursor[pair] + 1
        return pd.DataFrame() if n <= 0 else self.market_data[pair].iloc[:n].copy()

    def get_candles(self, instrument: str, granularity: str, count: int) -> pd.DataFrame:
        df = self._visible(instrument)
        if df.empty:
            return df
        gran = _norm(granularity)
        if gran == self.base_granularity:
            return df.tail(count)
        pandas_tf = OANDA_TO_PANDAS.get(gran)
        if not pandas_tf:
            raise ValueError(f"Unsupported granularity: {granularity}")
        out = (df.resample(pandas_tf)
               .agg({"open": "first", "high": "max", "low": "min",
                     "close": "last", "volume": "sum"})
               .dropna())
        if out.empty:
            return out
        self._add_features(out)
        return out.tail(count)

    def get_current_price(self, instrument: str, timeout: int = 10):
        df = self._visible(instrument)
        if df.empty:
            return None
        mid = float(df.iloc[-1]["close"])
        ts  = df.index[-1]
        price_df = pd.DataFrame(
            [{"time": ts, "bid": mid, "ask": mid, "mid": mid, "spread": 0.0}]
        )
        price_df.set_index("time", inplace=True)
        return price_df


# ── push_candles ──────────────────────────────────────────────────────────────

def push_candles(pair: str, fetcher: BacktestCSVFetcher) -> None:
    for tf_val in DISPLAY_TIMEFRAMES:
        tf_norm = _norm(tf_val)
        df = fetcher.get_candles(pair, tf_norm, CHART_CANDLE_LIMIT)
        if not df.empty:
            candle_store.update(pair, tf_norm, df)
