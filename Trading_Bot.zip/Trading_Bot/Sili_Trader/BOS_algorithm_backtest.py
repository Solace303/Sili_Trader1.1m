"""print_market_structure.py

Runs the sam_market_structure compute() function on a CSV file and prints
every BOS / CHoCH event + swing-point label to the terminal.

Usage
-----
    python print_market_structure.py                          # uses defaults below
    python print_market_structure.py EUR_USD.csv --lb 3 --rb 3 --confirm Close
    # only show the 20 most recent events, Close confirmation
    python print_market_structure.py ./forex_data/AUD_USD.csv --confirm Close --last 20
    python print_market_structure.py EUR_USD.csv --no-hh-ll --no-hl-lh
"""

import argparse
import os
import sys

import pandas as pd

# ── Import the compute function from sam_market_structure ─────────────────────
# Adjust the path if the file lives in a subdirectory.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "Sili_Trader"))
from user_indicators import sam_market_structure
compute = sam_market_structure.compute


# ── ANSI colour helpers ───────────────────────────────────────────────────────
_RESET  = "\033[0m"
_BOLD   = "\033[1m"
_GREEN  = "\033[32m"
_RED    = "\033[31m"
_CYAN   = "\033[36m"
_YELLOW = "\033[33m"
_GREY   = "\033[90m"

def _ts(unix_int: int) -> str:
    return pd.Timestamp(unix_int, unit="s", tz="UTC").strftime("%Y-%m-%d %H:%M")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Print BOS / CHoCH to terminal")
    parser.add_argument("csv",         nargs="?",
                        default="./Sili_Trader/forex_data/EUR_USD.csv",
                        help="Path to OHLCV CSV file")
    parser.add_argument("--lb",        type=int,  default=5,     help="Pivot lookback left  (default 5)")
    parser.add_argument("--rb",        type=int,  default=5,     help="Pivot lookback right (default 5)")
    parser.add_argument("--confirm",   default="H/L", choices=["H/L","Close"],
                        help="Breakout confirmation (default H/L)")
    parser.add_argument("--no-hh-ll",  action="store_true", help="Hide HH / LL markers")
    parser.add_argument("--no-hl-lh",  action="store_true", help="Hide HL / LH markers")
    parser.add_argument("--no-bos",    action="store_true", help="Hide BOS events")
    parser.add_argument("--no-choch",  action="store_true", help="Hide CHoCH events")
    parser.add_argument("--last",      type=int,  default=None,
                        help="Only show the last N events (most recent)")
    args = parser.parse_args()

    # ── Load CSV ──────────────────────────────────────────────────────────────
    if not os.path.exists(args.csv):
        print(f"❌  File not found: {args.csv}", file=sys.stderr)
        sys.exit(1)

    df = pd.read_csv(args.csv)
    if "time" in df.columns:
            df["time"] = pd.to_datetime(df["time"], utc=True)
            df = df.sort_values("time").set_index("time")
            df.columns = [c.lower() for c in df.columns]

    print(f"\n{_BOLD}CSV loaded:{_RESET} {args.csv}  "
          f"({len(df):,} rows  "
          f"{df.index.min().date()} → {df.index.max().date()})\n")

    # ── Run compute ───────────────────────────────────────────────────────────
    params = {
        "pivot_lb":          args.lb,
        "pivot_rb":          args.rb,
        "breakout_confirm":  args.confirm,
        "show_hh_ll":        not args.no_hh_ll,
        "show_hl_lh":        not args.no_hl_lh,
        "show_bos":          not args.no_bos,
        "show_choch":        not args.no_choch,
    }
    result  = compute(df, params)
    events  = result["events"]
    markers = result["markers"]

    # ── Print swing-point markers ─────────────────────────────────────────────
    if markers:
        print(f"{_BOLD}{'─'*60}")
        print(f"  SWING POINTS  ({len(markers)} labels)  lb={args.lb}  rb={args.rb}")
        print(f"{'─'*60}{_RESET}")

        # Group by label type for a clean summary
        from collections import Counter
        counts = Counter(m["text"] for m in markers)
        summary = "  ".join(f"{lbl}: {n}" for lbl, n in sorted(counts.items()))
        print(f"  {_GREY}{summary}{_RESET}\n")

        # Per-marker table
        col = {"HH": _GREEN, "HL": _GREEN, "LH": _RED, "LL": _RED}
        for m in markers:
            c = col.get(m["text"], _GREY)
            pos = "▲" if m["position"] == "aboveBar" else "▼"
            print(f"  {c}{m['text']:4s}{_RESET}  {pos}  {_GREY}{_ts(m['time'])}{_RESET}")
    else:
        print(f"  {_GREY}No swing-point markers to display.{_RESET}")

    # ── Print BOS / CHoCH events ──────────────────────────────────────────────
    if not events:
        print(f"\n  {_GREY}No BOS / CHoCH events detected with these settings.{_RESET}\n")
        return

    subset = events[-args.last:] if args.last else events

    print(f"\n{_BOLD}{'─'*60}")
    print(f"  BOS / CHoCH EVENTS  ({len(events)} total"
          + (f", showing last {args.last}" if args.last else "")
          + f")  confirm={args.confirm}")
    print(f"{'─'*60}{_RESET}")
    print(f"  {'TYPE':<8} {'DIR':<6} {'LEVEL':>10}  {'FROM':>16}  {'TO':>16}")
    print(f"  {'─'*8} {'─'*6} {'─'*10}  {'─'*16}  {'─'*16}")

    for ev in subset:
        is_bull = ev["direction"] == "UP"
        c_type  = (_GREEN if is_bull else _RED) + _BOLD
        c_dir   = _GREEN if is_bull else _RED
        arrow   = "▲" if is_bull else "▼"
        label   = "ChoCh" if ev["type"] == "ChoCh" else "BOS"
        c_label = (_CYAN if ev["type"] == "ChoCh" else (_GREEN if is_bull else _RED)) + _BOLD

        print(
            f"  {c_label}{label:<8}{_RESET} "
            f"{c_dir}{arrow} {ev['direction']:<4}{_RESET} "
            f"{ev['level']:>10.5f}  "
            f"{_GREY}{_ts(ev['from_time']):>16}  "
            f"{_ts(ev['to_time']):>16}{_RESET}"
        )

    # ── Summary ───────────────────────────────────────────────────────────────
    n_bos_up   = sum(1 for e in events if e["type"] == "BOS"   and e["direction"] == "UP")
    n_bos_dn   = sum(1 for e in events if e["type"] == "BOS"   and e["direction"] == "DOWN")
    n_choch_up = sum(1 for e in events if e["type"] == "ChoCh" and e["direction"] == "UP")
    n_choch_dn = sum(1 for e in events if e["type"] == "ChoCh" and e["direction"] == "DOWN")

    print(f"\n  {_BOLD}Summary:{_RESET}")
    print(f"    {_GREEN}BOS   ▲{_RESET}  {n_bos_up:<4}   {_RED}BOS   ▼{_RESET}  {n_bos_dn}")
    print(f"    {_CYAN}ChoCh ▲{_RESET}  {n_choch_up:<4}   {_YELLOW}ChoCh ▼{_RESET}  {n_choch_dn}")
    print()


if __name__ == "__main__":
    main()