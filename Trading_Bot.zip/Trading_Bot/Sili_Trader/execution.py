from oandapyV20 import API
import oandapyV20.endpoints.orders as orders
import oandapyV20.endpoints.positions as positions
import oandapyV20.endpoints.trades as trades

from config import (
    OANDA_API_KEY,
    OANDA_ACCOUNT_ID,
    OANDA_ENVIRONMENT
)


class TradeExecutor:

    def __init__(self):

        self.client = API(
            access_token=OANDA_API_KEY,
            environment=OANDA_ENVIRONMENT
        )

        self.account_id = OANDA_ACCOUNT_ID

    # =========================================================
    # INTERNAL ORDER SENDER
    # =========================================================

    def _submit_order(self, order_data):

        r = orders.OrderCreate(
            accountID=self.account_id,
            data=order_data
        )

        response = self.client.request(r)

        return response

    # =========================================================
    # MARKET ORDER
    # =========================================================

    def place_market_order(
        self,
        instrument,
        units,
        stop_loss=None,
        take_profit=None
    ):

        order = {
            "order": {
                "type": "MARKET",
                "instrument": instrument,
                "units": str(units),
                "timeInForce": "FOK",
                "positionFill": "DEFAULT"
            }
        }

        # -----------------------------
        # Stop Loss
        # -----------------------------

        if stop_loss is not None:

            order["order"]["stopLossOnFill"] = {
                "price": str(stop_loss)
            }

        # -----------------------------
        # Take Profit
        # -----------------------------

        if take_profit is not None:

            order["order"]["takeProfitOnFill"] = {
                "price": str(take_profit)
            }

        return self._submit_order(order)

    # =========================================================
    # STOP ORDER
    # =========================================================

    def place_stop_order(
        self,
        instrument,
        units,
        entry_price,
        stop_loss=None,
        take_profit=None
    ):

        order = {
            "order": {
                "type": "STOP",
                "instrument": instrument,
                "units": str(units),
                "price": str(entry_price),
                "timeInForce": "GTC",
                "positionFill": "DEFAULT"
            }
        }

        # -----------------------------
        # Stop Loss
        # -----------------------------

        if stop_loss is not None:

            order["order"]["stopLossOnFill"] = {
                "price": str(stop_loss)
            }

        # -----------------------------
        # Take Profit
        # -----------------------------

        if take_profit is not None:

            order["order"]["takeProfitOnFill"] = {
                "price": str(take_profit)
            }

        return self._submit_order(order)

    # =========================================================
    # BUY MARKET
    # =========================================================

    def buy_market(
        self,
        instrument,
        units,
        stop_loss=None,
        take_profit=None
    ):

        print(f"Placing BUY MARKET order for {instrument}")

        return self.place_market_order(
            instrument=instrument,
            units=abs(units),
            stop_loss=stop_loss,
            take_profit=take_profit
        )

    # =========================================================
    # SELL MARKET
    # =========================================================

    def sell_market(
        self,
        instrument,
        units,
        stop_loss=None,
        take_profit=None
    ):

        print(f"Placing SELL MARKET order for {instrument}")

        return self.place_market_order(
            instrument=instrument,
            units=-abs(units),
            stop_loss=stop_loss,
            take_profit=take_profit
        )

    # =========================================================
    # BUY STOP
    # =========================================================

    def buy_stop(
        self,
        instrument,
        units,
        entry_price,
        stop_loss=None,
        take_profit=None
    ):

        print(f"Placing BUY STOP order for {instrument}")

        return self.place_stop_order(
            instrument=instrument,
            units=abs(units),
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit
        )

    # =========================================================
    # SELL STOP
    # =========================================================

    def sell_stop(
        self,
        instrument,
        units,
        entry_price,
        stop_loss=None,
        take_profit=None
    ):

        print(f"Placing SELL STOP order for {instrument}")

        return self.place_stop_order(
            instrument=instrument,
            units=-abs(units),
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit
        )

    # =========================================================
    # GET OPEN POSITIONS
    # =========================================================

    def get_open_positions(self):

        r = positions.OpenPositions(
            accountID=self.account_id
        )

        response = self.client.request(r)

        return response

    # =========================================================
    # CHECK IF POSITION EXISTS
    # =========================================================

    def has_open_position(self, instrument):

        response = self.get_open_positions()

        for pos in response.get("positions", []):

            if pos["instrument"] == instrument:

                long_units = float(pos["long"]["units"])
                short_units = float(pos["short"]["units"])

                if long_units != 0 or short_units != 0:
                    return True

        return False

    # =========================================================
    # GET OPEN TRADES
    # =========================================================

    def get_open_trades(self):

        r = trades.OpenTrades(
            accountID=self.account_id
        )

        response = self.client.request(r)

        return response

    # =========================================================
    # GET TRADE DETAILS
    # =========================================================

    def get_open_trade_details(self, instrument):

        response = self.get_open_trades()

        for trade in response.get("trades", []):

            if trade["instrument"] == instrument:

                return {

                    "price": float(trade["price"]),

                    "sl": (
                        float(trade["stopLossOrder"]["price"])
                        if "stopLossOrder" in trade
                        else None
                    ),

                    "tp": (
                        float(trade["takeProfitOrder"]["price"])
                        if "takeProfitOrder" in trade
                        else None
                    )
                }

        return None