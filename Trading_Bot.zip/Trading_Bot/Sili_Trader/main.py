"""main.py — Sili_Trader unified entry point.

Controls are in config.py:
    BACKTEST_MODE = False  →  live trading via OANDA
    BACKTEST_MODE = True   →  CSV replay (backtest)

Backtest transport controls (Play/Pause/Step/Rewind/DateRange) are exposed via
chart_server.py API endpoints and routed through backtest.PlaybackController.
"""

import os, time, logging
from typing import Optional
import pandas as pd

from config import (
    INSTRUMENTS, CRT_TIMEFRAMES, BACKTEST_MODE,
    BACKTEST_TIMEFRAME_RELATIVITY_SECONDS,
)
from strategy import (
    BOSCRTStrategy, 
    detect_trend,
)

from risk_manager import RiskManager
from trade_journal import TradeJournal

# ── Mode-specific imports (patch watcher BEFORE importing Watcher) ────────────
if BACKTEST_MODE:
    import watcher as _watcher_module
    import backtest as _bt
    from backtest import (
        SimulatedTradeExecutor, BacktestCSVFetcher,
        candle_store, push_candles, _norm,
        BACKTEST_DATA_DIR, BACKTEST_STATE_FILE, BACKTEST_LOG_FILE,
        playback,
    )
    _watcher_module.STATE_FILE    = BACKTEST_STATE_FILE
    _watcher_module.TradeExecutor = SimulatedTradeExecutor
else:
    from data import CandleFetcher

from watcher import Watcher


# ── Logging ───────────────────────────────────────────────────────────────────

def _setup_logging() -> None:
    handlers = [logging.StreamHandler()]
    if BACKTEST_MODE:
        os.makedirs(BACKTEST_DATA_DIR, exist_ok=True)
        handlers.append(
            logging.FileHandler(BACKTEST_LOG_FILE, mode="a", encoding="utf-8")
        )
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers, force=True,
    )


# ── Strategy (mode-agnostic) ──────────────────────────────────────────────────

# ─────────────────────────────────────────────
# ANALYZE SINGLE PAIR
# ─────────────────────────────────────────────
def _analyze_pair(fetcher, watcher, pair):
    """
    Full BOS + CRT execution pipeline.

    FLOW:
    1. Detect BOS continuously
    2. If BOS exists → activate CRT detection
    3. If CRT BUY/SELL appears:
        - calculate entry
        - calculate TP
        - validate distance constraint
        - calculate risk parameters
        - execute trade
    """

    try:
        
        # =========================================================
        # FETCH H4 DATA
        # =========================================================
        df = fetcher.get_candles(
            instrument=pair,
            granularity="H4",
            count=500
        )

        if df is None or df.empty:
            logging.warning(f"[{pair}] No H4 candle data")
            return
        
        # =========================================================
        # MARKET STRUCTURE
        # =========================================================
        df = detect_trend(df)

        # =========================================================
        # INITIALIZE STRATEGY
        # =========================================================
        strategy = BOSCRTStrategy(pair)

        # =========================================================
        # STEP 1 → DETECT BOS
        # =========================================================
        bos = strategy.detect_bos(df)

        if not bos:
            return

        direction = bos["direction"]

        logging.info(
            f"[{pair}] BOS DETECTED | "
            f"Direction={direction} | "
            f"Level={bos['level']}"
        )

        # =========================================================
        # STEP 2 → CRT CONFIRMATION
        # =========================================================
        signal = strategy.crt_confirmation(df)

        if not signal:
            return

        logging.info(f"[{pair}] CRT SIGNAL = {signal}")

        # =========================================================
        # CURRENT MARKET PRICE
        # =========================================================
        current_price = float(
            fetcher.get_current_price(pair)
        )

        # =========================================================
        # LAST CANDLES
        # =========================================================
        preceding_candle = df.iloc[-2]
        proceding_candle = df.iloc[-1]

        # =========================================================
        # BUY LOGIC
        # =========================================================
        if signal == "BUY":

            # -----------------------------------------------------
            # FIND MOST RECENT LH OR HH CLOSE
            # TP = recent structural high close
            # -----------------------------------------------------
            target_exit = None

            for i in range(len(df) - 2, 0, -1):

                row = df.iloc[i]

                if row.get("LH") or row.get("HH"):
                    target_exit = row["close"]
                    break

            if target_exit is None:
                return

            # -----------------------------------------------------
            # RANGE LOGIC
            # 0% = proceeding candle close
            # 100% = TP
            # -----------------------------------------------------
            range_distance = abs(
                target_exit - proceding_candle["close"]
            )

            if range_distance == 0:
                return

            # -----------------------------------------------------
            # ENTRY VALIDATION
            # entry must not exceed 20% of TP range
            # -----------------------------------------------------
            current_percent = (
                abs(current_price - proceding_candle["close"])
                / range_distance
            ) * 100

            if current_percent > 20:
                logging.info(
                    f"[{pair}] BUY skipped | "
                    f"Entry exceeded 20% threshold"
                )
                return

            # -----------------------------------------------------
            # STOP LOSS
            # use proceeding candle low
            # -----------------------------------------------------
            stop_loss = proceding_candle["low"]

            # -----------------------------------------------------
            # RISK PARAMETERS
            # -----------------------------------------------------
            params = watcher.risk_manager.compute_trade_parameters(
                instrument=pair,
                entry=current_price,
                stop=stop_loss,
                take_profit=target_exit,
                trade_type="BUY"
            )

            if params is None:
                logging.info(f"[{pair}] BUY rejected by RiskManager")
                return

            # -----------------------------------------------------
            # EXECUTE BUY
            # -----------------------------------------------------
            watcher.executor.buy(
                instrument=pair,
                units=params["units"],
                stop_loss=stop_loss,
                take_profit=target_exit
            )

            logging.info(
                f"[{pair}] BUY EXECUTED | "
                f"Entry={current_price} | "
                f"SL={stop_loss} | "
                f"TP={target_exit}"
            )

        # =========================================================
        # SELL LOGIC
        # =========================================================
        elif signal == "SELL":

            # -----------------------------------------------------
            # FIND MOST RECENT LL OR HL CLOSE
            # TP = recent structural low close
            # -----------------------------------------------------
            target_exit = None

            for i in range(len(df) - 2, 0, -1):

                row = df.iloc[i]

                if row.get("LL") or row.get("HL"):
                    target_exit = row["close"]
                    break

            if target_exit is None:
                return

            # -----------------------------------------------------
            # RANGE LOGIC
            # 0% = proceeding candle close
            # 100% = TP
            # -----------------------------------------------------
            range_distance = abs(
                proceding_candle["close"] - target_exit
            )

            if range_distance == 0:
                return

            # -----------------------------------------------------
            # ENTRY VALIDATION
            # current price must remain within 20%
            # -----------------------------------------------------
            current_percent = (
                abs(proceding_candle["close"] - current_price)
                / range_distance
            ) * 100

            if current_percent > 20:
                logging.info(
                    f"[{pair}] SELL skipped | "
                    f"Entry exceeded 20% threshold"
                )
                return

            # -----------------------------------------------------
            # STOP LOSS
            # use proceeding candle high
            # -----------------------------------------------------
            stop_loss = proceding_candle["high"]

            # -----------------------------------------------------
            # RISK PARAMETERS
            # -----------------------------------------------------
            params = watcher.risk_manager.compute_trade_parameters(
                instrument=pair,
                entry=current_price,
                stop=stop_loss,
                take_profit=target_exit,
                trade_type="SELL"
            )

            if params is None:
                logging.info(f"[{pair}] SELL rejected by RiskManager")
                return

            # -----------------------------------------------------
            # EXECUTE SELL
            # -----------------------------------------------------
            watcher.executor.sell(
                instrument=pair,
                units=params["units"],
                stop_loss=stop_loss,
                take_profit=target_exit
            )

            logging.info(
                f"[{pair}] SELL EXECUTED | "
                f"Entry={current_price} | "
                f"SL={stop_loss} | "
                f"TP={target_exit}"
            )

    except Exception as e:

        logging.error(
            f"[{pair}] ANALYSIS ERROR: {e}"
        )

# ── Main run ──────────────────────────────────────────────────────────────────

def run() -> None:
    _setup_logging()

    if BACKTEST_MODE:
        exec_tf = _norm(CRT_TIMEFRAMES.get("execution_tf", "M15"))
        base_sleep = float(BACKTEST_TIMEFRAME_RELATIVITY_SECONDS.get(exec_tf, 1.0))
        fetcher = BacktestCSVFetcher(
            data_dir=BACKTEST_DATA_DIR,
            instruments=INSTRUMENTS,
            base_granularity=exec_tf,
        )
        _bt.current_fetcher = fetcher   # expose for chart_server API

        # Apply initial date range if pre-configured (e.g. from a previous session)
        if playback.start_ts or playback.end_ts:
            fetcher.apply_date_range(playback.start_ts, playback.end_ts)
    else:
        base_sleep = 60
        fetcher    = CandleFetcher()

    watcher = Watcher(fetcher)
    fetcher.start_price_stream()
    watcher.load_state()

    pairs   = list(fetcher.market_data.keys()) if BACKTEST_MODE else list(INSTRUMENTS)
    missing = [p for p in INSTRUMENTS if p not in (fetcher.market_data if BACKTEST_MODE else INSTRUMENTS)]
    if missing:
        logging.warning(f"[INIT] No CSV for: {missing} — skipping")

    logging.info("=" * 60)
    logging.info(f"{'BACKTEST' if BACKTEST_MODE else 'LIVE'} BOT STARTED")
    logging.info(f"    Pairs       : {pairs}")
    logging.info(f"    Base sleep  : {base_sleep}s")
    if BACKTEST_MODE:
        logging.info(f"    Chart server: http://localhost:8000")
        logging.info(f"    Transport   : Press ▶ in the browser to begin")
    logging.info("=" * 60)

    # Prime the candle store with the first visible slice so the browser
    # can show chart axes even before the user presses Play.
    if BACKTEST_MODE:
        for pair in pairs:
            if not fetcher.pair_finished(pair):
                fetcher.advance_pair(pair)
        for pair in pairs:
            push_candles(pair, fetcher)
        # Start paused — user clicks ▶ to begin
        playback.pause()

    # ── Main loop ──────────────────────────────────────────────────────────
    while True:
        try:
            was_manual_step = False

            if BACKTEST_MODE:
                fwd, rwd, is_playing = playback.consume_steps()

                # ── Rewind: move cursor back, repush, increment version ────
                if rwd > 0:
                    for pair in pairs:
                        fetcher.rewind_pair(pair, rwd)
                    for pair in pairs:
                        push_candles(pair, fetcher)
                    candle_store.rewind_version += 1
                    time.sleep(0.01)
                    continue

                # ── Reached end of replay ─────────────────────────────────
                if fetcher.all_finished():
                    if is_playing:
                        playback.pause()
                        logging.info("✅ Backtest replay complete — all candles exhausted")
                    playback.wait(timeout=0.5)
                    continue

                # ── Paused and no pending step → block ────────────────────
                if not is_playing and fwd == 0:
                    playback.wait(timeout=0.2)
                    continue

                # ── Advance cursor (1 auto step or N manual steps) ────────
                was_manual_step = (fwd > 0 and not is_playing)
                n_advance = max(1, fwd)
                for _ in range(n_advance):
                    for pair in pairs:
                        if not fetcher.pair_finished(pair):
                            fetcher.advance_pair(pair)
                for pair in pairs:
                    push_candles(pair, fetcher)

            # ── Per-pair strategy (identical for both modes) ───────────────
            for pair in pairs:
                if pair in watcher.active_watchers:
                    thread = watcher.active_watchers[pair]["thread"]
                    if thread.is_alive():
                        continue
                    logging.warning(f"[STALE] Removing dead watcher for {pair}")
                    del watcher.active_watchers[pair]
                    watcher.save_state()

                if watcher.executor.has_open_position(pair):
                    logging.info(f"[SKIP] Open position exists for {pair}")
                    continue

                logging.info(f"\n{'=' * 50}\nAnalyzing {pair}\n{'=' * 50}")

                _analyze_pair(fetcher, watcher, pair)

            logging.info("⏳ Sleeping before next cycle...\n")

            if BACKTEST_MODE:
                if was_manual_step:
                    time.sleep(0.01)         # near-instant for single-step
                else:
                    actual = max(0.01, base_sleep / max(0.1, playback.speed))
                    time.sleep(actual)
            else:
                time.sleep(base_sleep)

        except Exception as e:
            logging.error(f"🔥 MAIN LOOP ERROR: {e}", exc_info=True)
            time.sleep(1)

        # ── Teardown (only reached in non-backtest path or on StopIteration) ──
        if BACKTEST_MODE:
            watcher.save_state()
            if watcher.logs:
                frames = []
                for pair, df_log in watcher.logs.items():
                    if df_log is not None and not df_log.empty:
                        out = df_log.copy(); out["pair"] = pair
                        frames.append(out)
                if frames:
                    import pandas as _pd
                    results = _pd.concat(frames, ignore_index=True)
                    summary_path = os.path.join(BACKTEST_DATA_DIR, "backtest_results.csv")
                    results.to_csv(summary_path, index=False)
                    logging.info(f"[RESULT] Saved → {summary_path}")
                    for pair in results["pair"].unique():
                        sub = results[results["pair"] == pair]
                        wins = int((sub["result"] == "WIN").sum())
                        losses = int((sub["result"] == "LOSS").sum())
                        total = len(sub)
                        wr = (wins / total * 100) if total else 0.0
                        logging.info(f"  {pair:10s}  {wins}W/{losses}L/{total}  WR={wr:.1f}%")
                else:
                    logging.info("[RESULT] No completed trades.")


if __name__ == "__main__":
    run()