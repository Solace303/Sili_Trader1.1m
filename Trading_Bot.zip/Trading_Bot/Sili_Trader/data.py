"""OANDA candle data fetcher for Sili_Trader.

This module handles the low-level API interaction with OANDA and returns a
pandas DataFrame of OHLCV candles enriched with a few useful derived columns.

MODIFIED FOR LIVE MODE:
- Appends new data to existing CSVs instead of overwriting.
- Detects the last saved timestamp to fetch only missing candles.
- Handles data gaps by extending the dataset.
"""

import time
import logging
import threading
import oandapyV20
import pandas as pd
from pathlib import Path
import oandapyV20.endpoints.orders as orders
import oandapyV20.endpoints.pricing as pricing
import oandapyV20.endpoints.accounts as accounts
import oandapyV20.endpoints.instruments as instruments

# Import BACKTEST_MODE to ensure we only append in Live Mode
from config import (
    OANDA_ACCOUNT_ID, OANDA_API_KEY, OANDA_ENVIRONMENT,
    INSTRUMENTS, BACKTEST_MODE, CRT_TIMEFRAMES,
)

logging.basicConfig(level=logging.INFO)

def _norm_tf(tf: str) -> str:
    s = str(tf).strip().upper()
    aliases = {"15M": "M15", "1H": "H1", "4H": "H4", "1D": "D"}
    return aliases.get(s, s)


class CandleFetcher:
    """Simple wrapper around the OANDA REST API for fetching historical candles."""

    def __init__(self):
        self.client = oandapyV20.API(
            access_token=OANDA_API_KEY,
            environment=OANDA_ENVIRONMENT
        )
        
        self.price_cache = {}
        self.pip_cache = {}
        self.stream_running = False
        self.forex_data_dir = Path("/run/media/solace/ABBA-2E35/My_Code/Sili_Trader/forex_data")
        self.forex_data_dir.mkdir(parents=True, exist_ok=True)
        self.base_storage_granularity = _norm_tf(CRT_TIMEFRAMES.get("execution_tf", "M15"))

    def get_candles(self, instrument, granularity, count):
        """Return a pandas DataFrame of the most recent candles.

        In LIVE MODE (!BACKTEST_MODE):
            - Checks for existing CSV.
            - Fetches only missing candles since the last recorded time.
            - Appends new data to the CSV.
        
        In BACKTEST MODE:
            - Behaves as before (returns requested count), saving is handled by backtest logic.

        Args:
            instrument (str): Candle instrument, e.g. "EUR_USD".
            granularity (str): Timeframe string accepted by OANDA.
            count (int): Number of candles to fetch (used as a baseline or buffer).

        Returns:
            pd.DataFrame: Indexed by timestamp.
        """
        
        gran_norm = _norm_tf(granularity)
        should_persist = (not BACKTEST_MODE and gran_norm == self.base_storage_granularity)

        # Determine how many candles to actually request from OANDA
        fetch_count = count
        existing_df = None
        last_saved_time = None

        # --- LIVE MODE LOGIC: Append vs Overwrite ---
        if should_persist:
            output_file = self.forex_data_dir / f"{instrument}.csv"
            
            if output_file.exists():
                try:
                    # Load existing data to find the last timestamp
                    existing_df = pd.read_csv(output_file, index_col="time", parse_dates=["time"])
                    if not existing_df.empty:
                        last_saved_time = existing_df.index[-1]
                        
                        # Calculate how many candles might have passed since last save
                        # Approximate seconds per candle
                        tf_seconds = {
                            "M1": 60, "M5": 300, "M15": 900, "M30": 1800,
                            "H1": 3600, "H4": 14400, "D": 86400
                        }
                        seconds_per_candle = tf_seconds.get(gran_norm, 3600)
                        
                        # Time difference in seconds
                        time_diff = (pd.Timestamp.now(tz='UTC') - last_saved_time).total_seconds()
                        
                        # Estimate missing candles + buffer of 5 to be safe
                        estimated_missing = int(time_diff / seconds_per_candle) + 5
                        
                        # We fetch at least 'count' or the estimated missing, whichever is larger
                        # But cap it to avoid hitting OANDA limits if something is wrong
                        fetch_count = max(count, min(estimated_missing, 1000))
                        
                        logging.info(f"[{instrument}] Found existing data. Last: {last_saved_time}. Fetching ~{fetch_count} candles to bridge gap.")
                    else:
                        logging.info(f"[{instrument}] CSV exists but empty. Fetching full batch.")
                except Exception as e:
                    logging.error(f"[{instrument}] Error reading existing CSV: {e}. Fetching full batch.")
            else:
                logging.info(f"[{instrument}] No existing CSV found. Fetching initial batch of {count}.")

        # --- OANDA API REQUEST ---
        params = {
            "granularity": gran_norm,
            "count": fetch_count,
            "price": "M"
        }

        try:
            r = instruments.InstrumentsCandles(instrument=instrument, params=params)
            response = self.client.request(r)
        except Exception as e:
            logging.error(f"[{instrument}] OANDA API Request failed: {e}")
            return existing_df if existing_df is not None else pd.DataFrame()

        candles = []
        for candle in response["candles"]:
            if candle["complete"]:
                candles.append({
                    "time": pd.to_datetime(candle["time"]),
                    "open": float(candle["mid"]["o"]),
                    "high": float(candle["mid"]["h"]),
                    "low": float(candle["mid"]["l"]),
                    "close": float(candle["mid"]["c"]),
                    "volume": int(candle["volume"])
                })

        new_df = pd.DataFrame(candles)
        
        if new_df.empty:
            return existing_df if existing_df is not None else pd.DataFrame()

        new_df.set_index("time", inplace=True)

        # --- MERGE AND SAVE (LIVE MODE ONLY, base timeframe only) ---
        if should_persist:
            if existing_df is not None and not existing_df.empty:
                # Concatenate existing and new data
                combined_df = pd.concat([existing_df, new_df])
                
                # Remove duplicates based on index (timestamp), keeping the last occurrence
                # This handles the case where the newest fetched candle overlaps with the last saved one
                combined_df = combined_df[~combined_df.index.duplicated(keep='last')]
                
                # Sort by time just in case
                combined_df.sort_index(inplace=True)
                
                final_df = combined_df
            else:
                final_df = new_df

            # Enrich with derived columns before saving
            final_df = self._enrich_dataframe(final_df)

            # Save to CSV
            output_file = self.forex_data_dir / f"{instrument}.csv"
            final_df.to_csv(output_file, index=True)
            
            # Return only the 'count' most recent for the strategy to process immediately
            # (or return all if you prefer, but strategy usually wants latest)
            return final_df.tail(count)

        if not BACKTEST_MODE:
            # For non-base live requests (e.g. H1/H4), return fetched data but
            # do not append to the shared CSV to avoid mixed-interval files.
            return self._enrich_dataframe(new_df).tail(count)
        
        # --- BACKTEST MODE (Original Behavior) ---
        # In backtest mode, we don't save to disk here; the backtest engine manages state.
        # We just return the processed dataframe.
        new_df = self._enrich_dataframe(new_df)
        return new_df

    def _enrich_dataframe(self, df):
        """Helper to add derived columns (candle_type, wicks, etc.)"""
        if df.empty:
            return df

        def detect_candle_type(row):
            if row['close'] > row['open']: return 'Bullish'
            elif row['close'] < row['open']: return 'Bearish'
            else: return 'Neutral'

        def calculate_body_size(row):
            return abs(row["close"] - row["open"])

        def calculate_wick_lengths(row):
            upper_wick = row['high'] - max(row['open'], row['close'])
            lower_wick = min(row['open'], row['close']) - row['low']
            return upper_wick, lower_wick

        # Avoid SettingWithCopyWarning by working on a copy if needed, 
        # but here we assume df is fresh or we want to modify it directly
        df['candle_type'] = df.apply(detect_candle_type, axis=1)
        df['body_size'] = df.apply(calculate_body_size, axis=1)
        df[['upper_wick', 'lower_wick']] = df.apply(calculate_wick_lengths, axis=1, result_type='expand')
        
        return df
    
    # ---------------------------------------
    # ACCOUNT SUMMARY
    # ---------------------------------------
    def get_account_summary(self):
        r = accounts.AccountSummary(OANDA_ACCOUNT_ID)
        response = self.client.request(r)

        data = response["account"]

        return {
            "balance": float(data["balance"]),
            "currency": data["currency"]
        }

    # ---------------------------------------
    # PIP LOCATION
    # ---------------------------------------
    def get_pip_location(self, instrument):
        r = accounts.AccountInstruments(
            accountID=OANDA_ACCOUNT_ID,
            params={"instruments": instrument}
        )

        response = self.client.request(r)
        instrument_data = response["instruments"][0]

        return instrument_data["pipLocation"]
    
    def get_current_price(self, instrument, timeout=10):
        start = time.time()
        while instrument not in self.price_cache:
            if time.time() - start > timeout:
                logging.warning(f"No price received yet for {instrument}")
                return None
            time.sleep(0.05)
        return self.price_cache[instrument]["mid"].iloc[-1]

    def start_price_stream(self):
        if self.stream_running:
            return

        self.stream_running = True

        def stream():
            params = {
                "instruments": ",".join(INSTRUMENTS)
            }

            r = pricing.PricingStream(
                accountID=OANDA_ACCOUNT_ID,
                params=params
            )

            try:
                for tick in self.client.request(r):
                    if tick.get("type") != "PRICE":
                        continue

                    instrument = tick["instrument"]
                    if not tick.get("bids") or not tick.get("asks"):
                        continue

                    bid = float(tick["bids"][0]["price"])
                    ask = float(tick["asks"][0]["price"])

                    data = {
                        "time": pd.to_datetime(tick["time"]),
                        "bid": bid,
                        "ask": ask,
                        "mid": (bid + ask) / 2,
                        "spread": ask - bid
                    }

                    df = pd.DataFrame([data])
                    df.set_index("time", inplace=True)
                    self.price_cache[instrument] = df

            except Exception as e:
                logging.error(f"Price stream error: {e}")

        thread = threading.Thread(target=stream, daemon=True)
        thread.start()
