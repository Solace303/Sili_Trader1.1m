import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mt5linux import MetaTrader5
from sam_market_structure import compute

# 1. Get the absolute path of the directory this script is in (user_indicators)
current_dir = os.path.dirname(os.path.abspath(__file__))

# 2. Find the parent directory (Sili-Trader1.1m)
parent_dir = os.path.dirname(current_dir)

# 3. Add the parent directory to Python's search path if it's not already there
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import your dictionary configuration layer
from config import vol_priz_fft

# Define environment/session specific targets locally
MT5_PATH = "/home/solace/.mt5/drive_c/Program Files/MetaTrader 5/terminal64.exe"
SYMBOL = "BTCUSDz"

# =============================================================================
# INITIALIZE INITIAL GRAPH WINDOWS & BACKEND
# =============================================================================
fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(15, 12), sharex=True)
plt.subplots_adjust(hspace=0.15)

def update_live_dashboard(frame):
    """Core processing and window update callback loop."""
    # Initialize MT5 session per tick/frame
    mt5 = MetaTrader5()
    if not mt5.initialize(MT5_PATH):
        print("[-] MT5 Initialization Failed within update loop!")
        return

    rates = mt5.copy_rates_from_pos(
        SYMBOL, 
        vol_priz_fft["TIMEFRAME"], 
        0, 
        vol_priz_fft["COUNT"]
    )
    mt5.shutdown()

    if rates is None or len(rates) == 0:
        print("[-] Failed to fetch streaming framework ticks.")
        return

    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    df.rename(columns={"tick_volume": "volume"}, inplace=True)
    df.set_index("time", inplace=True)

    df["price_ma"] = df["close"].rolling(window=vol_priz_fft["MA_LENGTH"]).mean()
    df["volume_ma"] = df["volume"].rolling(window=vol_priz_fft["MA_LENGTH"]).mean()
    df.dropna(subset=["price_ma", "volume_ma"], inplace=True)

    time_lookup = dict(zip([int(x.timestamp()) for x in df.index], df.index))

    # Run Market Structure Engine
    params = {"pivot_lb": 8, "pivot_rb": 8, "breakout_confirm": "Close"}
    structure_result = compute(df, params=params)
    raw_events = structure_result.get("events", [])

    # FFT Spectral Engines
    fft_price = np.fft.fft(df["price_ma"].values)
    fft_volume = np.fft.fft(df["volume_ma"].values)

    lp_price = fft_price.copy()
    lp_price[vol_priz_fft["KEEP_COMPONENTS"]:-vol_priz_fft["KEEP_COMPONENTS"]] = 0
    df["price_low"] = np.real(np.fft.ifft(lp_price))

    lp_volume = fft_volume.copy()
    lp_volume[vol_priz_fft["KEEP_COMPONENTS"]:-vol_priz_fft["KEEP_COMPONENTS"]] = 0
    df["vol_low"] = np.real(np.fft.ifft(lp_volume))

    hp_price_coefs = fft_price.copy()
    hp_price_coefs[:vol_priz_fft["KEEP_COMPONENTS"]] = 0
    hp_price_coefs[-vol_priz_fft["KEEP_COMPONENTS"]:] = 0

    hp_vol_coefs = fft_volume.copy()
    hp_vol_coefs[:vol_priz_fft["KEEP_COMPONENTS"]] = 0
    hp_vol_coefs[-vol_priz_fft["KEEP_COMPONENTS"]:] = 0

    df["raw_p_high"] = np.real(np.fft.ifft(hp_price_coefs))
    df["raw_v_high"] = np.real(np.fft.ifft(hp_vol_coefs))

    # Rolling Normalization
    roll_p_min = df["raw_p_high"].rolling(window=vol_priz_fft["LOCAL_WINDOW"], min_periods=1).min()
    roll_p_max = df["raw_p_high"].rolling(window=vol_priz_fft["LOCAL_WINDOW"], min_periods=1).max()
    roll_v_min = df["raw_v_high"].rolling(window=vol_priz_fft["LOCAL_WINDOW"], min_periods=1).min()
    roll_v_max = df["raw_v_high"].rolling(window=vol_priz_fft["LOCAL_WINDOW"], min_periods=1).max()

    p_range = (roll_p_max - roll_p_min).replace(0, 1e-8)
    v_range = (roll_v_max - roll_v_min).replace(0, 1e-8)

    df["price_high"] = 2 * (df["raw_p_high"] - roll_p_min) / p_range - 1
    df["vol_high"] = 2 * (df["raw_v_high"] - roll_v_min) / v_range - 1
    df["combined_high_wave"] = df["price_high"] + df["vol_high"]

    # Signal Refinement Engine
    fine_tuned_signals = []
    total_bars = len(df)

    for event in raw_events:
        if event["type"] != "ChoCh":
            continue
            
        break_unix = event["break_time"]
        if break_unix not in time_lookup:
            continue
            
        choch_time = time_lookup[break_unix]
        choch_idx = df.index.get_loc(choch_time)
        
        start_look = max(0, choch_idx - vol_priz_fft["CREST_NEIGHBORHOOD"])
        end_look = min(total_bars, choch_idx + vol_priz_fft["CREST_NEIGHBORHOOD"] + 1)
        
        local_vol_curve = df["vol_low"].iloc[start_look:end_look].values
        current_vol_low = df["vol_low"].iloc[choch_idx]
        
        if current_vol_low != np.max(local_vol_curve):
            continue  
            
        ftss_trend = "UP" if event["direction"] == "UP" else "DOWN"
        
        for forward_idx in range(choch_idx + 1, total_bars):
            if forward_idx < total_bars - 1:
                prev_val = df["vol_low"].iloc[forward_idx - 1]
                curr_val = df["vol_low"].iloc[forward_idx]
                next_val = df["vol_low"].iloc[forward_idx + 1]
                if curr_val > prev_val and curr_val > next_val:
                    break  
                
            interference_wave_val = df["combined_high_wave"].iloc[forward_idx]
            
            if abs(interference_wave_val) >= 0.7:
                interference_type = "CONSTRUCTIVE"
            elif abs(interference_wave_val) <= 0.3:
                interference_type = "DESTRUCTIVE"
            else:
                interference_type = "TRANSITIONAL"
            
            trade_trigger = None
            if ftss_trend == "UP" and interference_type == "CONSTRUCTIVE":
                trade_trigger = "BUY_CONSTRUCTIVE"
            elif ftss_trend == "DOWN" and interference_type == "DESTRUCTIVE":
                trade_trigger = "BUY_DESTRUCTIVE"
                
            if trade_trigger:
                fine_tuned_signals.append({
                    "time": df.index[forward_idx],
                    "price": df["close"].iloc[forward_idx],
                    "trend": ftss_trend,
                    "interference": interference_type,
                    "vol_low_val": df["vol_low"].iloc[forward_idx]
                })
                break

    # -------------------------------------------------------------------------
    # RENDERING/REFRESH LAYER
    # -------------------------------------------------------------------------
    ax1.cla()
    ax2.cla()
    ax3.cla()

    # Subplot 1: Price State
    ax1.plot(df.index, df["close"], color="#2962FF", label="Raw Close Price", alpha=0.4)
    ax1.plot(df.index, df["price_ma"], color="#26a69a", label="Price 8 MA Line", linewidth=2.0)
    ax1.set_title(f"LIVE FRAME DATA: {SYMBOL} | Signals Validated: {len(fine_tuned_signals)}", fontsize=12, fontweight="bold")
    ax1.set_ylabel("Price Domain")
    ax1.grid(True, linestyle="--", alpha=0.3)

    # Subplot 2: Volume State
    ax2.bar(df.index, df["volume"], color="#E0E3EB", alpha=0.3, label="Raw Volume Bars")
    ax2.plot(df.index, df["volume_ma"], color="#2962FF", label="Volume 8 MA Line", linewidth=1.8)
    ax2.plot(df.index, df["vol_low"], color="#FF6D00", label="Low-Pass Vol Wave (Crests)", linewidth=2.5)
    ax2.set_ylabel("Volume Domain")
    ax2.grid(True, linestyle="--", alpha=0.3)

    # Subplot 3: Interference Scale
    ax3.plot(df.index, df["combined_high_wave"], color="#7B1FA2", label="Synthesized Wave Envelope", linewidth=2.0)
    ax3.plot(df.index, df["price_high"], color="#26a69a", label="Rolling Price Component", linewidth=1.0, linestyle=":", alpha=0.5)
    ax3.plot(df.index, df["vol_high"], color="#2962FF", label="Rolling Volume Component", linewidth=1.0, linestyle=":", alpha=0.5)
    ax3.axhline(0, color="black", linestyle="-", alpha=0.4)
    ax3.set_ylim(-2.5, 2.5)
    ax3.set_ylabel("Synthesized Scale [-2, 2]")
    ax3.set_xlabel("Timeline")
    ax3.grid(True, linestyle="--", alpha=0.3)

    # Replot Signal Execution Markings dynamically per tick
    buy_legend_added = False
    for sig in fine_tuned_signals:
        ax1.plot(sig["time"], sig["price"], marker="▲", color="#00E676", markersize=14, linestyle="None", zorder=10)
        ax2.plot(sig["time"], sig["vol_low_val"], marker="●", color="#7B1FA2", markersize=10, linestyle="None", zorder=10)
        ax3.axvline(x=sig["time"], color="#00E676", linestyle=":", alpha=0.7, linewidth=2)
        
        if not buy_legend_added:
            ax1.plot([], [], marker="▲", color="#00E676", linestyle="None", label="Derivative Apex Trigger")
            buy_legend_added = True

    ax1.legend(loc="upper left")
    ax2.legend(loc="upper left")
    ax3.legend(loc="upper left")

# =============================================================================
# RUNNING TIMELINE ENGINE
# =============================================================================
# interval=1000 means the graph re-fetches and processes MT5 data every 1000ms (1 second)
ani = FuncAnimation(fig, update_live_dashboard, interval=2000, cache_frame_data=False)
plt.show()