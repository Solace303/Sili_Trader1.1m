import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mt5linux import MetaTrader5
from sam_market_structure import compute

# 1. Get the absolute path of the directory this script is in (user_indicators)
current_dir = os.path.dirname(os.path.abspath(__file__))

# 2. Find the parent directory (Sili-Trader1.1m)
parent_dir = os.path.dirname(current_dir)

# 3. Add the parent directory to Python's search path if it's not already there
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Import your dictionary configuration layer
from config import vol_priz_fft

# Define environment/session specific targets locally
MT5_PATH = "/home/solace/.mt5/drive_c/Program Files/MetaTrader 5/terminal64.exe"
SYMBOL = "BTCUSDz"

# =============================================================================
# DATA ACQUISITION & PROCESSING LAYER
# =============================================================================
mt5 = MetaTrader5()
if not mt5.initialize(MT5_PATH):
    print("[-] MT5 Initialization Failed!")
    sys.exit()

print(f"[+] Fetching {vol_priz_fft['COUNT']} bars of {SYMBOL} H1 data...")
rates = mt5.copy_rates_from_pos(
    SYMBOL, 
    vol_priz_fft["TIMEFRAME"], 
    0, 
    vol_priz_fft["COUNT"]
)
mt5.shutdown()

if rates is None or len(rates) == 0:
    print("[-] Failed to fetch data.")
    sys.exit()

df = pd.DataFrame(rates)
df["time"] = pd.to_datetime(df["time"], unit="s")
df.rename(columns={"tick_volume": "volume"}, inplace=True)
df.set_index("time", inplace=True)

df["price_ma"] = df["close"].rolling(window=vol_priz_fft["PRIZ_MA_LENGTH"]).mean()
df["volume_ma"] = df["volume"].rolling(window=vol_priz_fft["VOL_MA_LENGTH"]).mean()
df.dropna(subset=["price_ma", "volume_ma"], inplace=True)

time_lookup = dict(zip([int(x.timestamp()) for x in df.index], df.index))

# =============================================================================
# 2. RUN MARKET STRUCTURE ENGINE
# =============================================================================
params = {"pivot_lb": 8, "pivot_rb": 8, "breakout_confirm": "Close"}
structure_result = compute(df, params=params)
raw_events = structure_result.get("events", [])

# =============================================================================
# 3. FFT TRANSFORMATION & SPECTRAL ENGINES
# =============================================================================
fft_price = np.fft.fft(df["price_ma"].values)
fft_volume = np.fft.fft(df["volume_ma"].values)

# Isolate Low-Frequencies separately for structural cycle verification
lp_price = fft_price.copy()
lp_price[vol_priz_fft["KEEP_COMPONENTS"]:-vol_priz_fft["KEEP_COMPONENTS"]] = 0
df["price_low"] = np.real(np.fft.ifft(lp_price))

lp_volume = fft_volume.copy()
lp_volume[vol_priz_fft["KEEP_COMPONENTS"]:-vol_priz_fft["KEEP_COMPONENTS"]] = 0
df["vol_low"] = np.real(np.fft.ifft(lp_volume))

# Isolate Raw High-Frequencies
hp_price_coefs = fft_price.copy()
hp_price_coefs[:vol_priz_fft["KEEP_COMPONENTS"]] = 0
hp_price_coefs[-vol_priz_fft["KEEP_COMPONENTS"]:] = 0

hp_vol_coefs = fft_volume.copy()
hp_vol_coefs[:vol_priz_fft["KEEP_COMPONENTS"]] = 0
hp_vol_coefs[-vol_priz_fft["KEEP_COMPONENTS"]:] = 0

df["raw_p_high"] = np.real(np.fft.ifft(hp_price_coefs))
df["raw_v_high"] = np.real(np.fft.ifft(hp_vol_coefs))

# --- ROLLING LOCAL EQUALIZATION ENGINE ---
roll_p_min = df["raw_p_high"].rolling(window=vol_priz_fft["LOCAL_WINDOW"], min_periods=1).min()
roll_p_max = df["raw_p_high"].rolling(window=vol_priz_fft["LOCAL_WINDOW"], min_periods=1).max()
roll_v_min = df["raw_v_high"].rolling(window=vol_priz_fft["LOCAL_WINDOW"], min_periods=1).min()
roll_v_max = df["raw_v_high"].rolling(window=vol_priz_fft["LOCAL_WINDOW"], min_periods=1).max()

p_range = (roll_p_max - roll_p_min).replace(0, 1e-8)
v_range = (roll_v_max - roll_v_min).replace(0, 1e-8)

df["price_high"] = 2 * (df["raw_p_high"] - roll_p_min) / p_range - 1
df["vol_high"] = 2 * (df["raw_v_high"] - roll_v_min) / v_range - 1

df["combined_high_wave"] = df["price_high"] + df["vol_high"]

# =============================================================================
# INTEGRATED ENGINE: LOCAL DERIVATIVE CREST SCANNER
# =============================================================================
detected_crests = []
total_bars = len(df)
neighborhood = vol_priz_fft["CREST_NEIGHBORHOOD"]

for idx in range(total_bars):
    start_look = max(0, idx - neighborhood)
    end_look = min(total_bars, idx + neighborhood + 1)
    
    local_vol_curve = df["vol_low"].iloc[start_look:end_look].values
    current_vol_low = df["vol_low"].iloc[idx]
    
    if current_vol_low == np.max(local_vol_curve):
        exact_time = df.index[idx]
        detected_crests.append({
            "index": idx,
            "timestamp": exact_time.strftime("%Y-%m-%d %H:%M:%S"),
            "unix_time": int(exact_time.timestamp()),
            "volume_low_val": current_vol_low
        })

# =============================================================================
# 4. BOUNDED REFINEMENT ENGINE (CREST TO NEXT CREST BOUNDARY)
# =============================================================================
fine_tuned_signals = []
num_crests = len(detected_crests)

for c_idx in range(num_crests):
    current_crest = detected_crests[c_idx]
    crest_unix = current_crest["unix_time"]
    crest_bar_idx = current_crest["index"]
    
    # Establish absolute timeline limit: the index of the next newly formed crest
    next_crest_bar_idx = total_bars
    if c_idx + 1 < num_crests:
        next_crest_bar_idx = detected_crests[c_idx + 1]["index"]
        
    # Locate the first valid ChoCh that happens *after* this specific crest, but *before* the next
    matching_choch = None
    for event in raw_events:
        if event["type"] != "ChoCh":
            continue
        if event["break_time"] > crest_unix:
            if event["break_time"] in time_lookup:
                target_idx = df.index.get_loc(time_lookup[event["break_time"]])
                if target_idx < next_crest_bar_idx:
                    matching_choch = event
                    break
                    
    if not matching_choch:
        continue
        
    choch_time = time_lookup[matching_choch["break_time"]]
    choch_idx = df.index.get_loc(choch_time)
    sms_trend = "UP" if matching_choch["direction"] == "UP" else "DOWN"
    
    # Calculate the historic Crest Trend based on structural reversals prior to current boundary
    prev_sms_event = None
    for p_ev in reversed(raw_events):
        if p_ev["type"] == "ChoCh" and p_ev["break_time"] < crest_unix:
            prev_sms_event = p_ev
            break
            
    if prev_sms_event is not None:
        prev_trend = "UP" if prev_sms_event["direction"] == "UP" else "DOWN"
        crest_trend = "DOWN" if prev_trend == "UP" else "UP"
    else:
        crest_trend = sms_trend 

    # Implement your matrix trend designations
    if sms_trend == "UP" and crest_trend == "UP":
        ftss_trend = "100% up"
    elif sms_trend == "DOWN" and crest_trend == "DOWN":
        ftss_trend = "100% down"
    elif sms_trend == "UP" and crest_trend == "DOWN":
        ftss_trend = "70% down"
    elif sms_trend == "DOWN" and crest_trend == "UP":
        ftss_trend = "70% up"
    else:
        ftss_trend = sms_trend
    
    # Scan forward from ChoCh, but strictly break if we hit the boundary of the next crest
    for forward_idx in range(choch_idx + 1, next_crest_bar_idx):
        if forward_idx < total_bars - 1:
            prev_val = df["vol_low"].iloc[forward_idx - 1]
            curr_val = df["vol_low"].iloc[forward_idx]
            next_val = df["vol_low"].iloc[forward_idx + 1]
            
            if curr_val > prev_val and curr_val > next_val:
                break  
            
        # Check tracking metrics on zero crossings
        interference_wave_val = df["combined_high_wave"].iloc[forward_idx]
        is_zero_crossing = abs(interference_wave_val) <= 0.05
        
        trade_trigger = None
        if is_zero_crossing:
            if ftss_trend == "100% up":
                trade_trigger = "BUY SIGNAL 100%"
            elif ftss_trend == "100% down":
                trade_trigger = "SELL SIGNAL 100%"
            elif ftss_trend == "70% down":
                trade_trigger = "SELL SIGNAL 70%"
            elif ftss_trend == "70% up":
                trade_trigger = "BUY SIGNAL 70%"
                
        if trade_trigger:
            fine_tuned_signals.append({
                "time": df.index[forward_idx],
                "price": df["close"].iloc[forward_idx],
                "trend": ftss_trend,
                "interference": "ZERO_CROSS",
                "trigger": trade_trigger,
                "vol_low_val": df["vol_low"].iloc[forward_idx]
            })
            break  # Stop search within this cycle once confirmation triggers

print(f"[+] FTSS Forward Scanner Finished. Validated {len(fine_tuned_signals)} Forward Wave Entries.")

# =============================================================================
# CONSOLE SUMMARY COMPILER
# =============================================================================
print("\n" + "="*60)
print(f"LOW-FREQUENCY MACRO CREST ANALYSIS FOR {SYMBOL}")
print("="*60)
print(f"Total Available Crests Detected: {len(detected_crests)}")
print("-"*60)
print(f"{'Index':<8} | {'Precise Timestamp (to the second)':<30} | {'Wave Value':<12}")
print("-"*60)
for crest in detected_crests:
    print(f"{crest['index']:<8} | {crest['timestamp']:<30} | {crest['volume_low_val']:.<12.4f}")
print("="*60 + "\n")

# =============================================================================
# 5. VISUALIZATION COMPILER
# =============================================================================
fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(15, 12), sharex=True)
plt.subplots_adjust(hspace=0.15)

ax1.plot(df.index, df["close"], color="#2962FF", label="Raw Close Price", alpha=0.4)
ax1.plot(df.index, df["price_ma"], color="#26a69a", label="Price 8 MA Line", linewidth=2.0)
ax1.set_title("Fine-Tuned Market Structure & Derivative Superposition Engine", fontsize=14, fontweight="bold")
ax1.set_ylabel("Price Domain")
ax1.grid(True, linestyle="--", alpha=0.3)

ax2.bar(df.index, df["volume"], color="#E0E3EB", alpha=0.3, label="Raw Volume Bars")
ax2.plot(df.index, df["volume_ma"], color="#2962FF", label="Volume 8 MA Line", linewidth=1.8)
ax2.plot(df.index, df["vol_low"], color="#FF6D00", label="Low-Pass Vol Wave (Crests)", linewidth=2.5)
ax2.set_ylabel("Volume Domain")
ax2.grid(True, linestyle="--", alpha=0.3)

ax3.plot(df.index, df["combined_high_wave"], color="#7B1FA2", label="Synthesized Wave Envelope", linewidth=2.0)
ax3.plot(df.index, df["price_high"], color="#26a69a", label="Rolling Price Component", linewidth=1.0, linestyle=":", alpha=0.5)
ax3.plot(df.index, df["vol_high"], color="#2962FF", label="Rolling Volume Component", linewidth=1.0, linestyle=":", alpha=0.5)
ax3.axhline(0, color="black", linestyle="-", alpha=0.4)
ax3.set_ylim(-2.5, 2.5)
ax3.set_ylabel("Synthesized Scale [-2, 2]")
ax3.set_xlabel("Timeline")
ax3.grid(True, linestyle="--", alpha=0.3)

crest_times = [df.index[c["index"]] for c in detected_crests]
crest_vals = [c["volume_low_val"] for c in detected_crests]
ax2.plot(crest_times, crest_vals, marker="o", color="#7B1FA2", markersize=10, linestyle="None", label="Validated Wave Crest Apex", zorder=12)

for c_time in crest_times:
    ax2.axvline(x=c_time, color="#7B1FA2", linestyle=":", alpha=0.3, linewidth=1.2)

buy_legend_added = False
for sig in fine_tuned_signals:
    ax1.plot(sig["time"], sig["price"], marker="^", color="#00E676", markersize=14, linestyle="None", zorder=10)
    ax2.plot(sig["time"], sig["vol_low_val"], marker="o", color="#7B1FA2", markersize=10, linestyle="None", zorder=10)
    ax3.axvline(x=sig["time"], color="#00E676", linestyle=":", alpha=0.7, linewidth=2)
    
    if not buy_legend_added:
        ax1.plot([], [], marker="^", color="#00E676", linestyle="None", label="Derivative Apex Entry Trigger")
        buy_legend_added = True

ax1.legend(loc="upper left")
ax2.legend(loc="upper left")
ax3.legend(loc="upper left")

plt.show()