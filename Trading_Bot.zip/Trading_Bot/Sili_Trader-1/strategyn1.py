"""Strategy utilities for Sili_Trader.

This module lives separately from the data-fetching logic so the strategy can be
re-used with different data sources (e.g., saved CSVs, other brokers, etc.).

The main function in this module, ``find_rdc``, is a simple pattern detector.
It scans the most recent candles (based on a configurable loopback window) and
looks for a candle that closes inside the previous candle's range but has a
longer upper or lower wick.
"""

import logging
import pandas as pd
from config import LOOPBACK_CANDLES  # Import the loopback config
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from config import TREND_CONFIG, WICK_REJECTION_CONFIG



def find_rdc(df: pd.DataFrame, pair: str, timeframe_key: str):
    """
    Iterates through a DataFrame to find a specific two-candle pattern based on the timeframe key.

    Args:
        df (pd.DataFrame): The input DataFrame of candle data.
        pair (str): The currency pair being analyzed (e.g., "EUR_USD").
        timeframe_key (str): The key for the timeframe from config (e.g., "rdc_tf", "manipulation_tf").

    Returns:
        tuple(bool, pd.Timestamp, str|None, pd.Timestamp|None) or bool:
        - (True, preceding_candle_time, proceeding_candle_type, proceeding_candle_time) if the pattern is found.
        - False if the pattern is not found.
    """
    # --- FIX: Get the correct loopback value from the config dictionary ---
    try:
        loopback = LOOPBACK_CANDLES[timeframe_key]
    except KeyError:
        print(f"Error: Timeframe key '{timeframe_key}' not found in LOOPBACK_CANDLES config")
        return False

    print(f"Analyzing {pair} on {timeframe_key} with a loopback of {loopback} candles...")

    # Ensure the DataFrame has enough data for the loopback
    if len(df) < loopback + 1:
        print(f"Not enough data to perform analysis (need {loopback + 1}, have {len(df)}).")
        return False

    # Get the last 'n' candles to analyze
    recent_candles = df.iloc[-(loopback + 1):]
    
    for i in range(1, len(recent_candles)):
        preceding_candle = recent_candles.iloc[i-1]
        proceding_candle = recent_candles.iloc[i]

        # --- helps determine the bearish high wick out or bullish low wick out ---
        #---  this is paramount to determine the direction for take profit i.e opposite the wick out direction ---
        # Use pre-calculated body_size from data.py (feature engineering)
        body = proceding_candle['body_size'] 
        
        # Avoid division by zero - if body is too small, treat as zero
        if body > 0:
            lower_wick_to_body_ratio = proceding_candle['lower_wick'] / body
            upper_wick_to_body_ratio = proceding_candle['upper_wick'] / body
        else:
            # For doji or very small body, use zero ratio (no significant rejection)
            lower_wick_to_body_ratio = 0
            upper_wick_to_body_ratio = 0
        
        # Get thresholds from config
        lower_wick_threshold = WICK_REJECTION_CONFIG['lower_wick_to_body_threshold']
        upper_wick_threshold = WICK_REJECTION_CONFIG['upper_wick_to_body_threshold']
        
        # Check pair logic based on candle type
        is_pair_found = False
        
        if preceding_candle['candle_type'] == "Bearish":
            if proceding_candle['high'] > preceding_candle['high']:
                if (proceding_candle['close'] <= preceding_candle['open'] and
                    upper_wick_to_body_ratio <= upper_wick_threshold):
                    is_pair_found = True
            elif proceding_candle['low'] < preceding_candle['low']:
                if (proceding_candle['close'] >= preceding_candle['close'] and
                    lower_wick_to_body_ratio <= lower_wick_threshold):
                    is_pair_found = True
                    
        elif preceding_candle['candle_type'] == "Bullish":
            if proceding_candle['high'] > preceding_candle['high']:
                if (proceding_candle['close'] <= preceding_candle['close'] and
                    upper_wick_to_body_ratio <= upper_wick_threshold):
                    is_pair_found = True
            elif proceding_candle['low'] < preceding_candle['low']:
                if (proceding_candle['close'] >= preceding_candle['open'] and
                    lower_wick_to_body_ratio <= lower_wick_threshold):
                    is_pair_found = True

        if is_pair_found:
            # Cache the proceeding candle's type from the DataFrame if available
            proceeding_candle_type = (
                proceding_candle['candle_type']
                if 'candle_type' in proceding_candle.index
                else None
            )

            preceding_candle_type = (
                preceding_candle['candle_type']
                if 'candle_type' in preceding_candle.index
                else None 
            )
            
            pre_high = preceding_candle['high']
            pre_low = preceding_candle['low']
            pro_high = preceding_candle['high']
            pro_low = preceding_candle['low']
            
            # Determine proceeding candle datetime: prefer a 'time' column, otherwise use the row index (name)
            if 'time' in proceding_candle.index and pd.notnull(proceding_candle['time']):
                pro_time = proceding_candle['time']
            else:
                pro_time = proceding_candle.name

            # Determine preceding candle datetime similarly
            if 'time' in preceding_candle.index and pd.notnull(preceding_candle['time']):
                pre_time = preceding_candle['time']
            else:
                pre_time = preceding_candle.name

            logging.info(f"✅ Signal FOUND for {pair} on {timeframe_key}! @ {pre_time} \n  Proceeding candle type: {proceeding_candle_type} @ {pro_time}")
            return (True, pre_time, pro_time, proceeding_candle_type, pro_high, pro_low,pre_high, pre_low)

    # If the loop completes without finding the signal
    return False

def detect_trend(data):

    data = data.copy()

    # Initialize columns
    data['HH'] = False
    data['LH'] = False
    data['HL'] = False
    data['LL'] = False
    data['Trend'] = "Sideways"

    for i in range(1, len(data)):

        # Higher High / Lower High
        if data['high'].iloc[i] > data['high'].iloc[i-1]:
            data.iloc[i, data.columns.get_loc('HH')] = True
        elif data['high'].iloc[i] < data['high'].iloc[i-1]:
            data.iloc[i, data.columns.get_loc('LH')] = True

        # Higher Low / Lower Low
        if data['low'].iloc[i] > data['low'].iloc[i-1]:
            data.iloc[i, data.columns.get_loc('HL')] = True
        elif data['low'].iloc[i] < data['low'].iloc[i-1]:
            data.iloc[i, data.columns.get_loc('LL')] = True

        # Trend Logic
        if data['HL'].iloc[i] and data['HH'].iloc[i]:
            data.iloc[i, data.columns.get_loc('Trend')] = "Uptrend"

        elif data['LH'].iloc[i] and data['LL'].iloc[i]:
            data.iloc[i, data.columns.get_loc('Trend')] = "Downtrend"

        else:
            data.iloc[i, data.columns.get_loc('Trend')] = data['Trend'].iloc[i-1]

    return data

# ==========================
# TIMEFRAME TO MINUTES
# ==========================

def timeframe_to_minutes(tf):

    tf = tf.lower()

    if "m" in tf:
        return int(tf.replace("m",""))
    if "h" in tf:
        return int(tf.replace("h","")) * 60
    if "d" in tf:
        return int(tf.replace("d","")) * 1440

    raise ValueError(f"Unsupported timeframe: {tf}")


# ==========================
# WINDOW CALCULATION
# ==========================

def compute_window(timeframe):

    ref_tf = TREND_CONFIG["reference_timeframe"]

    base_minutes = timeframe_to_minutes(ref_tf)
    tf_minutes = timeframe_to_minutes(timeframe)

    window = int(base_minutes / tf_minutes)

    return max(window,1)


# ==========================
# SLOPE CALCULATION
# ==========================

def rolling_normalized_slope(x):

    y = x.values
    X = np.arange(len(y)).reshape(-1,1)

    model = LinearRegression()
    model.fit(X, y)

    slope = model.coef_[0]
    mean_price = np.mean(y)

    return slope / mean_price

# ==========================
# TIMEFRAME TO MINUTES
# ==========================

def timeframe_to_minutes(tf):

    tf = tf.lower()

    if "m" in tf:
        return int(tf.replace("m",""))
    if "h" in tf:
        return int(tf.replace("h","")) * 60
    if "d" in tf:
        return int(tf.replace("d","")) * 1440

    raise ValueError(f"Unsupported timeframe: {tf}")


# ==========================
# WINDOW CALCULATION
# ==========================

def compute_window(timeframe):

    ref_tf = TREND_CONFIG["reference_timeframe"]

    base_minutes = timeframe_to_minutes(ref_tf)
    tf_minutes = timeframe_to_minutes(timeframe)

    window = int(base_minutes / tf_minutes)

    return max(window,1)


# ==========================
# SLOPE CALCULATION
# ==========================

def rolling_normalized_slope(x):

    y = x.values
    X = np.arange(len(y)).reshape(-1,1)

    model = LinearRegression()
    model.fit(X, y)

    slope = model.coef_[0]
    mean_price = np.mean(y)

    return slope / mean_price


# ==========================
# THRESHOLD CALCULATION
# ==========================

def compute_threshold(price):

    mode = TREND_CONFIG["threshold_mode"]

    # --------------------
    # VOLATILITY MODE
    # --------------------

    if mode == "volatility":

        vol_window = TREND_CONFIG["volatility_window"]

        volatility = price.pct_change().rolling(vol_window).std()

        threshold = np.maximum(
            TREND_CONFIG["minimum_threshold"],
            volatility * TREND_CONFIG["volatility_multiplier"]
        )

        return threshold


    # --------------------
    # FIXED MODE
    # --------------------

    elif mode == "fixed":

        return TREND_CONFIG["minimum_threshold"]

    else:
        raise ValueError("Invalid threshold_mode in config")


# ==========================
# MAIN TREND ANALYSIS
# ==========================

def trend_analysis(df, timeframe, price_column="close"):

    price = df[price_column]

    # --------------------
    # dynamic window
    # --------------------

    window = compute_window(timeframe)

    # --------------------
    # rolling regression
    # --------------------

    rolling_trend = price.rolling(window).apply(
        rolling_normalized_slope,
        raw=False
    )

    # --------------------
    # threshold
    # --------------------

    threshold = compute_threshold(price)

    # --------------------
    # trend classification
    # --------------------

    trend_direction = np.where(
        rolling_trend > threshold,
        "Uptrend",
        np.where(
            rolling_trend < -threshold,
            "Downtrend",
            "Sideways"
        )
    )

    trend_df = pd.DataFrame({

        "price": price,
        "trend_strength": rolling_trend,
        "threshold": threshold,
        "trend_direction": trend_direction

    })

    return trend_df


def analyze_trend_in_range(
        df,
        start_time,
        end_time,
        timeframe='15min',
        price_column='close',
        plot=False):
    """
    Analyzes the overall trend within a specific time range by fitting a single linear regression line.

    Args:
        df (pd.DataFrame): DataFrame containing price data with a datetime index.
        start_time: The start date/time for the analysis.
        end_time: The end date/time for the analysis.
        timeframe (str): The timeframe for resampling (pandas format: '15T', '1H', '4H', etc.).
        price_column (str): The name of the column containing the price data.
        plot (bool): If True, a plot of the price and its trendline will be displayed.

    Returns:
        dict: A dictionary containing the trend direction, normalized slope, start price, and end price.
    """
    """
    if __name__ == '__main__':

        file = './forex_data/EUR_USD_H4.csv' 

        if os.path.exists(file):
            print("Running example analysis...")
            trend_info = analyze_trend_in_range(
                file_path=file,
                start_time="2026-02-01", # Define your start date
                end_time="2026-02-28", # Define your end date
                timeframe='4H',
                plot=True
            )
            if trend_info:
                print("\n--- Analysis Result ---")
                print(f"Overall Trend: {trend_info['trend_direction']}")
                print(f"Trend Strength (Normalized Slope): {trend_info['normalized_slope']:.6f}")
                print(f"Price at Start: {trend_info['start_price']:.5f}")
                print(f"Price at End: {trend_info['end_price']:.5f}")
        else:
            print(f"Example file not found: {file}")
            print("Please ensure the file exists or update the path.")
    """
    # Convert OANDA timeframe format to pandas format for resampling
    # OANDA: M15 -> pandas: 15min, H1 -> pandas: 1H, H4 -> pandas: 4H
    oanda_to_pandas = {
        'M15': '15min',
        'M5': '5min',
        'M1': '1min',
        'H1': '1H',
        'H4': '4H',
        'D': 'D'
    }
    pandas_timeframe = oanda_to_pandas.get(timeframe, timeframe)

    # Resample to desired timeframe and get the full price series
    price = df[price_column].resample(pandas_timeframe).last().dropna()

    # --- MODIFICATION START ---
    # 1. Select the specific slice of data based on the provided time range
    price_slice = price.loc[start_time:end_time]

    if price_slice.empty:
        print(f"No data found in the specified range: {start_time} to {end_time}")
        return None

    # 2. Apply the linear regression to the entire slice, not a rolling window
    y = price_slice.values
    # Create a simple time axis [0, 1, 2,...] for the X values
    X = np.arange(len(y)).reshape(-1, 1)

    model = LinearRegression()
    model.fit(X, y)

    # Calculate the normalized slope for the entire range
    slope = model.coef_[0]
    mean_price = np.mean(y)
    normalized_slope = slope / mean_price

    # 3. Classify the single trend for the whole period
    if normalized_slope > 0:
        trend_direction = "Uptrend"
    else:
        trend_direction = "Downtrend"
    # A zero slope is highly unlikely but would be classified as Downtrend here.

    # 4. Prepare the results in a dictionary
    result = {
        "trend_direction": trend_direction,
        "normalized_slope": normalized_slope,
        "start_price": price_slice.iloc[0],
        "end_price": price_slice.iloc[-1]
    }
    # --- MODIFICATION END ---

    # Plot if requested
    if plot:
        # Create the trendline for plotting using the model's prediction
        trendline = model.predict(X)

        plt.figure(figsize=(12, 6))
        
        # Plot the actual price data for the slice
        plt.plot(price_slice.index, price_slice.values, label=f"Price ({timeframe})", marker='o', linestyle='-')
        
        # Plot the calculated trendline over the same data
        plt.plot(price_slice.index, trendline, color='red', linestyle='--', label=f"Overall Trendline (Slope: {normalized_slope:.6f})")
        
        plt.title(f"Trend Analysis from {start_time} to {end_time}")
        plt.xlabel("Date")
        plt.ylabel("Price")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()
    return result

def range_price_to_percent(price, high, low):
    """
    Returns the percentage position of price inside a range.
    """

    if high == low:
        return None

    percentage = ((price - low) * 100) / (high - low)

    return percentage

def range_percentage_to_price(percent, high, low):
    """
    Returns the price corresponding to a percentage of a range.
    """

    price = (percent * (high - low) / 100) + low

    return price


