"""Strategy utilities for Sili_Trader.

This module lives separately from the data-fetching logic so the strategy can be
re-used with different data sources (e.g., saved CSVs, other brokers, etc.).

The main function in this module, ``find_rdc``, is a simple pattern detector.
It scans the most recent candles (based on a configurable loopback window) and
looks for a candle that closes inside the previous candle's range but has a
longer upper or lower wick.
"""

import logging
import pandas as pd
from config import LOOPBACK_CANDLES  # Import the loopback config
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from config import TREND_CONFIG, WICK_REJECTION_CONFIG


