import logging
from pathlib import Path
from typing import Dict, Iterable

import pandas as pd


OANDA_TO_PANDAS = {
    "M1": "1min",
    "M5": "5min",
    "M15": "15min",
    "H1": "1H",
    "H4": "4H",
    "D": "1D",
}


class BacktestCandleFetcher:
    """Replays saved CSV candles from oldest to newest like a live feed."""

    def __init__(self, data_dir: str, instruments: Iterable[str], base_granularity: str = "M15"):
        self.data_dir = Path(data_dir)
        self.base_granularity = base_granularity
        self.market_data: Dict[str, pd.DataFrame] = {}
        self.cursor: Dict[str, int] = {}

        for instrument in instruments:
            path = self.data_dir / f"{instrument}.csv"
            if not path.exists():
                logging.warning(f"[BT DATA] Missing CSV for {instrument}: {path}")
                continue

            df = pd.read_csv(path)
            if df.empty:
                logging.warning(f"[BT DATA] Empty CSV for {instrument}: {path}")
                continue

            if "time" not in df.columns:
                logging.warning(f"[BT DATA] No 'time' column for {instrument}: {path}")
                continue

            df["time"] = pd.to_datetime(df["time"], utc=True)
            df = df.sort_values("time").set_index("time")

            numeric_cols = ["open", "high", "low", "close", "volume"]
            existing_numeric = [col for col in numeric_cols if col in df.columns]
            df = df[existing_numeric].copy()

            self._add_candle_features(df)

            self.market_data[instrument] = df
            self.cursor[instrument] = -1

        if not self.market_data:
            raise ValueError(
                f"No valid CSV candle files found in {self.data_dir}. "
                "Expected files like EUR_USD.csv, USD_JPY.csv"
            )

    @staticmethod
    def _add_candle_features(df: pd.DataFrame) -> None:
        df["candle_type"] = "Neutral"
        df.loc[df["close"] > df["open"], "candle_type"] = "Bullish"
        df.loc[df["close"] < df["open"], "candle_type"] = "Bearish"

        df["body_size"] = (df["close"] - df["open"]).abs()
        df["upper_wick"] = df["high"] - df[["open", "close"]].max(axis=1)
        df["lower_wick"] = df[["open", "close"]].min(axis=1) - df["low"]

    def start_price_stream(self):
        return

    def advance_market(self) -> bool:
        advanced = False
        for instrument, df in self.market_data.items():
            current = self.cursor[instrument]
            if current < len(df) - 1:
                self.cursor[instrument] = current + 1
                advanced = True
        return advanced

    def replay_finished(self, instrument: str) -> bool:
        if instrument not in self.market_data:
            return True
        return self.cursor[instrument] >= len(self.market_data[instrument]) - 1

    def _visible_df(self, instrument: str) -> pd.DataFrame:
        if instrument not in self.market_data:
            return pd.DataFrame()

        visible_rows = self.cursor[instrument] + 1
        if visible_rows <= 0:
            return pd.DataFrame()

        return self.market_data[instrument].iloc[:visible_rows].copy()

    def get_candles(self, instrument, granularity, count):
        df = self._visible_df(instrument)
        if df.empty:
            return df

        if granularity == self.base_granularity:
            return df.tail(count)

        pandas_tf = OANDA_TO_PANDAS.get(granularity)
        if not pandas_tf:
            raise ValueError(f"Unsupported OANDA granularity: {granularity}")

        resampled = (
            df.resample(pandas_tf)
            .agg(
                {
                    "open": "first",
                    "high": "max",
                    "low": "min",
                    "close": "last",
                    "volume": "sum",
                }
            )
            .dropna()
        )

        if resampled.empty:
            return resampled

        self._add_candle_features(resampled)
        return resampled.tail(count)

    def get_current_price(self, instrument, timeout=10):
        df = self._visible_df(instrument)
        if df.empty:
            return None

        last = df.iloc[-1]
        ts = df.index[-1]
        mid = float(last["close"])

        price_df = pd.DataFrame(
            [{"time": ts, "bid": mid, "ask": mid, "mid": mid, "spread": 0.0}]
        )
        price_df.set_index("time", inplace=True)
        return price_df
