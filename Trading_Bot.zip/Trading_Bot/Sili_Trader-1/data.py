"""OANDA candle data fetcher for Sili_Trader.

This module handles the low-level API interaction with OANDA and returns a
pandas DataFrame of OHLCV candles enriched with a few useful derived columns.

It is intentionally lightweight: other parts of the project (e.g., strategy.py)
should not need to know any OANDA API details.
"""

import time
import logging
import threading
import oandapyV20
import pandas as pd
from pathlib import Path
import oandapyV20.endpoints.orders as orders
import oandapyV20.endpoints.pricing as pricing
import oandapyV20.endpoints.accounts as accounts
import oandapyV20.endpoints.instruments as instruments
from config import OANDA_ACCOUNT_ID, OANDA_API_KEY, OANDA_ENVIRONMENT,INSTRUMENTS

logging.basicConfig(level=logging.INFO)


class CandleFetcher:
    """Simple wrapper around the OANDA REST API for fetching historical candles."""

    def __init__(self):
        # The OANDA client requires API key + environment (practice / live).
        # We keep the key in config.py for easy swapping.
        self.client = oandapyV20.API(
            access_token=OANDA_API_KEY,
            environment=OANDA_ENVIRONMENT
        )
        
        self.price_cache = {}
        self.stream_running = False
        self.forex_data_dir = Path("/run/media/solace/ABBA-2E35/My_Code/Sili_Trader/forex_data")
        self.forex_data_dir.mkdir(parents=True, exist_ok=True)

    def get_candles(self, instrument, granularity, count):
        """Return a pandas DataFrame of the most recent candles.

        Args:
            instrument (str): Candle instrument, e.g. "EUR_USD".
            granularity (str): Timeframe string accepted by OANDA (e.g. "H4", "H1").
            count (int): Number of candles to fetch.

        Returns:
            pd.DataFrame: Indexed by timestamp with columns [open, high, low, close,
            volume, candle_type, body_size, upper_wick, lower_wick]. If no data is
            returned by OANDA, this will be an empty DataFrame.
        """
        params = {
            "granularity": granularity,
            "count": count,
            "price": "M"  # Use the mid price (average of bid/ask) for analysis.
        }

        r = instruments.InstrumentsCandles(
            instrument=instrument,
            params=params
        )

        response = self.client.request(r)
        candles = []

        # Convert OANDA JSON into a list of rows that pandas can consume.
        for candle in response["candles"]:
            # Only include fully-formed (complete) candles.
            if candle["complete"]:
                candles.append({
                    "time": pd.to_datetime(candle["time"]),
                    "open": float(candle["mid"]["o"]),
                    "high": float(candle["mid"]["h"]),
                    "low": float(candle["mid"]["l"]),
                    "close": float(candle["mid"]["c"]),
                    "volume": int(candle["volume"])
                })

        # Create a DataFrame and use the timestamp as the index.
        df = pd.DataFrame(candles)
        df.set_index("time", inplace=True)

        # Return early if no candles were fetched.
        if df.empty:
            return df
        
        # Function to detect bullish/bearish candles
        def detect_candle_type(row):
            if row['close'] > row['open']:
                return 'Bullish'
            elif row['close'] < row['open']:
                return 'Bearish'
            else:
                return 'Neutral'

        # Function to calculate body size
        def calculate_body_size(row):
            # Body is the absolute distance between open and close.
            return abs(row["close"] - row["open"])

        # Function to calculate wick lengths
        def calculate_wick_lengths(row):
            upper_wick = row['high'] - max(row['open'], row['close'])
            lower_wick = min(row['open'], row['close']) - row['low']
            return upper_wick, lower_wick

        # Apply functions to candleFrame
        df['candle_type'] = df.apply(detect_candle_type, axis=1)
        df['body_size'] = df.apply(calculate_body_size, axis=1)
        df[['upper_wick', 'lower_wick']] = df.apply(calculate_wick_lengths, axis=1, result_type='expand')

        # Save candles per pair and overwrite previous file on each call.
        output_file = self.forex_data_dir / f"{instrument}.csv"
        df.to_csv(output_file, index=True)
    
        return df
    
    def get_current_price(self, instrument, timeout=10):

        start = time.time()

        while instrument not in self.price_cache:

            if time.time() - start > timeout:
                logging.warning(f"No price received yet for {instrument}")
                return None

            time.sleep(0.05)

        return self.price_cache[instrument]

    def start_price_stream(self):

        if self.stream_running:
            return

        self.stream_running = True

        def stream():

            params = {
                "instruments": ",".join(INSTRUMENTS)  # stream all pairs
            }

            r = pricing.PricingStream(
                accountID=OANDA_ACCOUNT_ID,
                params=params
            )

            try:
                for tick in self.client.request(r):

                    if tick.get("type") != "PRICE":
                        continue

                    instrument = tick["instrument"]

                    if not tick.get("bids") or not tick.get("asks"):
                        continue

                    bid = float(tick["bids"][0]["price"])
                    ask = float(tick["asks"][0]["price"])

                    data = {
                        "time": pd.to_datetime(tick["time"]),
                        "bid": bid,
                        "ask": ask,
                        "mid": (bid + ask) / 2,
                        "spread": ask - bid
                    }

                    df = pd.DataFrame([data])
                    df.set_index("time", inplace=True)

                    self.price_cache[instrument] = df

            except Exception as e:
                logging.error(f"Price stream error: {e}")

        thread = threading.Thread(target=stream, daemon=True)
        thread.start()
