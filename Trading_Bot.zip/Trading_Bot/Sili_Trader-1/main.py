"""main.py — Sili_Trader unified entry point.

Controls are in config.py:
    BACKTEST_MODE = False   →  live trading via OANDA
    BACKTEST_MODE = True    →  CSV replay (backtest)

The strategy loop is written ONCE here.  Any change to strategyn1.py,
watcher.py, or execution.py is automatically reflected in both modes.

Run modes
---------
Live trading:
    python main.py

Backtest with chart server (recommended):
    uvicorn chart_server:app --host 0.0.0.0 --port 8000
    # chart_server.py calls run() in a background thread automatically.

Backtest without chart server (terminal-only):
    python main.py          # with BACKTEST_MODE = True in config.py
"""

import os
import time
import logging
from typing import Optional

import pandas as pd

from config import (
    INSTRUMENTS,
    CRT_TIMEFRAMES,
    BACKTEST_MODE,
    BACKTEST_TIMEFRAME_RELATIVITY_SECONDS,
)

from strategyn1 import find_rdc, analyze_trend_in_range, range_price_to_percent

# ---------------------------------------------------------------------------
# Mode-specific setup — must happen before watcher is imported so the
# monkey-patch takes effect before Watcher.__init__ calls TradeExecutor()
# ---------------------------------------------------------------------------

if BACKTEST_MODE:
    import watcher as _watcher_module
    from backtest import (
        SimulatedTradeExecutor,
        BacktestCSVFetcher,
        candle_store,
        push_candles,
        _norm,
        BACKTEST_DATA_DIR,
        BACKTEST_STATE_FILE,
        BACKTEST_LOG_FILE,
    )
    _watcher_module.STATE_FILE    = BACKTEST_STATE_FILE
    _watcher_module.TradeExecutor = SimulatedTradeExecutor
else:
    from data import CandleFetcher  # only imported in live mode

from watcher import Watcher  # import AFTER patch so it picks up SimulatedTradeExecutor


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def _setup_logging() -> None:
    handlers = [logging.StreamHandler()]
    if BACKTEST_MODE:
        os.makedirs(BACKTEST_DATA_DIR, exist_ok=True)
        handlers.append(
            logging.FileHandler(BACKTEST_LOG_FILE, mode="a", encoding="utf-8")
        )
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
        force=True,
    )


# ---------------------------------------------------------------------------
# Strategy analysis — identical for both modes
# ---------------------------------------------------------------------------

def _analyze_pair(pair: str, fetcher) -> Optional[dict]:
    """Run the full signal pipeline for one pair.

    Returns a signal dict on success or None.
    This function is intentionally mode-agnostic — it calls fetcher methods
    that exist on both CandleFetcher and BacktestCSVFetcher.
    """
    rdc_signal: Optional[dict] = None

    for tf_key, tf_val in CRT_TIMEFRAMES.items():
        df = fetcher.get_candles(pair, tf_val, 1000)
        if df.empty:
            continue

        if tf_key == "rdc_tf":
            result = find_rdc(df, pair, tf_key)
            if not result:
                rdc_signal = None
                continue

            (_, pre_time, pro_time, pro_candle_type,
            pro_high, pro_low, pre_high, pre_low) = result

            rdc_signal = {
                "preceding_time":      pre_time,
                "proceding_time":      pro_time,
                "proceding_candle_type": pro_candle_type,
                "pro_high": pro_high,
                "pro_low":  pro_low,
                "pre_high": pre_high,
                "pre_low":  pre_low,
            }
            logging.info(f"[RDC FOUND] {pair}")

        elif tf_key == "execution_tf":
            if not rdc_signal:
                continue

            start_time = rdc_signal["proceding_time"]
            end_time   = start_time + pd.Timedelta(hours=4)

            trend_result = analyze_trend_in_range(df, start_time, end_time, tf_val)
            if not trend_result:
                continue

            price_df = fetcher.get_current_price(pair)
            if price_df is None:
                continue

            current_price = float(price_df["mid"].iloc[0])
            percent = range_price_to_percent(
                price=current_price,
                high=rdc_signal["pro_high"],
                low=rdc_signal["pro_low"],
            )
            candle_count = int(len(df[df.index >= rdc_signal["proceding_time"]]))

            logging.info(
                f"[DEBUG] {pair} | %={percent:.2f} | "
                f"trend={trend_result['trend_direction']} | "
                f"candles_since_rdc={candle_count}"
            )

            rdc_signal.update({
                "trend_direction":  trend_result["trend_direction"],
                "normalized_slope": trend_result["normalized_slope"],
                "percent":          percent,
                "candle_count":     candle_count,
                "current_price":    current_price,
            })
            return rdc_signal

    return None


# ---------------------------------------------------------------------------
# Main run function — called by chart_server.py lifespan OR __main__
# ---------------------------------------------------------------------------

def run() -> None:
    _setup_logging()

    # ── Fetcher & sleep ────────────────────────────────────────────────────
    if BACKTEST_MODE:
        exec_tf  = _norm(CRT_TIMEFRAMES.get("execution_tf", "M15"))
        sleep_s  = float(BACKTEST_TIMEFRAME_RELATIVITY_SECONDS.get(exec_tf, 1.0))
        fetcher  = BacktestCSVFetcher(
            data_dir=BACKTEST_DATA_DIR,
            instruments=INSTRUMENTS,
            base_granularity=exec_tf,
        )
    else:
        sleep_s = 60
        fetcher = CandleFetcher()

    watcher = Watcher(fetcher)
    fetcher.start_price_stream()
    watcher.load_state()

    pairs   = list(fetcher.market_data.keys()) if BACKTEST_MODE else list(INSTRUMENTS)
    missing = [p for p in INSTRUMENTS if p not in (fetcher.market_data if BACKTEST_MODE else INSTRUMENTS)]
    if missing:
        logging.warning(f"[INIT] No data for: {missing} — skipping")

    logging.info("=" * 60)
    logging.info(f"{'BACKTEST' if BACKTEST_MODE else 'LIVE'} BOT STARTED")
    logging.info(f"    Pairs        : {pairs}")
    logging.info(f"    Loop sleep   : {sleep_s}s")
    if BACKTEST_MODE:
        logging.info(f"    Chart server : http://localhost:8000")
    logging.info("=" * 60)

    # ── Backtest: prime the store with candle 0 ────────────────────────────
    if BACKTEST_MODE:
        for pair in pairs:
            fetcher.advance_pair(pair)
            push_candles(pair, fetcher)

    # ── Main loop ──────────────────────────────────────────────────────────
    while True:
        try:
            # Backtest: advance replay cursor + push to chart store
            if BACKTEST_MODE:
                if fetcher.all_finished():
                    logging.info("✅ Backtest replay complete — all pairs exhausted")
                    break
                for pair in pairs:
                    if not fetcher.pair_finished(pair):
                        fetcher.advance_pair(pair)
                for pair in pairs:
                    push_candles(pair, fetcher)

            # ── Per-pair strategy logic (identical for both modes) ─────────
            for pair in pairs:

                # Stale thread cleanup
                if pair in watcher.active_watchers:
                    thread = watcher.active_watchers[pair]["thread"]
                    if thread.is_alive():
                        continue
                    logging.warning(f"[STALE] Removing dead watcher for {pair}")
                    del watcher.active_watchers[pair]
                    watcher.save_state()

                if watcher.executor.has_open_position(pair):
                    logging.info(f"[SKIP] Open position exists for {pair}")
                    continue

                logging.info(f"\n{'=' * 50}")
                logging.info(f"Analyzing {pair}")
                logging.info(f"{'=' * 50}")

                signal = _analyze_pair(pair, fetcher)
                if signal is None:
                    continue

                # Push signal to chart store (backtest only — no-op in live mode)
                if BACKTEST_MODE:
                    candle_store.set_signal(pair, signal)

                percent      = signal.get("percent")
                candle_count = signal.get("candle_count", 999)
                trend        = signal.get("trend_direction", "")

                if (candle_count <= 48) and (percent is not None) and (percent <= 35):
                    logging.info(f"[WATCHER] BUY activated for {pair}")
                    watcher.start(
                        pair=pair,
                        trend_direction=trend,
                        preceding_time=signal["preceding_time"],
                        proceding_time=signal["proceding_time"],
                        trade_type="BUY",
                        pro_high=signal["pro_high"],
                        pro_low=signal["pro_low"],
                    )

                elif (candle_count <= 48) and (percent is not None) and (percent >= 65):
                    logging.info(f"[WATCHER] SELL activated for {pair}")
                    watcher.start(
                        pair=pair,
                        trend_direction=trend,
                        preceding_time=signal["preceding_time"],
                        proceding_time=signal["proceding_time"],
                        trade_type="SELL",
                        pro_high=signal["pro_high"],
                        pro_low=signal["pro_low"],
                    )

            logging.info("⏳ Sleeping before next cycle...\n")
            time.sleep(sleep_s)

        except Exception as e:
            logging.error(f"🔥 MAIN LOOP ERROR: {e}", exc_info=True)
            time.sleep(1)

    # ── Backtest teardown ──────────────────────────────────────────────────
    if BACKTEST_MODE:
        watcher.save_state()

        if watcher.logs:
            frames = []
            for pair, df_log in watcher.logs.items():
                if df_log is not None and not df_log.empty:
                    out = df_log.copy()
                    out["pair"] = pair
                    frames.append(out)

            if frames:
                results = pd.concat(frames, ignore_index=True)
                summary_path = os.path.join(BACKTEST_DATA_DIR, "backtest_results.csv")
                results.to_csv(summary_path, index=False)
                logging.info(f"[RESULT] Saved → {summary_path}")

                logging.info("\n" + "=" * 50)
                logging.info("BACKTEST SUMMARY")
                logging.info("=" * 50)
                for pair in results["pair"].unique():
                    sub    = results[results["pair"] == pair]
                    wins   = int((sub["result"] == "WIN").sum())
                    losses = int((sub["result"] == "LOSS").sum())
                    total  = len(sub)
                    wr     = (wins / total * 100) if total else 0.0
                    logging.info(
                        f"  {pair:10s}  {wins}W / {losses}L / {total} trades  WR={wr:.1f}%"
                    )
            else:
                logging.info("[RESULT] No completed trades.")
        else:
            logging.info("[RESULT] No trades triggered.")


# ---------------------------------------------------------------------------
# Entry point — for running directly without the chart server
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    run()