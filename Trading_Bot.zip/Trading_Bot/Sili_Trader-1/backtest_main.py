import os
import time
import logging

import pandas as pd

import mplfinance as mpf

import watcher as watcher_module
from watcher import Watcher
from config import INSTRUMENTS, CRT_TIMEFRAMES
from strategyn1 import (
    find_rdc,
    analyze_trend_in_range,
    range_price_to_percent,
)

# ==========================
# BACKTEST SETTINGS
# ==========================
BACKTEST_DATA_DIR = "/run/media/solace/ABBA-2E35/My_Code/Sili_Trader/forex_data"
BACKTEST_STATE_FILE = os.path.join(BACKTEST_DATA_DIR, "backtest_watcher_state.json")
BACKTEST_LOG_FILE = os.path.join(BACKTEST_DATA_DIR, "backtest_log.log")

# Optional config override (if user adds this to config.py later)
try:
    from config import BACKTEST_TIMEFRAME_RELATIVITY_SECONDS as CONFIG_BACKTEST_RELATIVITY
except ImportError:
    CONFIG_BACKTEST_RELATIVITY = None

DEFAULT_BACKTEST_RELATIVITY_SECONDS = {
    "H4": 5,
    "H1": 3,
    "M15": 1,
    "15M": 1,
}


class BacktestCandleViewer:
    """Live candlestick viewer for replay candles using mplfinance."""

    def __init__(self, enabled=True, window_size=120):
        self.enabled = enabled
        self.window_size = window_size
        self.figure = None
        self.ax_price = None

        if self.enabled:
            self.figure = mpf.figure(figsize=(12, 6), style="charles")
            self.ax_price = self.figure.add_subplot(1, 1, 1)
            self.figure.show()

    def update(self, pair, timeframe, df):
        if not self.enabled or df.empty:
            return

        candle_df = df[["open", "high", "low", "close"]].tail(self.window_size).copy()
        self.ax_price.clear()

        mpf.plot(
            candle_df,
            type="candle",
            style="charles",
            ax=self.ax_price,
            axtitle=f"Backtest Live Candles | {pair} | {timeframe}",
            datetime_format="%Y-%m-%d %H:%M",
            xrotation=15,
            warn_too_much_data=10000,
        )

        self.figure.tight_layout()
        self.figure.canvas.draw_idle()
        self.figure.canvas.flush_events()

    def close(self):
        if self.enabled and self.figure is not None:
            self.figure.clear()


def setup_backtest_logging():
    """Log to both terminal and a persistent backtest log file."""
    log_format = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"

    file_handler = logging.FileHandler(BACKTEST_LOG_FILE, mode="a", encoding="utf-8")
    stream_handler = logging.StreamHandler()

    logging.basicConfig(
        level=logging.INFO,
        format=log_format,
        datefmt=date_format,
        handlers=[file_handler, stream_handler],
        force=True,
    )


class SimulatedTradeExecutor:
    """Runtime-only drop-in replacement for live TradeExecutor."""

    def __init__(self):
        self.order_events = []

    def buy(self, instrument, units, stop_loss=None, take_profit=None):
        self.order_events.append(
            {
                "instrument": instrument,
                "side": "BUY",
                "units": abs(units),
                "sl": stop_loss,
                "tp": take_profit,
                "timestamp": pd.Timestamp.now(tz="UTC"),
            }
        )
        return {"instrument": instrument, "side": "BUY"}

    def sell(self, instrument, units, stop_loss=None, take_profit=None):
        self.order_events.append(
            {
                "instrument": instrument,
                "side": "SELL",
                "units": -abs(units),
                "sl": stop_loss,
                "tp": take_profit,
                "timestamp": pd.Timestamp.now(tz="UTC"),
            }
        )
        return {"instrument": instrument, "side": "SELL"}

    def has_open_position(self, instrument):
        # Backtest uses watcher thread state for lifecycle, not broker position state.
        return False

    def get_open_trade_details(self, instrument):
        return None


class BacktestCSVFetcher:
    """CSV replay fetcher with the same interface main.py expects from CandleFetcher."""

    OANDA_TO_PANDAS = {
        "M1": "1min",
        "M5": "5min",
        "M15": "15min",
        "H1": "1H",
        "H4": "4H",
        "D": "1D",
    }

    def __init__(self, data_dir, instruments, base_granularity="M15"):
        self.data_dir = data_dir
        self.base_granularity = base_granularity
        self.market_data = {}
        self.cursor = {}

        for pair in instruments:
            csv_path = os.path.join(self.data_dir, f"{pair}.csv")

            if not os.path.exists(csv_path):
                logging.warning(f"[BT DATA] Missing file for {pair}: {csv_path}")
                continue

            df = pd.read_csv(csv_path)
            if df.empty or "time" not in df.columns:
                logging.warning(f"[BT DATA] Invalid file for {pair}: {csv_path}")
                continue

            df["time"] = pd.to_datetime(df["time"], utc=True)
            df = df.sort_values("time").set_index("time")

            cols = ["open", "high", "low", "close", "volume"]
            df = df[[c for c in cols if c in df.columns]].copy()

            self._add_candle_features(df)

            self.market_data[pair] = df
            self.cursor[pair] = -1

        if not self.market_data:
            raise ValueError(
                f"No valid pair CSV files found in {self.data_dir}. "
                "Expected files like EUR_USD.csv"
            )

    @staticmethod
    def _add_candle_features(df):
        df["candle_type"] = "Neutral"
        df.loc[df["close"] > df["open"], "candle_type"] = "Bullish"
        df.loc[df["close"] < df["open"], "candle_type"] = "Bearish"

        df["body_size"] = (df["close"] - df["open"]).abs()
        df["upper_wick"] = df["high"] - df[["open", "close"]].max(axis=1)
        df["lower_wick"] = df[["open", "close"]].min(axis=1) - df["low"]

    def start_price_stream(self):
        return

    def advance_market(self):
        """Advance one candle for each available pair (oldest -> newest)."""
        moved = False

        for pair, df in self.market_data.items():
            idx = self.cursor[pair]
            if idx < len(df) - 1:
                self.cursor[pair] = idx + 1
                moved = True

        return moved

    def _visible_df(self, pair):
        if pair not in self.market_data:
            return pd.DataFrame()

        visible_rows = self.cursor[pair] + 1
        if visible_rows <= 0:
            return pd.DataFrame()

        return self.market_data[pair].iloc[:visible_rows].copy()

    def get_candles(self, instrument, granularity, count):
        df = self._visible_df(instrument)
        if df.empty:
            return df

        if granularity == self.base_granularity:
            return df.tail(count)

        pandas_tf = self.OANDA_TO_PANDAS.get(granularity)
        if not pandas_tf:
            raise ValueError(f"Unsupported granularity: {granularity}")

        out = (
            df.resample(pandas_tf)
            .agg(
                {
                    "open": "first",
                    "high": "max",
                    "low": "min",
                    "close": "last",
                    "volume": "sum",
                }
            )
            .dropna()
        )

        if out.empty:
            return out

        self._add_candle_features(out)
        return out.tail(count)

    def get_current_price(self, instrument, timeout=10):
        df = self._visible_df(instrument)
        if df.empty:
            return None

        row = df.iloc[-1]
        ts = df.index[-1]
        mid = float(row["close"])

        price_df = pd.DataFrame(
            [{"time": ts, "bid": mid, "ask": mid, "mid": mid, "spread": 0.0}]
        )
        price_df.set_index("time", inplace=True)
        return price_df


def _normalize_timeframe(tf):
    normalized = str(tf).upper()
    if normalized == "15M":
        return "M15"
    return normalized


def get_backtest_loop_seconds(execution_tf):
    tf_key = _normalize_timeframe(execution_tf)

    mapping = DEFAULT_BACKTEST_RELATIVITY_SECONDS.copy()
    if isinstance(CONFIG_BACKTEST_RELATIVITY, dict):
        mapping.update(CONFIG_BACKTEST_RELATIVITY)

    return mapping.get(tf_key, 1)


if __name__ == "__main__":
    os.makedirs(BACKTEST_DATA_DIR, exist_ok=True)
    setup_backtest_logging()

    # Runtime monkey patches so helper files remain unchanged.
    watcher_module.STATE_FILE = BACKTEST_STATE_FILE
    watcher_module.TradeExecutor = SimulatedTradeExecutor

    fetcher = BacktestCSVFetcher(
        data_dir=BACKTEST_DATA_DIR,
        instruments=INSTRUMENTS,
        base_granularity=_normalize_timeframe(CRT_TIMEFRAMES.get("execution_tf", "M15")),
    )

    watcher = Watcher(fetcher)

    # Keep same order used in main.py
    fetcher.start_price_stream()
    watcher.load_state()

    pairs = [p for p in INSTRUMENTS if p in fetcher.market_data]
    missing = [p for p in INSTRUMENTS if p not in fetcher.market_data]
    chart_pair = pairs[0] if pairs else None

    if missing:
        logging.warning(f"[BT DATA] Skipping pairs with missing CSV: {missing}")

    loop_sleep = get_backtest_loop_seconds(CRT_TIMEFRAMES.get("execution_tf", "M15"))
    execution_tf = _normalize_timeframe(CRT_TIMEFRAMES.get("execution_tf", "M15"))
    viewer = BacktestCandleViewer(enabled=True, window_size=120)

    logging.info("🚀 BACKTEST STARTED - REPLAY RUNNING....")
    logging.info(f"[BT LOOP] Candle-to-loop speed: {CRT_TIMEFRAMES.get('execution_tf')} -> {loop_sleep}s")
    if chart_pair:
        logging.info(f"[BT CHART] Live chart pair: {chart_pair} ({execution_tf})")

    while True:
        try:
            has_next = fetcher.advance_market()
            if not has_next:
                logging.info("✅ Backtest replay completed (no more candles).")
                break

            if chart_pair:
                chart_df = fetcher.get_candles(chart_pair, execution_tf, 120)
                viewer.update(chart_pair, execution_tf, chart_df)

            for pair in pairs:
                if pair in watcher.active_watchers:
                    thread = watcher.active_watchers[pair]["thread"]
                    if thread.is_alive():
                        continue
                    logging.warning(f"[STALE] Removing dead watcher for {pair}")
                    del watcher.active_watchers[pair]
                    watcher.save_state()

                if watcher.executor.has_open_position(pair):
                    continue

                logging.info(f"\n{'=' * 50}")
                logging.info(f"Analyzing {pair}")
                logging.info(f"{'=' * 50}")

                rdc_signal_data = None

                for timeframe_key, timeframe_value in CRT_TIMEFRAMES.items():
                    df = fetcher.get_candles(pair, _normalize_timeframe(timeframe_value), 1000)

                    if df.empty:
                        continue

                    if timeframe_key == "rdc_tf":
                        rdc_result = find_rdc(df, pair, timeframe_key)

                        if rdc_result:
                            (
                                _,
                                preceding_time,
                                proceding_time,
                                proceding_candle_type,
                                pro_high,
                                pro_low,
                                pre_high,
                                pre_low,
                            ) = rdc_result

                            rdc_signal_data = {
                                "preceding_time": preceding_time,
                                "proceding_time": proceding_time,
                                "proceding_candle_type": proceding_candle_type,
                                "pro_high": pro_high,
                                "pro_low": pro_low,
                            }

                            logging.info(f"[RDC FOUND] {pair}")

                    elif timeframe_key == "execution_tf":
                        if not rdc_signal_data:
                            continue

                        start_time = rdc_signal_data["proceding_time"]
                        end_time = start_time + pd.Timedelta(hours=4)

                        trend_result = analyze_trend_in_range(
                            df,
                            start_time,
                            end_time,
                            _normalize_timeframe(timeframe_value),
                        )

                        if not trend_result:
                            continue

                        trend_direction = trend_result["trend_direction"]

                        price_df = fetcher.get_current_price(pair)
                        if price_df is None:
                            continue

                        current_price = float(price_df["mid"].iloc[0])

                        percent = range_price_to_percent(
                            price=current_price,
                            high=rdc_signal_data["pro_high"],
                            low=rdc_signal_data["pro_low"],
                        )

                        logging.info(
                            f"[DEBUG] {pair} | %: {percent} | Trend: {trend_direction}"
                        )

                        candle_count = len(df[df.index >= rdc_signal_data["proceding_time"]])

                        logging.info(
                            f"[DEBUG] {pair} | Candle Count: {candle_count}"
                        )

                        if (candle_count <= 48) and (percent <= 35):
                            logging.info(f"[WATCHER] BUY activated for {pair}")

                            watcher.start(
                                pair=pair,
                                trend_direction=trend_direction,
                                preceding_time=rdc_signal_data["preceding_time"],
                                proceding_time=rdc_signal_data["proceding_time"],
                                trade_type="BUY",
                                pro_high=rdc_signal_data["pro_high"],
                                pro_low=rdc_signal_data["pro_low"],
                            )

                        elif (candle_count <= 48) and (percent >= 65):
                            logging.info(f"[WATCHER] SELL activated for {pair}")

                            watcher.start(
                                pair=pair,
                                trend_direction=trend_direction,
                                preceding_time=rdc_signal_data["preceding_time"],
                                proceding_time=rdc_signal_data["proceding_time"],
                                trade_type="SELL",
                                pro_high=rdc_signal_data["pro_high"],
                                pro_low=rdc_signal_data["pro_low"],
                            )

            logging.info("⏳ Sleeping before next replay candle...\n")
            time.sleep(loop_sleep)

        except Exception as e:
            logging.error(f"🔥 BACKTEST MAIN LOOP ERROR: {e}")
            time.sleep(1)

    watcher.save_state()
    viewer.close()

    # Export watcher logs to CSV for review.
    if watcher.logs:
        frames = []
        for pair, df_log in watcher.logs.items():
            if df_log is not None and not df_log.empty:
                out = df_log.copy()
                out["pair"] = pair
                frames.append(out)

        if frames:
            results = pd.concat(frames, ignore_index=True)
            summary_path = os.path.join(BACKTEST_DATA_DIR, "backtest_results.csv")
            results.to_csv(summary_path, index=False)
            logging.info(f"[BT RESULT] Saved watcher logs to {summary_path}")
