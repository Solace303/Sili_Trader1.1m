import json
import os
import threading
import time
import pandas as pd
import logging

from strategyn1 import range_percentage_to_price, range_price_to_percent
from execution import TradeExecutor

STATE_FILE = "./Sili_Trader/forex_data/watcher_state.json"


class Watcher:

    def __init__(self, fetcher):
        self.fetcher = fetcher
        self.executor = TradeExecutor()

        self.active_watchers = {}   # pair → {thread, state}
        self.logs = {}

        self.lock = threading.Lock()

    # ==========================
    # SAVE STATE
    # ==========================
    def save_state(self):

        with self.lock:

            os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)

            data = [info["state"] for info in self.active_watchers.values()]

            with open(STATE_FILE, "w") as f:
                json.dump(data, f, indent=4, default=str)

    # ==========================
    # LOAD STATE (RESTORE)
    # ==========================
    def load_state(self):

        if not os.path.exists(STATE_FILE):
            logging.info("[STATE] No previous state found")
            return

        with open(STATE_FILE, "r") as f:
            data = json.load(f)

        for state in data:

            # 🔥 SKIP CLOSED TRADES
            if state.get("status") == "CLOSED":
                logging.info(f"[SKIP RESTORE] Closed trade for {state['pair']}")
                continue

            pair = state["pair"]

            logging.info(f"[RESTORE] Restarting watcher for {pair}")

            self.start(
                pair=pair,
                trend_direction=state["trend_direction"],
                preceding_time=pd.to_datetime(state["preceding_time"]),
                proceding_time=pd.to_datetime(state["proceding_time"]),
                trade_type=state["trade_type"],
                pro_high=state["pro_high"],
                pro_low=state["pro_low"]
            )

    # ==========================
    # START WATCHER
    # ==========================
    def start(
        self,
        pair,
        trend_direction,
        preceding_time,
        proceding_time,
        trade_type,
        pro_high,
        pro_low
    ):

        # Prevent duplicate threads
        if pair in self.active_watchers:
            logging.info(f"[WATCHER] Already running for {pair}")
            return

        # ==========================
        # INITIAL STATE
        # ==========================
        state = {
            "pair": pair,
            "trade_type": trade_type,
            "trend_direction": trend_direction,
            "pro_high": pro_high,
            "pro_low": pro_low,
            "preceding_time": str(preceding_time),
            "proceding_time": str(proceding_time),
            "status": "WATCHING"
        }

        def run():

            logging.info(f"[WATCHER STARTED] {pair}")

            df_log = pd.DataFrame(columns=[
                "timestamp",
                "preceding_time",
                "proceding_time",
                "entry_price",
                "stop_loss",
                "take_profit",
                "result"
            ])

            trade_open = False
            entry_price = None
            sl = None
            tp = None

            try:

                while True:

                    # ==========================
                    # GET LIVE PRICE
                    # ==========================
                    price_df = self.fetcher.get_current_price(pair)

                    if price_df is None:
                        time.sleep(1)
                        continue

                    current_price = price_df["mid"].iloc[0]

                    # ==========================
                    # DYNAMIC PERCENT
                    # ==========================
                    percent = range_price_to_percent(
                        price=current_price,
                        high=pro_high,
                        low=pro_low
                    )

                    # ==========================
                    # ENTRY LOGIC
                    # ==========================
                    if not trade_open:

                        # 🔥 BROKER SYNC (REAL FIX)
                        if self.executor.has_open_position(pair):

                            details = self.executor.get_open_trade_details(pair)

                            if details:
                                entry_price = details["price"]
                                sl = details["sl"]
                                tp = details["tp"]

                                trade_open = True

                                state["status"] = "OPEN"
                                state["entry_price"] = entry_price
                                state["sl"] = sl
                                state["tp"] = tp

                                self.save_state()

                                logging.info(
                                    f"[SYNC] {pair} | Entry: {entry_price} | SL: {sl} | TP: {tp}"
                                )

                                continue

                        # BUY ENTRY
                        if (trade_type == "BUY") and (25 <= percent <= 35) and trend_direction == "Uptrend":

                            tp = range_percentage_to_price(75, pro_high, pro_low)
                            sl = pro_low

                            self.executor.buy(pair, 1000, sl, tp)

                            entry_price = current_price
                            trade_open = True

                            state["status"] = "OPEN"
                            self.save_state()

                            logging.info(f"[BUY] {pair} @ {entry_price} | TP: {tp} | SL: {sl}")

                        # SELL ENTRY
                        elif (trade_type == "SELL") and (65 <= percent <= 75) and trend_direction == "Downtrend":

                            tp = range_percentage_to_price(25, pro_high, pro_low)
                            sl = pro_high

                            self.executor.sell(pair, 1000, sl, tp)

                            entry_price = current_price
                            trade_open = True

                            state["status"] = "OPEN"
                            self.save_state()

                            logging.info(f"[SELL] {pair} @ {entry_price} | TP: {tp} | SL: {sl}")

                    # ==========================
                    # EXIT LOGIC
                    # ==========================
                    else:

                        result = None

                        if trade_type == "BUY":
                            if current_price <= sl:
                                result = "LOSS"
                            elif current_price >= tp:
                                result = "WIN"

                        elif trade_type == "SELL":
                            if current_price >= sl:
                                result = "LOSS"
                            elif current_price <= tp:
                                result = "WIN"

                        if result:

                            logging.info(f"[EXIT] {pair} → {result}")

                            df_log.loc[len(df_log)] = [
                                pd.Timestamp.now(),
                                preceding_time,
                                proceding_time,
                                entry_price,
                                sl,
                                tp,
                                result
                            ]

                            self.logs[pair] = df_log

                            state["status"] = "CLOSED"
                            self.save_state()

                            break


            except Exception as e:
                logging.error(f"[WATCHER ERROR] {pair}: {e}")

            finally:

                logging.info(f"[WATCHER STOPPED] {pair}")

                with self.lock:
                    if pair in self.active_watchers:
                        del self.active_watchers[pair]

                self.save_state()

        # ==========================
        # THREAD START
        # ==========================
        thread = threading.Thread(target=run, daemon=True)

        self.active_watchers[pair] = {
            "thread": thread,
            "state": state
        }

        self.save_state()
        thread.start()