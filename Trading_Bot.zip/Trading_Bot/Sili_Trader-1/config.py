"""Project configuration for Sili_Trader."""

# -----------------------------------------------------------------------------
# OANDA API configuration
# -----------------------------------------------------------------------------
OANDA_API_KEY     = "387fae57368cb651154d2dc8df3882db-4b88c9f19596d99a78f41da15071795c"
OANDA_ACCOUNT_ID  = "101-001-38660645-001"
OANDA_ENVIRONMENT = "practice"

# ================================
# ▶  MODE SWITCH  ◀
#   False → live trading via OANDA
#   True  → backtest replay from CSV
# ================================
BACKTEST_MODE = True

# ================================
# BACKTEST SETTINGS
# (only used when BACKTEST_MODE = True)
# ================================
BACKTEST_DATA_DIR = "/run/media/solace/ABBA-2E35/My_Code/Sili_Trader/forex_data"
CHART_CANDLE_LIMIT = 200   # candles sent to the browser per request

# ================================
# MULTI-PAIR CONFIGURATION
# ================================
INSTRUMENTS = [
    "EUR_USD",
    "GBP_USD",
    "USD_JPY",
    "AUD_USD",
    "USD_CAD",
    "EUR_GBP",
    "EUR_JPY",
    "GBP_JPY",
]

CRT_TIMEFRAMES = {
    "rdc_tf":         "H4",
    "manipulation_tf":"H1",
    "execution_tf":   "M15",
}

LOOPBACK_CANDLES = {
    "rdc_tf":         3,
    "manipulation_tf":3,
    "execution_tf":   3,
    "test_tf":        500,
}

# ================================
# BACKTEST LOOP SPEED CONFIG
# ================================
BACKTEST_TIMEFRAME_RELATIVITY_SECONDS = {
    "H4":  5,
    "H1":  3,
    "M15": 1,
    "15M": 1,
}

# ================================
# TREND DETECTION SETTINGS
# ================================
TREND_CONFIG = {
    "reference_timeframe":  "4h",
    "threshold_mode":       "volatility",
    "volatility_multiplier":2.0,
    "volatility_window":    50,
    "minimum_threshold":    0.0001,
}

# ================================
# WICK REJECTION CONFIG
# ================================
WICK_REJECTION_CONFIG = {
    "lower_wick_to_body_threshold": 3.0,
    "upper_wick_to_body_threshold": 3.0,
}