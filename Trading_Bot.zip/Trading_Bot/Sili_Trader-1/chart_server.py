"""chart_server.py — Sili_Trader backtest chart server.

Run with ONE command only:
    uvicorn chart_server:app --host 0.0.0.0 --port 8000

Then open http://localhost:8000

The FastAPI startup event launches run_backtest() in a daemon thread so both
the backtest loop and the chart server share the same CandleStore object in
the same process memory. No second terminal needed.
"""

from __future__ import annotations

import json
import math
import threading
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

# Import the shared store AND the backtest runner from backtest.py.
# Both live in this process — candle_store is the same object the loop writes to.
from backtest import candle_store
from main import run as _run_backtest
from config import CRT_TIMEFRAMES, CHART_CANDLE_LIMIT, BACKTEST_MODE


# ---------------------------------------------------------------------------
# Lifespan — starts the backtest loop in a background daemon thread
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    if BACKTEST_MODE:
        thread = threading.Thread(target=_run_backtest, daemon=True, name="backtest-loop")
        thread.start()
    yield
    # daemon=True means it dies automatically when the main process exits


app = FastAPI(title="Sili_Trader Backtest Chart", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)

DISPLAY_TIMEFRAMES = list(CRT_TIMEFRAMES.values())


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _df_to_ohlcv(df) -> list[dict]:
    records = []
    for ts, row in df.iterrows():
        if any(math.isnan(v) for v in [row["open"], row["high"], row["low"], row["close"]]):
            continue
        records.append({
            "t": ts.isoformat(),
            "o": round(float(row["open"]),  5),
            "h": round(float(row["high"]),  5),
            "l": round(float(row["low"]),   5),
            "c": round(float(row["close"]), 5),
            "v": int(row.get("volume", 0)),
            "type": str(row.get("candle_type", "")),
        })
    return records


# ---------------------------------------------------------------------------
# API routes
# ---------------------------------------------------------------------------

@app.get("/api/pairs")
def get_pairs():
    result = []
    for pair in candle_store.pairs():
        cursor = candle_store.cursors.get(pair, 0)
        total  = candle_store.lengths.get(pair, 1)
        pct    = round(cursor / max(total - 1, 1) * 100, 1)
        result.append({
            "pair": pair,
            "cursor": cursor,
            "total": total,
            "progress_pct": pct,
            "timeframes": candle_store.timeframes(pair),
        })
    return JSONResponse(result)


@app.get("/api/candles/{pair}/{tf}")
def get_candles(pair: str, tf: str):
    tf_norm = tf.upper().replace("15M", "M15")
    df = candle_store.get(pair, tf_norm)
    if df is None:
        raise HTTPException(
            status_code=404,
            detail=f"No data yet for {pair}/{tf_norm}. Backtest may still be initialising."
        )
    candles = _df_to_ohlcv(df.tail(CHART_CANDLE_LIMIT))
    return JSONResponse({
        "pair": pair,
        "timeframe": tf_norm,
        "count": len(candles),
        "candles": candles,
    })


@app.get("/api/signal/{pair}")
def get_signal(pair: str):
    sig = candle_store.get_signal(pair)
    if sig is None:
        return JSONResponse({"pair": pair, "signal": None})
    out = {}
    for k, v in sig.items():
        if hasattr(v, "isoformat"):
            out[k] = v.isoformat()
        elif isinstance(v, float) and math.isnan(v):
            out[k] = None
        else:
            out[k] = v
    return JSONResponse({"pair": pair, "signal": out})


@app.get("/api/status")
def get_status():
    pairs    = candle_store.pairs()
    finished = sum(
        1 for p in pairs
        if candle_store.cursors.get(p, 0) >= candle_store.lengths.get(p, 1) - 1
    )
    return JSONResponse({
        "pairs_loaded":   len(pairs),
        "pairs_finished": finished,
        "running":        finished < len(pairs) or len(pairs) == 0,
    })


# ---------------------------------------------------------------------------
# Browser UI  (unchanged from before — paste your full _HTML string here)
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def index():
    return HTMLResponse(content=_HTML, status_code=200)


_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sili_Trader Backtest</title>
<script src="https://cdn.jsdelivr.net/npm/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js"></script>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg:#0d0f14;--surface:#141720;--border:#252a35;--accent:#00e5a0;
    --accent2:#ff6b35;--bull:#26a69a;--bear:#ef5350;--text:#e2e8f0;
    --muted:#64748b;--font:'Courier New','Lucida Console',monospace;
    --sidebar:220px;--header:52px;--tf-bar:40px;
  }
  body{background:var(--bg);color:var(--text);font-family:var(--font);font-size:13px;height:100dvh;display:flex;flex-direction:column;overflow:hidden;}
  header{height:var(--header);background:var(--surface);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 16px;gap:20px;flex-shrink:0;}
  .logo{font-size:14px;font-weight:bold;letter-spacing:3px;color:var(--accent);}
  #status-badge{font-size:11px;padding:3px 10px;border-radius:2px;border:1px solid var(--accent);color:var(--accent);letter-spacing:1px;}
  #status-badge.done{border-color:var(--muted);color:var(--muted);}
  #status-badge.waiting{border-color:#f0b429;color:#f0b429;}
  .spacer{flex:1;}
  #current-label{font-size:15px;letter-spacing:2px;}
  #current-price{font-size:15px;color:var(--accent);letter-spacing:1px;}
  .body-wrap{flex:1;display:flex;overflow:hidden;}
  aside{width:var(--sidebar);background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;flex-shrink:0;overflow:hidden;}
  .sidebar-title{padding:10px 14px;font-size:10px;letter-spacing:2px;color:var(--muted);border-bottom:1px solid var(--border);text-transform:uppercase;}
  #pair-list{flex:1;overflow-y:auto;scrollbar-width:thin;scrollbar-color:var(--border) transparent;}
  .pair-item{padding:10px 14px;cursor:pointer;border-bottom:1px solid var(--border);transition:background 0.1s;position:relative;}
  .pair-item:hover{background:rgba(255,255,255,0.04);}
  .pair-item.active{background:rgba(0,229,160,0.08);border-left:2px solid var(--accent);}
  .pair-name{font-size:12px;letter-spacing:1px;}
  .pair-progress{margin-top:5px;height:2px;background:var(--border);border-radius:1px;overflow:hidden;}
  .pair-progress-fill{height:100%;background:var(--accent);border-radius:1px;transition:width 0.4s ease;}
  .pair-pct{font-size:10px;color:var(--muted);margin-top:3px;}
  main{flex:1;display:flex;flex-direction:column;overflow:hidden;}
  .tf-bar{height:var(--tf-bar);background:var(--surface);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 12px;gap:6px;flex-shrink:0;}
  .tf-btn{background:transparent;border:1px solid var(--border);color:var(--muted);font-family:var(--font);font-size:11px;letter-spacing:1px;padding:4px 12px;cursor:pointer;border-radius:2px;transition:all .15s;}
  .tf-btn:hover{border-color:var(--accent);color:var(--accent);}
  .tf-btn.active{background:rgba(0,229,160,0.12);border-color:var(--accent);color:var(--accent);}
  .chart-panels{flex:1;display:flex;flex-direction:column;overflow:hidden;gap:1px;background:var(--border);}
  .chart-panel{flex:1;position:relative;background:var(--bg);overflow:hidden;}
  .panel-label{position:absolute;top:8px;left:12px;font-size:11px;letter-spacing:2px;color:var(--muted);z-index:10;pointer-events:none;text-transform:uppercase;}
  #signal-box{position:absolute;bottom:20px;right:16px;background:rgba(14,16,20,0.9);border:1px solid var(--border);border-left:2px solid var(--accent2);padding:8px 12px;font-size:11px;letter-spacing:1px;z-index:20;min-width:200px;display:none;}
  #signal-box.visible{display:block;}
  #signal-box .sig-title{color:var(--accent2);font-size:10px;letter-spacing:2px;margin-bottom:6px;text-transform:uppercase;}
  #signal-box .sig-row{display:flex;justify-content:space-between;margin-bottom:3px;gap:16px;}
  #signal-box .sig-key{color:var(--muted);}
  .bull{color:var(--bull);} .bear{color:var(--bear);}
  #waiting-msg{flex:1;display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:12px;letter-spacing:2px;display:none;}
  #waiting-msg.visible{display:flex;}
</style>
</head>
<body>
<header>
  <span class="logo">SILI_TRADER</span>
  <span id="status-badge" class="waiting">◌ INITIALIZING</span>
  <div class="spacer"></div>
  <span id="current-label"></span>&nbsp;
  <span id="current-price"></span>
</header>
<div class="body-wrap">
  <aside>
    <div class="sidebar-title">Pairs</div>
    <div id="pair-list"></div>
  </aside>
  <main>
    <div class="tf-bar" id="tf-bar"></div>
    <div id="waiting-msg" class="visible">Waiting for backtest data...</div>
    <div class="chart-panels" id="chart-panels"></div>
    <div id="signal-box"><div class="sig-title">RDC Signal</div><div id="signal-rows"></div></div>
  </main>
</div>
<script>
"use strict";
const state={pairs:[],activePair:null,charts:{},series:{},visibleTfs:[],allTfs:[],refreshInterval:2000,statusInterval:4000,initializedSeries:new Set(),barSpacing:8};
const BULL='#26a69a',BEAR='#ef5350';
const chartTheme={layout:{background:{color:'#0d0f14'},textColor:'#c9d1d9'},grid:{vertLines:{color:'#1a1f2c'},horzLines:{color:'#1a1f2c'}},crosshair:{mode:1},timeScale:{borderColor:'#252a35',timeVisible:true,secondsVisible:false},rightPriceScale:{visible:true,borderVisible:true,borderColor:'#252a35',scaleMargins:{top:0.1,bottom:0.1}}};
const pairListEl=document.getElementById('pair-list');
const tfBarEl=document.getElementById('tf-bar');
const panelsEl=document.getElementById('chart-panels');
const signalBoxEl=document.getElementById('signal-box');
const signalRowsEl=document.getElementById('signal-rows');
const statusBadge=document.getElementById('status-badge');
const waitingMsg=document.getElementById('waiting-msg');
const currentLabel=document.getElementById('current-label');
const currentPrice=document.getElementById('current-price');

async function fetchPairs(){
  try{
    const res=await fetch('/api/pairs');
    if(!res.ok)return;
    const data=await res.json();
    if(!data.length){
      waitingMsg.classList.add('visible');
      panelsEl.innerHTML='';
      return;
    }
    waitingMsg.classList.remove('visible');
    state.pairs=data;
    pairListEl.innerHTML='';
    data.forEach(p=>{
      const el=document.createElement('div');
      el.className='pair-item'+(p.pair===state.activePair?' active':'');
      el.dataset.pair=p.pair;
      el.innerHTML=`<div class="pair-name">${p.pair.replace('_','/')}</div>
        <div class="pair-progress"><div class="pair-progress-fill" style="width:${p.progress_pct}%"></div></div>
        <div class="pair-pct">${p.progress_pct}% · ${p.cursor}/${p.total}</div>`;
      el.addEventListener('click',()=>selectPair(p.pair,p.timeframes));
      pairListEl.appendChild(el);
      if(!state.activePair&&data.indexOf(p)===0) selectPair(p.pair,p.timeframes);
    });
  }catch(e){console.warn('fetchPairs',e);}
}

function selectPair(pair,timeframes){
  if(state.activePair===pair)return;
  state.activePair=pair;
  state.allTfs=timeframes||[];
  document.querySelectorAll('.pair-item').forEach(el=>el.classList.toggle('active',el.dataset.pair===pair));
  currentLabel.textContent=pair.replace('_','/');
  state.visibleTfs=[...state.allTfs];
  renderTfBar();rebuildPanels();refreshCharts();refreshSignal();
}

function renderTfBar(){
  const existingControls = tfBarEl.querySelector('#bar-spacing') ? tfBarEl.innerHTML.split('<span style="color:var(--muted)')[1] : null;
  tfBarEl.innerHTML='';
  state.allTfs.forEach(tf=>{
    const btn=document.createElement('button');
    btn.className='tf-btn'+(state.visibleTfs.includes(tf)?' active':'');
    btn.textContent=tf;
    btn.addEventListener('click',()=>toggleTf(tf,btn));
    tfBarEl.appendChild(btn);
  });
  const spacer=document.createElement('span');
  spacer.style.cssText='color:var(--muted);font-size:10px;letter-spacing:1px;white-space:nowrap;margin-left:auto';
  spacer.textContent='CANDLE WIDTH';
  tfBarEl.appendChild(spacer);
  const slider=document.createElement('input');
  slider.type='range';slider.id='bar-spacing';slider.min=2;slider.max=60;slider.value=state.barSpacing;
  slider.style.cssText='width:100px;accent-color:var(--accent);cursor:pointer';
  slider.addEventListener('input',()=>setBarSpacing(parseInt(slider.value)));
  tfBarEl.appendChild(slider);
  const lbl=document.createElement('span');
  lbl.id='bar-spacing-val';lbl.style.cssText='color:var(--accent);font-size:10px;min-width:20px';
  lbl.textContent=state.barSpacing;
  tfBarEl.appendChild(lbl);
}

function toggleTf(tf,btn){
  const idx=state.visibleTfs.indexOf(tf);
  if(idx===-1){state.visibleTfs.push(tf);btn.classList.add('active');}
  else{if(state.visibleTfs.length===1)return;state.visibleTfs.splice(idx,1);btn.classList.remove('active');}
  rebuildPanels();refreshCharts();
}

function rebuildPanels(){
  Object.values(state.charts).forEach(c=>c.remove());
  state.charts={};state.series={};panelsEl.innerHTML='';
  state.visibleTfs.forEach(tf=>{
    state.initializedSeries.delete(tf);
    const panel=document.createElement('div');
    panel.className='chart-panel';panel.id='panel-'+tf;
    const label=document.createElement('div');
    label.className='panel-label';label.textContent=tf;
    panel.appendChild(label);panelsEl.appendChild(panel);
    const chart=LightweightCharts.createChart(panel,{...chartTheme,autoSize:true});
    chart.timeScale().applyOptions({barSpacing:state.barSpacing});
    const series=chart.addCandlestickSeries({upColor:BULL,downColor:BEAR,borderUpColor:BULL,borderDownColor:BEAR,wickUpColor:BULL,wickDownColor:BEAR});
    state.charts[tf]=chart;state.series[tf]=series;
  });
  observeResize();
}

function setBarSpacing(v){
  state.barSpacing=v;
  const lbl=document.getElementById('bar-spacing-val');
  if(lbl)lbl.textContent=v;
  Object.values(state.charts).forEach(c=>c.timeScale().applyOptions({barSpacing:v}));
}

async function refreshCharts(){
  if(!state.activePair)return;
  for(const tf of state.visibleTfs){
    try{
      const res=await fetch(`/api/candles/${state.activePair}/${tf}`);
      if(!res.ok)continue;
      const data=await res.json();
      const fmt=data.candles.map(c=>({time:Math.floor(new Date(c.t).getTime()/1000),open:c.o,high:c.h,low:c.l,close:c.c}));
      if(fmt.length>0&&state.series[tf]){
        const samplePrice=fmt[fmt.length-1]?.close||1;
        const isJpy=samplePrice>10;
        const precision=isJpy?3:5;
        state.series[tf].applyOptions({priceFormat:{type:'price',precision,minMove:isJpy?0.001:0.00001}});
        state.series[tf].setData(fmt);
        if(!state.initializedSeries.has(tf)){
          state.charts[tf].timeScale().fitContent();
          state.initializedSeries.add(tf);
        }
        const last=data.candles[data.candles.length-1];
        if(last&&tf===state.visibleTfs[0]){
          currentPrice.className=last.c>=last.o?'bull':'bear';
          currentPrice.textContent=last.c.toFixed(5);
        }
      }
    }catch(e){console.warn('refreshCharts',tf,e);}
  }
}

async function refreshSignal(){
  if(!state.activePair)return;
  try{
    const res=await fetch(`/api/signal/${state.activePair}`);
    if(!res.ok)return;
    const data=await res.json();const sig=data.signal;
    if(!sig){signalBoxEl.classList.remove('visible');return;}
    signalBoxEl.classList.add('visible');
    const tc=sig.trend_direction==='Uptrend'?'bull':'bear';
    signalRowsEl.innerHTML=`
      <div class="sig-row"><span class="sig-key">Trend</span><span class="sig-val ${tc}">${sig.trend_direction||'-'}</span></div>
      <div class="sig-row"><span class="sig-key">% in range</span><span class="sig-val">${sig.percent!=null?sig.percent.toFixed(1)+'%':'-'}</span></div>
      <div class="sig-row"><span class="sig-key">Candles since</span><span class="sig-val">${sig.candle_count??'-'}</span></div>
      <div class="sig-row"><span class="sig-key">Pro high</span><span class="sig-val">${sig.pro_high?.toFixed(5)??'-'}</span></div>
      <div class="sig-row"><span class="sig-key">Pro low</span><span class="sig-val">${sig.pro_low?.toFixed(5)??'-'}</span></div>
      <div class="sig-row"><span class="sig-key">Price</span><span class="sig-val">${sig.current_price?.toFixed(5)??'-'}</span></div>`;
    Object.entries(state.series).forEach(([tf,series])=>{
      if(!series)return;
      try{if(series._btHighLine)series.removePriceLine(series._btHighLine);if(series._btLowLine)series.removePriceLine(series._btLowLine);}catch(_){}
      if(sig.pro_high)series._btHighLine=series.createPriceLine({price:sig.pro_high,color:'#ff6b35',lineWidth:1,lineStyle:1,axisLabelVisible:true,title:'PRO HIGH'});
      if(sig.pro_low)series._btLowLine=series.createPriceLine({price:sig.pro_low,color:'#00e5a0',lineWidth:1,lineStyle:1,axisLabelVisible:true,title:'PRO LOW'});
    });
  }catch(e){console.warn('refreshSignal',e);}
}

async function refreshStatus(){
  try{
    const res=await fetch('/api/status');
    if(!res.ok)return;
    const d=await res.json();
    if(d.pairs_loaded===0){
      statusBadge.className='waiting';statusBadge.textContent='◌ INITIALISING';
    } else if(!d.running){
      statusBadge.className='done';statusBadge.textContent='■ COMPLETE';
    } else {
      statusBadge.className='';statusBadge.textContent='● LIVE REPLAY';
    }
  }catch(_){}
}

function observeResize(){}

function startPolling(){
  setInterval(async()=>{await fetchPairs();await refreshCharts();await refreshSignal();},state.refreshInterval);
  setInterval(refreshStatus,state.statusInterval);
}

(async()=>{await fetchPairs();refreshStatus();startPolling();observeResize();})();
</script>
</body>
</html>"""