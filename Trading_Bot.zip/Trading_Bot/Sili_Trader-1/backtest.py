"""backtest.py — Sili_Trader backtest engine.

Mirrors main.py exactly, except:
- All candle data comes from CSV files in BACKTEST_DATA_DIR (no OANDA calls).
- The watcher state is saved to backtest_watcher_state.json (not watcher_state.json).
- TradeExecutor is replaced with SimulatedTradeExecutor (no real orders placed).
- A shared CandleStore (thread-safe) is populated on every loop iteration so
    the FastAPI chart server (chart_server.py) can serve live chart data while
    the backtest is still running.
- Loop speed is controlled by BACKTEST_TIMEFRAME_RELATIVITY_SECONDS in config.py.

Usage
-----
# Terminal 1 — start the chart server first (optional but recommended)
uvicorn chart_server:app --host 0.0.0.0 --port 8000 --reload

# Terminal 2 — run the backtest
python backtest.py

Then open http://localhost:8000 in your browser.
"""

import os
import time
import logging
import threading
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

# ---------------------------------------------------------------------------
# Monkey-patch watcher module BEFORE importing Watcher so the module-level
# STATE_FILE and TradeExecutor are substituted for all code paths.
# ---------------------------------------------------------------------------
import watcher as watcher_module

BACKTEST_DATA_DIR = "/run/media/solace/ABBA-2E35/My_Code/Sili_Trader/forex_data"
BACKTEST_STATE_FILE = os.path.join(BACKTEST_DATA_DIR, "backtest_watcher_state.json")
BACKTEST_LOG_FILE = os.path.join(BACKTEST_DATA_DIR, "backtest_log.log")


# ---------------------------------------------------------------------------
# Simulated executor — same interface as execution.TradeExecutor
# ---------------------------------------------------------------------------

class SimulatedTradeExecutor:
    """Records orders in memory; never contacts OANDA."""

    def __init__(self):
        self._lock = threading.Lock()
        self.order_events: list[dict] = []

    def place_market_order(self, instrument, units, stop_loss=None, take_profit=None):
        record = {
            "instrument": instrument,
            "units": units,
            "sl": stop_loss,
            "tp": take_profit,
            "timestamp": pd.Timestamp.now(tz="UTC"),
        }
        with self._lock:
            self.order_events.append(record)
        return record

    def buy(self, instrument, units, stop_loss=None, take_profit=None):
        logging.info(f"[SIM BUY]  {instrument}  units={abs(units)}  sl={stop_loss}  tp={take_profit}")
        return self.place_market_order(instrument, abs(units), stop_loss, take_profit)

    def sell(self, instrument, units, stop_loss=None, take_profit=None):
        logging.info(f"[SIM SELL] {instrument}  units={-abs(units)}  sl={stop_loss}  tp={take_profit}")
        return self.place_market_order(instrument, -abs(units), stop_loss, take_profit)

    # Watcher checks this to avoid double-entry.
    # In backtest mode the watcher thread itself manages position lifecycle.
    def has_open_position(self, instrument: str) -> bool:
        return False

    def get_open_trade_details(self, instrument: str):
        return None

    def get_open_positions(self):
        return {"positions": []}

    def get_open_trades(self):
        return {"trades": []}


# Apply patches before Watcher is imported so it picks them up at import time.
watcher_module.STATE_FILE = BACKTEST_STATE_FILE
watcher_module.TradeExecutor = SimulatedTradeExecutor

from watcher import Watcher  # noqa: E402  (must come after patch)
from config import (  # noqa: E402
    INSTRUMENTS,
    CRT_TIMEFRAMES,
    BACKTEST_TIMEFRAME_RELATIVITY_SECONDS,
    CHART_CANDLE_LIMIT,
)
from strategyn1 import find_rdc, analyze_trend_in_range, range_price_to_percent  # noqa: E402

# ---------------------------------------------------------------------------
# Shared candle store (backtest → chart server bridge)
# ---------------------------------------------------------------------------

class CandleStore:
    """Thread-safe store that the backtest writes and the chart server reads.

    Structure:
        _data[pair][timeframe] = pd.DataFrame (latest N candles)
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._data: Dict[str, Dict[str, pd.DataFrame]] = {}
        # Track the cursor position so the UI can show replay progress.
        self.cursors: Dict[str, int] = {}      # pair → current row index
        self.lengths: Dict[str, int] = {}       # pair → total CSV row count
        self.active_signals: Dict[str, dict] = {}  # pair → latest signal info

    def update(self, pair: str, timeframe: str, df: pd.DataFrame) -> None:
        with self._lock:
            if pair not in self._data:
                self._data[pair] = {}
            self._data[pair][timeframe] = df.copy()

    def get(self, pair: str, timeframe: str) -> Optional[pd.DataFrame]:
        with self._lock:
            return self._data.get(pair, {}).get(timeframe)

    def pairs(self) -> list[str]:
        with self._lock:
            return list(self._data.keys())

    def timeframes(self, pair: str) -> list[str]:
        with self._lock:
            return list(self._data.get(pair, {}).keys())

    def set_signal(self, pair: str, info: dict) -> None:
        with self._lock:
            self.active_signals[pair] = info

    def get_signal(self, pair: str) -> Optional[dict]:
        with self._lock:
            return self.active_signals.get(pair)


# Module-level store — imported by chart_server.py
candle_store = CandleStore()


# ---------------------------------------------------------------------------
# OANDA timeframe normalisation
# ---------------------------------------------------------------------------

OANDA_TO_PANDAS = {
    "M1": "1min", "M5": "5min", "M15": "15min",
    "H1": "1H", "H4": "4H", "D": "1D",
}

DISPLAY_TIMEFRAMES = list(CRT_TIMEFRAMES.values())  # ["H4", "H1", "M15"]


def _norm(tf: str) -> str:
    s = str(tf).upper()
    return "M15" if s == "15M" else s


def _loop_sleep(tf: str) -> float:
    key = _norm(tf)
    return float(BACKTEST_TIMEFRAME_RELATIVITY_SECONDS.get(key, 1.0))


# ---------------------------------------------------------------------------
# CSV fetcher — same interface as data.CandleFetcher
# ---------------------------------------------------------------------------

class BacktestCSVFetcher:
    """Replays CSV candle files from oldest to newest, one row per loop tick."""

    def __init__(self, data_dir: str, instruments, base_granularity: str = "M15"):
        self.data_dir = Path(data_dir)
        self.base_granularity = base_granularity
        self.market_data: Dict[str, pd.DataFrame] = {}
        self.cursor: Dict[str, int] = {}

        for pair in instruments:
            path = self.data_dir / f"{pair}.csv"
            if not path.exists():
                logging.warning(f"[BT DATA] Missing CSV → {path}")
                continue

            df = pd.read_csv(path)
            if df.empty or "time" not in df.columns:
                logging.warning(f"[BT DATA] Invalid CSV for {pair}")
                continue

            df["time"] = pd.to_datetime(df["time"], utc=True)
            df = df.sort_values("time").set_index("time")
            kept = [c for c in ["open", "high", "low", "close", "volume"] if c in df.columns]
            df = df[kept].copy()
            self._add_features(df)

            self.market_data[pair] = df
            self.cursor[pair] = -1

            # Populate the shared store with initial metadata
            candle_store.lengths[pair] = len(df)
            candle_store.cursors[pair] = -1

        if not self.market_data:
            raise ValueError(
                f"No valid CSV files found in {data_dir}. "
                "Expected files like EUR_USD.csv"
            )

    # ------------------------------------------------------------------
    # Feature engineering (mirrors data.CandleFetcher)
    # ------------------------------------------------------------------

    @staticmethod
    def _add_features(df: pd.DataFrame) -> None:
        df["candle_type"] = "Neutral"
        df.loc[df["close"] > df["open"], "candle_type"] = "Bullish"
        df.loc[df["close"] < df["open"], "candle_type"] = "Bearish"
        df["body_size"] = (df["close"] - df["open"]).abs()
        df["upper_wick"] = df["high"] - df[["open", "close"]].max(axis=1)
        df["lower_wick"] = df[["open", "close"]].min(axis=1) - df["low"]

    # ------------------------------------------------------------------
    # Interface (same as data.CandleFetcher)
    # ------------------------------------------------------------------

    def start_price_stream(self) -> None:
        pass  # no-op — price comes from CSV cursor

    def all_finished(self) -> bool:
        return all(
            self.cursor[p] >= len(df) - 1
            for p, df in self.market_data.items()
        )

    def pair_finished(self, pair: str) -> bool:
        if pair not in self.market_data:
            return True
        return self.cursor[pair] >= len(self.market_data[pair]) - 1

    def advance_pair(self, pair: str) -> bool:
        """Advance one candle for a single pair. Returns True if advanced."""
        if pair not in self.market_data:
            return False
        idx = self.cursor[pair]
        if idx < len(self.market_data[pair]) - 1:
            self.cursor[pair] = idx + 1
            candle_store.cursors[pair] = self.cursor[pair]
            return True
        return False

    def _visible(self, pair: str) -> pd.DataFrame:
        """Return all rows up to and including the current cursor position."""
        if pair not in self.market_data:
            return pd.DataFrame()
        n = self.cursor[pair] + 1
        if n <= 0:
            return pd.DataFrame()
        return self.market_data[pair].iloc[:n].copy()

    def get_candles(self, instrument: str, granularity: str, count: int) -> pd.DataFrame:
        df = self._visible(instrument)
        if df.empty:
            return df

        if granularity == self.base_granularity:
            return df.tail(count)

        pandas_tf = OANDA_TO_PANDAS.get(granularity)
        if not pandas_tf:
            raise ValueError(f"Unsupported granularity: {granularity}")

        out = (
            df.resample(pandas_tf)
            .agg({"open": "first", "high": "max", "low": "min",
                  "close": "last", "volume": "sum"})
            .dropna()
        )
        if out.empty:
            return out

        self._add_features(out)
        return out.tail(count)

    def get_current_price(self, instrument: str, timeout: int = 10):
        df = self._visible(instrument)
        if df.empty:
            return None
        mid = float(df.iloc[-1]["close"])
        ts = df.index[-1]
        price_df = pd.DataFrame(
            [{"time": ts, "bid": mid, "ask": mid, "mid": mid, "spread": 0.0}]
        )
        price_df.set_index("time", inplace=True)
        return price_df


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def _setup_logging() -> None:
    fmt = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    logging.basicConfig(
        level=logging.INFO,
        format=fmt,
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.FileHandler(BACKTEST_LOG_FILE, mode="a", encoding="utf-8"),
            logging.StreamHandler(),
        ],
        force=True,
    )


# ---------------------------------------------------------------------------
# Signal analysis (mirrors main.py pair analysis block)
# ---------------------------------------------------------------------------

def _analyze_pair(pair: str, fetcher: BacktestCSVFetcher) -> Optional[dict]:
    """
    Run the full strategy pipeline for one pair.
    Returns a signal dict (with all keys main.py uses) or None.
    Mirrors the for-loop over CRT_TIMEFRAMES in main.py exactly.
    """
    rdc_signal: Optional[dict] = None

    for tf_key, tf_val in CRT_TIMEFRAMES.items():
        df = fetcher.get_candles(pair, _norm(tf_val), 1000)
        if df.empty:
            continue

        if tf_key == "rdc_tf":
            result = find_rdc(df, pair, tf_key)
            if not result:
                rdc_signal = None
                continue

            (_, pre_time, pro_time, pro_candle_type,
                pro_high, pro_low, pre_high, pre_low) = result

            rdc_signal = {
                "preceding_time": pre_time,
                "proceding_time": pro_time,
                "proceding_candle_type": pro_candle_type,
                "pro_high": pro_high,
                "pro_low": pro_low,
                "pre_high": pre_high,
                "pre_low": pre_low,
            }
            logging.info(f"[RDC FOUND] {pair}")

        elif tf_key == "execution_tf":
            if not rdc_signal:
                continue

            start_time = rdc_signal["proceding_time"]
            end_time = start_time + pd.Timedelta(hours=4)

            trend_result = analyze_trend_in_range(
                df, start_time, end_time, _norm(tf_val)
            )
            if not trend_result:
                continue

            price_df = fetcher.get_current_price(pair)
            if price_df is None:
                continue

            current_price = float(price_df["mid"].iloc[0])
            percent = range_price_to_percent(
                price=current_price,
                high=rdc_signal["pro_high"],
                low=rdc_signal["pro_low"],
            )
            candle_count = int(len(df[df.index >= rdc_signal["proceding_time"]]))

            logging.info(
                f"[DEBUG] {pair} | %={percent:.2f} | "
                f"trend={trend_result['trend_direction']} | "
                f"candles_since_rdc={candle_count}"
            )

            rdc_signal.update({
                "trend_direction": trend_result["trend_direction"],
                "normalized_slope": trend_result["normalized_slope"],
                "percent": percent,
                "candle_count": candle_count,
                "current_price": current_price,
            })
            return rdc_signal

    return None


# ---------------------------------------------------------------------------
# Candle store updater — pushes fresh data for all TFs after each advance
# ---------------------------------------------------------------------------

def _push_candles(pair: str, fetcher: BacktestCSVFetcher) -> None:
    """Update the shared candle store for every display timeframe of this pair."""
    for tf_val in DISPLAY_TIMEFRAMES:
        tf_norm = _norm(tf_val)
        df = fetcher.get_candles(pair, tf_norm, CHART_CANDLE_LIMIT)
        if not df.empty:
            candle_store.update(pair, tf_norm, df)


# ---------------------------------------------------------------------------
# Main backtest loop (mirrors main.py)
# ---------------------------------------------------------------------------

def run_backtest() -> None:
    os.makedirs(BACKTEST_DATA_DIR, exist_ok=True)
    _setup_logging()

    exec_tf = _norm(CRT_TIMEFRAMES.get("execution_tf", "M15"))
    sleep_s = _loop_sleep(exec_tf)

    fetcher = BacktestCSVFetcher(
        data_dir=BACKTEST_DATA_DIR,
        instruments=INSTRUMENTS,
        base_granularity=exec_tf,
    )

    watcher = Watcher(fetcher)
    fetcher.start_price_stream()
    watcher.load_state()

    pairs = list(fetcher.market_data.keys())
    missing = [p for p in INSTRUMENTS if p not in fetcher.market_data]
    if missing:
        logging.warning(f"[BT] No CSV for: {missing} — skipping")

    logging.info("=" * 60)
    logging.info("🚀  BACKTEST STARTED")
    logging.info(f"    Execution TF : {exec_tf}")
    logging.info(f"    Loop sleep   : {sleep_s} s per candle")
    logging.info(f"    Pairs loaded : {pairs}")
    logging.info(f"    Chart server : http://localhost:8000")
    logging.info("=" * 60)

    # Push the very first slice to the store so the chart server has data
    # immediately when the browser connects.
    for pair in pairs:
        fetcher.advance_pair(pair)
        _push_candles(pair, fetcher)

    # -----------------------------------------------------------------------
    # Main replay loop — identical structure to main.py's while True block
    # -----------------------------------------------------------------------
    while not fetcher.all_finished():
        try:
            # Advance every pair that still has candles left
            for pair in pairs:
                if not fetcher.pair_finished(pair):
                    fetcher.advance_pair(pair)

            # Push fresh candle slices to the shared store (chart server reads this)
            for pair in pairs:
                _push_candles(pair, fetcher)

            # ---- Per-pair strategy logic (mirrors main.py) ----
            for pair in pairs:

                # Stale-thread cleanup (same as main.py)
                if pair in watcher.active_watchers:
                    thread = watcher.active_watchers[pair]["thread"]
                    if thread.is_alive():
                        continue
                    logging.warning(f"[STALE] Removing dead watcher for {pair}")
                    del watcher.active_watchers[pair]
                    watcher.save_state()

                if watcher.executor.has_open_position(pair):
                    continue

                logging.info(f"\n{'=' * 50}")
                logging.info(f"Analyzing {pair}")
                logging.info(f"{'=' * 50}")

                signal = _analyze_pair(pair, fetcher)
                if signal is None:
                    continue

                # Push signal metadata to store for the chart overlay
                candle_store.set_signal(pair, signal)

                percent = signal.get("percent")
                candle_count = signal.get("candle_count", 999)
                trend = signal.get("trend_direction", "")

                # BUY condition (mirrors main.py)
                if (candle_count <= 48) and (percent is not None) and (percent <= 35):
                    logging.info(f"[WATCHER] BUY activated for {pair}")
                    watcher.start(
                        pair=pair,
                        trend_direction=trend,
                        preceding_time=signal["preceding_time"],
                        proceding_time=signal["proceding_time"],
                        trade_type="BUY",
                        pro_high=signal["pro_high"],
                        pro_low=signal["pro_low"],
                    )

                # SELL condition (mirrors main.py)
                elif (candle_count <= 48) and (percent is not None) and (percent >= 65):
                    logging.info(f"[WATCHER] SELL activated for {pair}")
                    watcher.start(
                        pair=pair,
                        trend_direction=trend,
                        preceding_time=signal["preceding_time"],
                        proceding_time=signal["proceding_time"],
                        trade_type="SELL",
                        pro_high=signal["pro_high"],
                        pro_low=signal["pro_low"],
                    )

            logging.info("⏳ Sleeping before next candle...\n")
            time.sleep(sleep_s)

        except Exception as e:
            logging.error(f"🔥 BACKTEST LOOP ERROR: {e}", exc_info=True)
            time.sleep(1)

    # -----------------------------------------------------------------------
    # Replay complete
    # -----------------------------------------------------------------------
    logging.info("✅ Backtest replay complete — all pairs exhausted")
    watcher.save_state()

    # Export watcher logs to CSV (same as main.py teardown)
    if watcher.logs:
        frames = []
        for pair, df_log in watcher.logs.items():
            if df_log is not None and not df_log.empty:
                out = df_log.copy()
                out["pair"] = pair
                frames.append(out)

        if frames:
            results = pd.concat(frames, ignore_index=True)
            summary_path = os.path.join(BACKTEST_DATA_DIR, "backtest_results.csv")
            results.to_csv(summary_path, index=False)
            logging.info(f"[RESULT] Watcher logs saved → {summary_path}")

            # Quick win/loss summary per pair
            logging.info("\n" + "=" * 50)
            logging.info("BACKTEST SUMMARY")
            logging.info("=" * 50)
            for pair in results["pair"].unique():
                sub = results[results["pair"] == pair]
                wins = int((sub["result"] == "WIN").sum())
                losses = int((sub["result"] == "LOSS").sum())
                total = len(sub)
                wr = (wins / total * 100) if total else 0.0
                logging.info(
                    f"  {pair:10s}  {wins}W / {losses}L / {total} trades  "
                    f"WR={wr:.1f}%"
                )
        else:
            logging.info("[RESULT] No completed trades to export.")
    else:
        logging.info("[RESULT] No watcher logs — no trades were triggered.")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    run_backtest()
